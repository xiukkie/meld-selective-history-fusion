# MELD selective history-expert fusion

Source snapshot for the S4-T1 MELD official-test experiment and the S4-T2
development-set decision-preserving inference benchmark.

- S4-T1: `review/S4T1_plan_2026-11-23/confirm.py` performs frozen prediction,
  sealing, scoring and audit. `core.py` implements probability fusion and
  paired dialogue bootstrap. `expert_entry.py` runs the Gemma expert.
- S4-T2: `review/S4T2_plan_2026-11-23/certified.py` implements the stopping
  certificate. `replay.py`, `benchmark.py` and `report.py` replay and time
  the expert queues.
- The P11 and C1 directories contain the expert/router and backbone code
  used by these experiments. The original layout preserves source paths.

## Run the bundled tests

Use Python 3.12 and NumPy. The full historical dependency pins are included.
From the extracted directory root:

```sh
python review/S4T1_plan_2026-11-23/test_confirm.py
python review/S4T2_plan_2026-11-23/test_certified.py
```

## External assets and scope

This source snapshot supports the bundled synthetic tests. The archived
end-to-end commands require the original frozen artifacts (nine C1
checkpoints, P11 archives, binding and acceptance files) and are not
standalone reproduction commands. The historical T2 shard manifests
also used absolute source paths.

Obtain MELD from https://github.com/declare-lab/MELD, the released feature
references from https://github.com/feiyuchen7/M3NET and the original expert
from https://huggingface.co/mlx-community/gemma-3-4b-it-4bit.
T1 records asset hashes in the bundled lock. Gemma timing used Apple
Silicon with MLX. Data, weights, utterance-level predictions and logs
are excluded from this snapshot.

Upstream notices are included alongside the respective third-party code
and for the MM-DFN adaptation. The repository license covers original code.
