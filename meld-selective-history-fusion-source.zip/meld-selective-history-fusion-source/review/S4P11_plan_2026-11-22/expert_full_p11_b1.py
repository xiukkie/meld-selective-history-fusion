"""S4-P11 long-experiment expert entry, batch-1 engineering adaptation.

Derived byte-for-byte from the frozen `expert_full_p11.py` (SHA 48ae6738…) with two
changes, made only after the frozen entry was measured unable to run this dataset:

Evidence (2026-11-22, this machine, same weights, same code path):
- The frozen entry probes each shard's shortest case solo vs batched with the shard's
  longest case and raises when the letter-probability shift exceeds 0.008.
- For the historical_dev scope-minimum row (meld_d1100::0, 89 tokens) that shift is
  content-invariant and width-robust: 0.0561 at widths 89-90 (including a self-pair),
  0.01392 at every sampled width 100-263 (40+ widths from dev and train rows).
  No shard composition can place this row outside a shard minimum, so the frozen
  guard is unreachable for real MELD dev/train data on this MLX/Metal build.
- Same-length different-content tails give bitwise-identical shifts, i.e. the effect
  is co-batching shape noise (fp16/4-bit kernel tiling), not attention leakage.

Adaptation (scientific semantics unchanged; model, template, token mapping, scoring
and output schema untouched):
1. `--batch` is forced to 1. Every case is computed as a solo forward: no co-batching,
   no shape noise, outputs independent of any shard/batch plan ("短/长同批不变量"
   holds by construction; right padding never occurs with batch 1).
2. The original probe is still computed and recorded (`legacy_batch_probe_max_delta`)
   but no longer raises. Instead a stricter content-invariance guard runs: two
   same-length, different-content cases co-batched with the shortest case must give
   bitwise-identical probabilities for that shortest case - this is the actual
   leakage property the original probe intended, with the shape confound removed.
   Missing duplicate lengths are recorded as skipped.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from mlx_vlm.utils import load_model
from transformers import AutoTokenizer
from expert_p11 import (MODEL, LABELS, ORDERS, VIEWS, alternative_tokens,
                        token_ids, frozen_logits, answer_probs, digest, LIMIT, LETTERS)


IEMO = ("happy", "sad", "neutral", "angry", "excited", "frustrated")
CHECKPOINT_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"
SCOPES = {"long_train": LABELS, "historical_dev": LABELS,
          "iemocap_session03": IEMO, "iemocap_session04": IEMO,
          "synthetic": LABELS, "synthetic_iemocap": IEMO}


def encode(tok, row, view, permutation, classes):
    base = dict(id=row["id"],target=row["target"],
                history=row["sham_history"] if view=="SHAM" else row["history"])
    mode = "CURRENT" if view=="CURRENT" else "HISTORY"
    if classes==LABELS:
        return token_ids(tok,base,mode,permutation)
    history=base["history"][-4:] if mode=="HISTORY" else []
    choices="\n".join(f"{symbol}. {classes[index]}" for symbol,index in zip(LETTERS[:len(classes)],permutation,strict=True))
    spk,text=base["target"]
    while True:
        prefix="\n".join(f"Speaker {who}: {sentence}" for who,sentence in history)
        prior=f"Earlier turns:\n{prefix}\n\n" if prefix else ""
        body=("Classify the emotion expressed by the target speaker in the target utterance. "
              "Choose the one best answer, even if the words alone are ambiguous. "
              "Use earlier turns if present. Respond with a single answer letter only.\n\n"
              f"{prior}Target utterance (speaker {spk}): {text}\n\n{choices}")
        ids=tok.apply_chat_template([{"role":"user","content":body}],tokenize=True,add_generation_prompt=True,return_dict=False)
        if len(ids)<=LIMIT:
            return ids
        if not history:
            raise ValueError(f"oversized IEMOCAP prompt {row['id']}")
        history=history[1:]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--batch",type=int,default=1)
    args=parser.parse_args()
    assert args.batch==1, "b1 adaptation runs solo forwards only (--batch 1)"
    start=time.monotonic()
    data=json.loads(args.input.read_bytes())
    classes=SCOPES[data["scope"]]
    orders=tuple(tuple(i for i in order if i<len(classes)) for order in ORDERS)
    rows=data["rows"]
    keys=[row["id"] for row in rows]
    assert keys and len(keys)==len(set(keys))
    if data["scope"].startswith("iemocap_session"):
        expected_prefix="Ses"+data["scope"][-2:]
        assert all(key.startswith(expected_prefix) for key in keys), "IEMOCAP session mismatch"
    for row in rows:
        assert set(row)=={"id","target","history","sham_history"}
        assert len(row["history"])==len(row["sham_history"])<=4
    assert digest(MODEL/"model.safetensors")==CHECKPOINT_SHA
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    model=load_model(MODEL,lazy=False)
    model.eval()
    groups=alternative_tokens(tok)[:len(classes)]
    views=(*VIEWS,"SHAM")
    cases=[(ix,j,k,encode(tok,row,view,order,classes))
           for ix,view in enumerate(views) for j,order in enumerate(orders) for k,row in enumerate(rows)]
    cases.sort(key=lambda r:len(r[3]))
    out=np.empty((3,2,len(rows),len(classes)),float)
    counts=np.zeros(out.shape[:-1],np.int64)
    head,tail=cases[0][3],cases[-1][3]
    # Legacy probe (recorded, non-gating under batch 1): shape noise level that a
    # co-batched plan would have incurred for the shard's shortest case.
    legacy_delta=float(np.max(np.abs(answer_probs(frozen_logits(model,tok,[head]),groups)[0] -
                              answer_probs(frozen_logits(model,tok,[head,tail]),groups)[0])))
    # Gating content-invariance probe: co-batching must never change a row's output
    # as a function of OTHER rows' content (attention-leakage property), with the
    # batch shape held fixed by using two same-length different-content tails.
    by_len={}
    for c in cases:
        by_len.setdefault(len(c[3]),[]).append(c[3])
    pair=None
    for length,items in sorted(by_len.items()):
        if len({tuple(t) for t in items})>=2:
            uniq={tuple(t):t for t in items}
            vals=list(uniq.values())
            pair=(vals[0],vals[-1])
            break
    if pair is None:
        content_probe="skipped_no_duplicate_length"
    else:
        ta,tb=pair
        pa=answer_probs(frozen_logits(model,tok,[head,ta]),groups)[0]
        pb=answer_probs(frozen_logits(model,tok,[head,tb]),groups)[0]
        if not np.array_equal(pa,pb):
            raise ValueError(f"content leakage detected: {float(np.max(np.abs(pa-pb)))}")
        content_probe="pass"
    for s in range(0,len(cases),args.batch):
        part=cases[s:s+args.batch]
        results=answer_probs(frozen_logits(model,tok,[r[3] for r in part]),groups)
        for (view,j,k,ids),prob in zip(part,results,strict=True):
            out[view,j,k,list(orders[j])]=prob
            counts[view,j,k]=len(ids)
    assert np.isfinite(out).all() and np.allclose(out.sum(axis=-1),1,rtol=0,atol=1e-12)
    with args.output.open("xb") as stream:
        np.savez_compressed(stream,keys=np.asarray(keys),views=np.asarray(views),classes=np.asarray(classes),
                            probabilities=out,token_lengths=counts)
    print(json.dumps(dict(input_sha=digest(args.input),output_sha=digest(args.output),rows=len(rows),
                          checkpoint_sha=CHECKPOINT_SHA,calls=len(cases),seconds=time.monotonic()-start,
                          legacy_batch_probe_max_delta=legacy_delta,content_invariance=content_probe,
                          batch_mode=1)))


if __name__=="__main__":
    main()
