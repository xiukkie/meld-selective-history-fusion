"""Run the frozen text expert on real, removed, and matched replacement histories."""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from mlx_vlm.utils import load_model
from transformers import AutoTokenizer
from expert_p11 import (MODEL, LABELS, ORDERS, VIEWS, alternative_tokens,
                        token_ids, frozen_logits, answer_probs, digest, LIMIT, LETTERS)


IEMO = ("happy", "sad", "neutral", "angry", "excited", "frustrated")
CHECKPOINT_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"
SCOPES = {"long_train": LABELS, "historical_dev": LABELS,
          "iemocap_session03": IEMO, "iemocap_session04": IEMO,
          "synthetic": LABELS, "synthetic_iemocap": IEMO}


def encode(tok, row, view, permutation, classes):
    base = dict(id=row["id"],target=row["target"],
                history=row["sham_history"] if view=="SHAM" else row["history"])
    mode = "CURRENT" if view=="CURRENT" else "HISTORY"
    if classes==LABELS:
        return token_ids(tok,base,mode,permutation)
    history=base["history"][-4:] if mode=="HISTORY" else []
    choices="\n".join(f"{symbol}. {classes[index]}" for symbol,index in zip(LETTERS[:len(classes)],permutation,strict=True))
    spk,text=base["target"]
    while True:
        prefix="\n".join(f"Speaker {who}: {sentence}" for who,sentence in history)
        prior=f"Earlier turns:\n{prefix}\n\n" if prefix else ""
        body=("Classify the emotion expressed by the target speaker in the target utterance. "
              "Choose the one best answer, even if the words alone are ambiguous. "
              "Use earlier turns if present. Respond with a single answer letter only.\n\n"
              f"{prior}Target utterance (speaker {spk}): {text}\n\n{choices}")
        ids=tok.apply_chat_template([{"role":"user","content":body}],tokenize=True,add_generation_prompt=True,return_dict=False)
        if len(ids)<=LIMIT:
            return ids
        if not history:
            raise ValueError(f"oversized IEMOCAP prompt {row['id']}")
        history=history[1:]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--batch",type=int,default=12)
    args=parser.parse_args()
    start=time.monotonic()
    data=json.loads(args.input.read_bytes())
    classes=SCOPES[data["scope"]]
    orders=tuple(tuple(i for i in order if i<len(classes)) for order in ORDERS)
    rows=data["rows"]
    keys=[row["id"] for row in rows]
    assert keys and len(keys)==len(set(keys))
    if data["scope"].startswith("iemocap_session"):
        expected_prefix="Ses"+data["scope"][-2:]
        assert all(key.startswith(expected_prefix) for key in keys), "IEMOCAP session mismatch"
    for row in rows:
        assert set(row)=={"id","target","history","sham_history"}
        assert len(row["history"])==len(row["sham_history"])<=4
    assert digest(MODEL/"model.safetensors")==CHECKPOINT_SHA
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    model=load_model(MODEL,lazy=False)
    model.eval()
    groups=alternative_tokens(tok)[:len(classes)]
    views=(*VIEWS,"SHAM")
    cases=[(ix,j,k,encode(tok,row,view,order,classes))
           for ix,view in enumerate(views) for j,order in enumerate(orders) for k,row in enumerate(rows)]
    cases.sort(key=lambda r:len(r[3]))
    out=np.empty((3,2,len(rows),len(classes)),float)
    counts=np.zeros(out.shape[:-1],np.int64)
    head,tail=cases[0][3],cases[-1][3]
    delta=float(np.max(np.abs(answer_probs(frozen_logits(model,tok,[head]),groups)[0] -
                              answer_probs(frozen_logits(model,tok,[head,tail]),groups)[0])))
    if delta>0.008:
        raise ValueError(f"padding mismatch: {delta}")
    for s in range(0,len(cases),args.batch):
        part=cases[s:s+args.batch]
        results=answer_probs(frozen_logits(model,tok,[r[3] for r in part]),groups)
        for (view,j,k,ids),prob in zip(part,results,strict=True):
            out[view,j,k,list(orders[j])]=prob
            counts[view,j,k]=len(ids)
    assert np.isfinite(out).all() and np.allclose(out.sum(axis=-1),1,rtol=0,atol=1e-12)
    with args.output.open("xb") as stream:
        np.savez_compressed(stream,keys=np.asarray(keys),views=np.asarray(views),classes=np.asarray(classes),
                            probabilities=out,token_lengths=counts)
    print(json.dumps(dict(input_sha=digest(args.input),output_sha=digest(args.output),rows=len(rows),
                          checkpoint_sha=CHECKPOINT_SHA,calls=len(cases),seconds=time.monotonic()-start,
                          batch_probe_max_delta=delta)))


if __name__=="__main__":
    main()
