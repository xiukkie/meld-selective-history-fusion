"""Paired candidate scoring for S4-P11. NumPy/SciPy, no model or data access."""
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp


ALPHA_CANDIDATE = .25
L2 = .10
EPS = 1e-8


def distributions(p, q):
    p, q = np.asarray(p, float), np.asarray(q, float)
    if p.ndim != 2 or q.shape != (3, 2, *p.shape):
        raise ValueError("q must be [current, real, sham] x order x row x class")
    for item in (p, q):
        if not (np.isfinite(item).all() and np.all(item >= 0) and
                np.allclose(item.sum(axis=-1), 1, rtol=0, atol=2e-6)):
            raise ValueError("invalid probability distribution")
    return p, q


def features(p, q, arm):
    p, q = distributions(p, q)
    real = q[1].mean(axis=0)
    row = np.arange(len(p))
    a = p.argmax(axis=-1)
    b = ((1-ALPHA_CANDIDATE)*p+ALPHA_CANDIDATE*real).argmax(axis=-1)
    lp, lr = np.log(np.maximum(p, EPS)), np.log(np.maximum(real, EPS))

    def margin(probs):
        logp = np.log(np.maximum(probs, EPS))
        return logp[...,row,b]-logp[...,row,a]

    real_margin = margin(q[1])
    entropy_p = -(p*lp).sum(axis=-1)
    entropy_r = -(real*lr).sum(axis=-1)
    core = np.column_stack((lp[row,b]-lp[row,a], lr[row,b]-lr[row,a],
                            entropy_p, entropy_r, np.abs(p-real).sum(axis=-1),
                            real_margin.min(axis=0), np.abs(real_margin[0]-real_margin[1])))
    if arm != "ORDINARY":
        if arm not in ("CF", "SHAM_CF"):
            raise ValueError("unknown feature arm")
        selected = 1 if arm=="CF" else 2
        context = margin(q[selected])-margin(q[0])
        core = np.column_stack((core, context.T))
    return core, a, b


def objective(w, x, y):
    weight = w.reshape(x.shape[1], 3)
    logits = x@weight
    logp = logits-logsumexp(logits,axis=-1,keepdims=True)
    error = np.exp(logp)-np.eye(3)[y]
    value = -logp[np.arange(len(x)),y].mean()+.5*L2*np.square(weight).sum()
    grad = x.T@error/len(x)+L2*weight
    return value,grad.ravel()


def fit(x, a, b, y):
    y = np.asarray(y)
    use = a!=b
    data = np.asarray(x, float)[use]
    targets = np.select([y[use]==a[use], y[use]==b[use]], [0,1], default=2)
    if len(data)==0 or not np.all(np.bincount(targets,minlength=3)):
        raise ValueError("three outcomes require support on training disagreements")
    center=data.mean(axis=0)
    scale=np.maximum(data.std(axis=0),1e-8)
    dx=np.c_[np.ones(len(data)),(data-center)/scale]
    result=minimize(objective,np.zeros(dx.shape[1]*3),args=(dx,targets),jac=True,method="L-BFGS-B",
                    options=dict(ftol=1e-13,gtol=1e-9,maxiter=350))
    if not result.success or max(abs(result.jac))>1e-6:
        raise RuntimeError(f"routing optimization failed: {result.message}")
    return dict(center=center.tolist(),scale=scale.tolist(),coef=result.x.reshape(-1,3).tolist(),
                train_disagreements=len(targets),outcome_support=np.bincount(targets,minlength=3).tolist(),
                max_gradient=float(max(abs(result.jac))),steps=int(result.nit))


def risk(x, model, a, b):
    d=np.c_[np.ones(len(x)),(x-model["center"])/model["scale"]]
    logits=d@np.asarray(model["coef"])
    q=np.exp(logits-logsumexp(logits,axis=-1,keepdims=True))
    value=q[:,1]-q[:,0]
    value[a==b]=-np.inf
    return value,q


def order_margins(p, keys):
    sorted_p=np.sort(p,axis=-1)
    return np.lexsort((keys,sorted_p[:,-1]-sorted_p[:,-2]))


def choose_actions(a,b,score,keys,queries,limit,minimum=-np.inf):
    # queries is the common label-free mask. Exact budget diagnostics allow any
    # finite score. A minimum learned on C gives the deployable capped policy.
    keys=np.asarray(keys)
    eligible=np.flatnonzero(queries & (a!=b) & np.isfinite(score) & (score>minimum))
    ordered=eligible[np.lexsort((keys[eligible],-score[eligible]))][:limit]
    out=a.copy()
    out[ordered]=b[ordered]
    return out,ordered


def self_test():
    rng=np.random.default_rng(211)
    p=rng.dirichlet(np.ones(7),360)
    q=rng.dirichlet(np.ones(7),size=(3,2,360))
    x,a,b=features(p,q,"CF")
    z,aa,bb=features(p,q,"SHAM_CF")
    np.testing.assert_array_equal(a,aa)
    np.testing.assert_array_equal(b,bb)
    np.testing.assert_array_equal(x[:,:-2],z[:,:-2])
    y=np.arange(360)%7
    model=fit(x,a,b,y)
    scores,_=risk(x,model,a,b)
    ids=np.array([f"u{i:04d}" for i in range(len(p))])
    allowed=np.arange(len(p))%2==0
    pred,use=choose_actions(a,b,scores,ids,allowed,2)
    assert len(use)==2 and np.all(allowed[use]) and np.count_nonzero(pred!=a)==2
    np.testing.assert_array_equal(choose_actions(a,b,scores,ids,allowed,0)[0],a)
    unchanged=features(p,np.stack((q[0],q[0],q[0])),"CF")
    np.testing.assert_array_equal(unchanged[0][:,-2:],0.)
    print("P11 routing core PASS (paired candidates, outcome fit, placebo, fixed action cap, fallback)")


if __name__=="__main__":
    self_test()
