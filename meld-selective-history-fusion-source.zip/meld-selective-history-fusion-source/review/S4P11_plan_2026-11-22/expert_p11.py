"""Frozen Gemma 3 label scores on keyed MELD text. This entry never reads labels."""
import argparse
import hashlib
import json
from pathlib import Path
import time

import mlx.core as mx
import numpy as np
from mlx_vlm.utils import load_model
from transformers import AutoTokenizer


ROOT = Path(__file__).resolve().parents[2]
MODEL = Path.home() / ".cache/huggingface/hub/models--mlx-community--gemma-3-4b-it-4bit/snapshots/93724907d4ed1745d2fe50baadf3b0b01a65abf2"
LABELS = ("neutral", "surprise", "fear", "sadness", "joy", "disgust", "anger")
ORDERS = (tuple(range(7)), (4, 3, 0, 6, 1, 5, 2))
LETTERS = "ABCDEFG"
VIEWS = ("CURRENT", "HISTORY")
LIMIT = 512


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def prompt(row, view, order):
    choices = "\n".join(f"{letter}. {LABELS[i]}" for letter, i in zip(LETTERS, order, strict=True))
    past = row["history"] if view == "HISTORY" else []
    history = "\n".join(f"Speaker {speaker}: {text}" for speaker, text in past[-4:])
    contextual = f"Earlier turns:\n{history}\n\n" if history else ""
    speaker, target = row["target"]
    return ("Classify the emotion expressed by the target speaker in the target utterance. "
            "Choose the one best answer, even if the words alone are ambiguous. "
            "Use earlier turns if present. Respond with a single answer letter only.\n\n"
            f"{contextual}Target utterance (speaker {speaker}): {target}\n\n{choices}")


def token_ids(tokenizer, row, view, order):
    # Reserve the answer-format suffix. Remove old context before truncating target text.
    copy = dict(row, history=list(row["history"])[-4:])
    while True:
        ids = tokenizer.apply_chat_template([{"role":"user","content":prompt(copy,view,order)}],
                                            tokenize=True, add_generation_prompt=True,
                                            return_dict=False)
        if len(ids) <= LIMIT:
            return ids
        if view != "HISTORY" or not copy["history"]:
            raise ValueError(f"oversized target prompt: {row['id']}")
        copy["history"].pop(0)


def alternative_tokens(tok):
    groups = []
    for letter in LETTERS:
        options = {x[0] for char in (letter, " "+letter)
                   if len(x := tok.encode(char, add_special_tokens=False)) == 1}
        if not options:
            raise ValueError(f"missing single-token option {letter}")
        for i in options:
            assert tok.decode([i]).strip()==letter
        groups.append(tuple(sorted(options)))
    assert sum(len(g) for g in groups)==len(set().union(*map(set,groups)))
    return groups


def frozen_logits(model, tokenizer, seqs):
    # Right padding cannot affect any selected final real position in a causal model.
    width = max(map(len, seqs))
    padded = [s + [tokenizer.pad_token_id]*(width-len(s)) for s in seqs]
    hidden = model.language_model.model(mx.array(padded))
    head = model.language_model.lm_head
    rows = hidden[mx.arange(len(seqs)), mx.array([len(s)-1 for s in seqs]), :]
    logits = head(rows).astype(mx.float32)
    mx.eval(logits)
    return np.array(logits, dtype=np.float32)


def answer_probs(logits, groups):
    totals = np.column_stack([np.logaddexp.reduce(logits[:, g].astype(float), axis=1) for g in groups])
    return np.exp(totals-np.logaddexp.reduce(totals, axis=1, keepdims=True))


def infer(rows, model_dir=MODEL, batch=12):
    if not model_dir.is_dir():
        raise ValueError("pinned local model missing")
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True, trust_remote_code=False)
    model = load_model(model_dir, lazy=False)
    model.eval()
    groups = alternative_tokens(tokenizer)
    cases = [(v, j, ix, token_ids(tokenizer, row, v, order))
             for v in VIEWS for j, order in enumerate(ORDERS) for ix, row in enumerate(rows)]
    # Sorting by length only changes compute packing. Put each answer back in its fixed slot.
    cases.sort(key=lambda item: len(item[3]))
    out = np.empty((2, 2, len(rows), 7), dtype=np.float64)
    lengths = np.empty((2, 2, len(rows)), dtype=np.int64)
    probe = sorted(cases, key=lambda item:len(item[3]))
    short, long = probe[0][3],probe[-1][3]
    delta = np.max(np.abs(answer_probs(frozen_logits(model,tokenizer,[short]),groups)[0] -
                          answer_probs(frozen_logits(model,tokenizer,[short,long]),groups)[0]))
    if delta>0.008:
        raise ValueError(f"short-in-batch probability mismatch {delta}")
    for start in range(0,len(cases),batch):
        chunk = cases[start:start+batch]
        letter_probs = answer_probs(frozen_logits(model,tokenizer,[r[3] for r in chunk]),groups)
        for (view,j,row,ids), probs in zip(chunk,letter_probs,strict=True):
            out[VIEWS.index(view),j,row,list(ORDERS[j])] = probs
            lengths[VIEWS.index(view),j,row] = len(ids)
    assert np.isfinite(out).all() and np.allclose(out.sum(axis=-1),1,atol=1e-12,rtol=0)
    return out,lengths,dict(label_token_ids=groups,short_batch_diff=float(delta))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--batch",type=int,default=12)
    args=parser.parse_args()
    raw=json.loads(args.input.read_bytes())
    assert raw["scope"] in ("pilot_train", "long_train", "historical_dev", "synthetic"), "bad split"
    rows=raw["rows"]
    ids=[r["id"] for r in rows]
    assert len(set(ids))==len(ids)>0
    for row in rows:
        assert set(row)=={"id","history","target"}, "non-text fields supplied to expert"
    start=time.monotonic()
    scores,lengths,details=infer(rows,batch=args.batch)
    with args.output.open("xb") as stream:
        np.savez_compressed(stream,keys=np.array(ids),probabilities=scores,token_lengths=lengths)
    print(json.dumps(dict(input_sha=digest(args.input),output_sha=digest(args.output),
                          checkpoint_sha=digest(MODEL/"model.safetensors"), seconds=time.monotonic()-start,
                          cases=int(scores.shape[0]*scores.shape[1]*scores.shape[2]),rows=len(ids), **details)))


if __name__=="__main__":
    main()
