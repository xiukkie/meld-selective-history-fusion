#!/usr/bin/env python3
"""S4-P11 long experiment orchestration.

One process runs the fixed stage order:
source -> check -> export -> expert -> fit -> blind -> replay -> score -> audit.

Labels for train H / dev / IEMOCAP Ses04 are opened only in `score`, after every
blind package is sealed. The pilot replay runs after sealing (it re-scores the
pilot's own already-sealed artifacts). Expert inference runs as separate MLX
subprocesses per shard with key-bound resume.
"""
import argparse
import csv
import hashlib
import json
import math
import pickle
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "review/S4P9_plan_2026-11-22"))
sys.path.insert(0, str(ROOT))
import router_core_p11 as rc  # noqa: E402
import run_p9 as p9  # noqa: E402

RUNS = ROOT / "review/S4P11_2026-11-22"
P5RUN = ROOT / "review/S4P5_2026-11-21/run_20261121T093646"
P10RUN = ROOT / "review/S4P10_2026-11-22/run_20261122T035255fZ"
PILOT = ROOT / "review/S4P11_2026-11-22/pilot_20261122T0419Z"
MLXPY = HERE / ".pilot_env/bin/python"
EXPERT_FULL = HERE / "expert_full_p11.py"          # frozen original (byte-preserved)
EXPERT_B1 = HERE / "expert_full_p11_b1.py"         # documented batch-1 adaptation, used for runs
VENV_PY = ROOT / ".venv/bin/python"

SEEDS = (73, 101, 2026)
FOLDS = (0, 1, 2)
CLASSES = ("neutral", "surprise", "fear", "sadness", "joy", "disgust", "anger")
IEMO = ("happy", "sad", "neutral", "angry", "excited", "frustrated")
IEMO_ROLE_SALT = "S4-P11|iemocap|20261122|"
SALT = "S4P11-sham-v1"
BLEND = (0.875, 0.125)
C_MENU = (0.0, 0.125, 0.25, 0.5, 1.0)
TAU_MENU = (float("-inf"), -0.05, 0.0, 0.05, 0.10, float("inf"))
QB = (0.10, 0.20, 0.35)
AB = (0.01, 0.02, 0.04)
MAIN_QB, MAIN_AB = 0.20, 0.02
BOOT_DRAWS, BOOT_SEED = 2000, 2026112212
SHARD_ROWS = 200
DEV_REF_WF1 = 65.7800028361
ANCHOR_REF_WF1 = 64.9749197348
FS_N = {"fs": (2118, 2101, 2287), "c": (514, 414, 411), "h": (762, 727, 655)}
LEARNED = ("ORDINARY", "SHAM_CF", "CF")
QUOTA_ARMS = ("EXPERT_MARGIN", "ORDINARY", "SHAM_CF", "CF", "CF_PROTECTED")
FIXED_ARMS = ("FIXED_CURRENT", "FIXED_HISTORY", "FIXED_SHAM")
H_ENDS = ("SOURCE", "FIXED_CURRENT", "FIXED_HISTORY", "FIXED_SHAM", "HARD_EXPERT",
          "C_BLEND", "EXPERT_MARGIN", "ORDINARY", "SHAM_CF", "CF", "CF_PROTECTED")
DEV_ENDS = ("SOURCE", "FIXED_HISTORY", "C_BLEND", "CF", "CF_PROTECTED")
MECHANISM_PAIRS = (("CF", "SHAM_CF"), ("CF", "ORDINARY"), ("CF", "FIXED_HISTORY"),
                   ("SHAM_CF", "FIXED_SHAM"), ("FIXED_HISTORY", "FIXED_CURRENT"),
                   ("FIXED_HISTORY", "FIXED_SHAM"), ("C_BLEND", "SOURCE"),
                   ("CF_PROTECTED", "CF"), ("EXPERT_MARGIN", "ORDINARY"),
                   ("FIXED_HISTORY", "SOURCE"), ("C_BLEND", "FIXED_HISTORY"))

MODEL_SNAP = Path.home() / (".cache/huggingface/hub/models--mlx-community--gemma-3-4b-it-4bit/"
                            "snapshots/93724907d4ed1745d2fe50baadf3b0b01a65abf2")
MODEL_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"

_C1 = None
_SOURCES = None
_IEMO_TEXTS = None
_IEMO_DATA = None


def sources():
    global _SOURCES
    if _SOURCES is None:
        _SOURCES = p9.load_sources()
    return _SOURCES


def c1_lock():
    global _C1
    if _C1 is None:
        _C1 = sources()[-1]
    return _C1


# ---------------------------------------------------------------- ledger utils

def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    return sha_bytes(Path(path).read_bytes())


def dump(path, payload):
    path = Path(path)
    data = (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            + "\n").encode()
    if path.exists():
        if path.read_bytes() == data:
            return sha_bytes(data)
        raise ValueError(f"dump target exists with different content: {path}")
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)
    return sha_bytes(data)


def jload(path):
    return json.loads(Path(path).read_bytes())


def event(run, name, **fields):
    with (run / "attempts.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),
                                     event=name, **fields), default=str) + "\n")


def require(flag, details):
    if not flag:
        raise ValueError(details)


def save_npz(path, **fields):
    with Path(path).open("xb") as stream:
        np.savez_compressed(stream, **fields)


def read_npz(path, digest=None):
    raw = Path(path).read_bytes()
    if digest is not None:
        require(sha_bytes(raw) == digest, f"npz digest mismatch: {path}")
    with np.load(__import__("io").BytesIO(raw), allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def rss_gib():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**30  # macOS reports bytes


def wf1_cm(cm):
    support = cm.sum(-1)
    denom = support + cm.sum(-2)
    f1 = np.divide(2 * np.diagonal(cm, axis1=-2, axis2=-1), denom,
                   out=np.zeros_like(support, float), where=denom > 0)
    return (f1 * support).sum(-1) / support.sum(-1)


def cm_of(y, pred, n_cls):
    return np.bincount(n_cls * np.asarray(y) + np.asarray(pred),
                       minlength=n_cls * n_cls).reshape(n_cls, n_cls)


def diag(y, pred, base, n_cls):
    ch = np.asarray(pred) != np.asarray(base)
    y = np.asarray(y)
    fix = ch & (pred == y)
    harm = ch & (base == y)
    cm = cm_of(y, pred, n_cls)
    f1 = np.diagonal(cm) / np.maximum(cm.sum(0) + cm.sum(1), 1)
    return dict(n=int(len(y)), wf1_pct=float(100 * wf1_cm(cm)), accuracy_pct=float(100 * np.mean(pred == y)),
                macro_f1_pct=float(100 * f1.mean()), class_f1_pct=np.round(100 * f1, 4).tolist(),
                changes=int(ch.sum()), fixes=int(fix.sum()), harms=int(harm.sum()),
                wrong_to_wrong=int(ch.sum() - fix.sum() - harm.sum()), net=int(fix.sum() - harm.sum()))


def code_lock():
    return {p.name: file_sha(p) for p in
            (Path(__file__), HERE / "router_core_p11.py", HERE / "expert_full_p11.py",
             HERE / "expert_full_p11_b1.py", HERE / "expert_p11.py", HERE / "recheck_p11.py")}


# ---------------------------------------------------------------- stage source

def load_train_full():
    """p9.load_train verified S/C/H; add the F+S fit pool from the same verified sources."""
    sets, classes, c1 = p9.load_train()
    require(classes == CLASSES, "class order drift")
    old, binding, weights, fold_file, c1b = p9.load_sources()
    require(c1b == c1, "c1 identity drift")
    roles = p9.verified_json(p9.ROLES, p9.ROLES_SHA)["roles"]
    keys, off, did = old.geometry(binding, "train")
    frames = {}
    for f in FOLDS:
        fold_ids = set(fold_file["folds"][str(f)])
        fs_dlgs = sorted(set(roles[str(f)]["F"]) | set(roles[str(f)]["S"]))
        require(len(fs_dlgs) == 226, f"FS dialogue count fold {f}")
        fold_sel = np.isin(did, list(fold_ids))
        fold_keys, fold_off, fold_did = keys[fold_sel], off[fold_sel], did[fold_sel]
        fs_mask = np.isin(fold_did, [int(d) for d in fs_dlgs])
        require(int(fs_mask.sum()) == FS_N["fs"][f], f"FS rows fold {f}: {int(fs_mask.sum())}")
        for seed in SEEDS:
            unit = f"{seed}_{f}"
            src = old.P1 / "anchors" / f"train_{unit}"
            parent = jload(src.with_suffix(".json"))
            require(parent["sha"] == old.OOF_ANCHORS[unit] and parent["split"] == "train"
                    and parent["classes"] == list(CLASSES), f"anchor provenance {unit}")
            p_fold = old.align_anchor(src.with_suffix(".npz"), old.OOF_ANCHORS[unit],
                                      fold_keys, fold_off)
            frames[unit] = dict(
                fs=dict(keys=fold_keys[fs_mask], official=fold_off[fs_mask],
                        did=fold_did[fs_mask], p=p_fold[fs_mask]),
                c=sets[unit]["C"], h=sets[unit]["H"])
    for f in FOLDS:
        for role, n in FS_N.items():
            got = len(frames[f"73_{f}"][role]["keys"])
            require(got == n[f], f"role rows {role} fold {f}: {got} != {n[f]}")
    return frames


def source_stage(run):
    t0 = time.perf_counter()
    event(run, "source_start")
    frames = load_train_full()
    dev_sets, _, c1d = p9.load_dev()
    require(c1d == c1_lock(), "C1 lock identity drift")
    anchor_npz = P10RUN / "dev_fold_anchors.npz"
    require(file_sha(anchor_npz) == "73dbe17b0a72df31166b867598916c9bb8d4fafff8244dd57dba216fcd41fb10",
            "dev_fold_anchors.npz SHA drift (S4-P10 fit_manifest bound value)")
    anchor_z = read_npz(anchor_npz)
    anchor_p0 = {}
    for seed in SEEDS:
        p0 = np.mean([np.exp(anchor_z[f"{seed}_{f}_lp"].astype(float)) for f in FOLDS], axis=0)
        require(p0.shape == (1109, 7) and np.isfinite(p0).all()
                and np.allclose(p0.sum(1), 1, atol=2e-6, rtol=0), f"anchor p0 invalid {seed}")
        anchor_p0[str(seed)] = p0
    p5_pred = {}
    for seed in SEEDS:
        side = jload(P5RUN / "pred/iemocap" / f"anchor_dev_{seed}_0.json")
        npz = P5RUN / "pred/iemocap" / f"anchor_dev_{seed}_0.npz"
        ckpt = P5RUN / "fits/iemocap" / f"anchor_{seed}" / "last.pt"
        require(side["provenance"]["checkpoint_sha"] == file_sha(ckpt), f"iemocap anchor ckpt drift {seed}")
        require(side["npz_sha256"] == file_sha(npz), f"iemocap anchor npz drift {seed}")
        z = read_npz(npz, side["npz_sha256"])
        require(z["keys"].shape == (1512,) and z["p"].shape == (1512, 6), f"iemocap anchor shape {seed}")
        require(np.allclose(np.exp(z["lp"].astype(float)), z["p"].astype(float), atol=2e-6, rtol=0),
                f"iemocap anchor p/lp drift {seed}")
        p5_pred[str(seed)] = dict(keys=z["keys"], p=z["p"].astype(float), lp=z["lp"].astype(float),
                                  checkpoint_sha=side["provenance"]["checkpoint_sha"])
    pilot_lock = jload(PILOT / "input_lock.json")
    require(pilot_lock["text_sha"] == file_sha(PILOT / "blind_text.json"), "pilot text sha drift")
    require(jload(PILOT / "expert_run.json")["output_sha"] == file_sha(PILOT / "expert_scores.npz"),
            "pilot expert npz sha drift")
    require(jload(PILOT / "expert_run.json")["checkpoint_sha"] == MODEL_SHA, "pilot model sha drift")
    pilot_keys = {}
    for role in ("C", "H"):
        keys = []
        for f in FOLDS:
            tab = pilot_lock["tables"][f"{role}_{f}"]
            keys.extend(tab["keys"][i] for i in tab["indices"])
        pilot_keys[role] = keys
    require(len(pilot_keys["C"]) == 96 and len(pilot_keys["H"]) == 180, "pilot key count drift")
    for name in ("train", "dev"):
        digest = c1_lock()["protected"][f"third_party/MELD/data/MELD/{name}_sent_emo.csv"]
        require(file_sha(ROOT / f"third_party/MELD/data/MELD/{name}_sent_emo.csv") == digest,
                f"MELD {name} csv sha drift")
    pkl_sha = jload(P5RUN / "evidence/bc_manifest_iemocap.json")["external_locks"]["iemocap_pkl"]
    require(file_sha(ROOT / "data/features/m3net/IEMOCAP_features.pkl") == pkl_sha,
            "IEMOCAP pkl sha drift")
    record = dict(
        code=code_lock(), model_snapshot=str(MODEL_SNAP), model_weights_sha=MODEL_SHA,
        seeds=list(SEEDS), folds=list(FOLDS), query_budgets=list(QB), action_budgets=list(AB),
        main_query=MAIN_QB, main_action=MAIN_AB, blend=list(BLEND),
        c_menu=list(C_MENU), tau_menu=[t if math.isfinite(t) else ("inf" if t > 0 else "-inf")
                                       for t in TAU_MENU],
        bootstrap=dict(draws=BOOT_DRAWS, seed=BOOT_SEED, unit="dialogue"),
        expected=dict(FS_N={k: list(v) for k, v in FS_N.items()},
                      c1_dev_wf1_pct=DEV_REF_WF1, anchor_dev_wf1_pct=ANCHOR_REF_WF1,
                      pilot_query_n=dict(C=96, H=180)),
        p1_oof_anchor_shas={u: old_OOF(u) for u in (f"{s}_{f}" for s in SEEDS for f in FOLDS)},
        dev_fold_anchors_sha=file_sha(anchor_npz),
        iemocap_anchor_checkpoint_shas={str(s): p5_pred[str(s)]["checkpoint_sha"] for s in SEEDS},
        iemocap_anchor_dev_npz_shas={str(s): jload(P5RUN / "pred/iemocap" / f"anchor_dev_{s}_0.json")["npz_sha256"]
                                     for s in SEEDS},
        iemocap_pkl_sha=pkl_sha,
        meld_csv_shas={n: c1_lock()["protected"][f"third_party/MELD/data/MELD/{n}_sent_emo.csv"]
                       for n in ("train", "dev")},
        pilot=dict(dir=str(PILOT), text_sha=pilot_lock["text_sha"],
                   expert_npz_sha=jload(PILOT / "expert_run.json")["output_sha"],
                   c_lock=jload(PILOT / "c_lock.json"), keys=pilot_keys),
    )
    digest = dump(run / "source_lock.json", record)
    event(run, "source_complete", sha=digest, units=len(frames), rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return record, frames, dev_sets, anchor_p0, p5_pred


def old_OOF(unit):
    old, *_ = sources()
    return old.OOF_ANCHORS[unit]


# ---------------------------------------------------------------- text builders

def meld_text():
    """Text per canonical key for train+dev; per-dialogue anonymized speakers, 400-char cap."""
    text = {}
    for split in ("train", "dev"):
        name = f"third_party/MELD/data/MELD/{split}_sent_emo.csv"
        raw = p9.verified_bytes(ROOT / name, c1_lock()["protected"][name])
        tx = {}
        for row in csv.DictReader(StringIO(raw.decode("utf-8-sig"))):
            tx[(int(row["Dialogue_ID"]), int(row["Utterance_ID"]))] = (
                row["Speaker"], " ".join(row["Utterance"].split())[:400])
        _, b, *_ = sources()
        for group in b[split].values():
            official = [tuple(map(int, k)) for k in group["official"]]
            speaker_id, preceding = {}, []
            for key, canon in zip(official, group["utterance_keys"], strict=True):
                speaker, utterance = tx[key]
                anonymous = speaker_id.setdefault(speaker, len(speaker_id) + 1)
                target = [anonymous, utterance]
                text[canon] = dict(id=canon, history=preceding[-4:], target=target)
                preceding.append(target)
    require(len(text) == 9989 + 1109, f"MELD text size {len(text)}")
    return text


def iemo_text():
    """Session 3/4 texts from the verified released package.

    Only speaker ids and sentence text fields are selected; Session 5 dialogues are
    never returned by the loader. The shared pkl is physically decoded once
    (recorded limitation inherited from S4-P5)."""
    global _IEMO_TEXTS, _IEMO_DATA
    if _IEMO_TEXTS is not None:
        return _IEMO_TEXTS, _IEMO_DATA
    sys.path.insert(0, str(P5RUN))
    import s5core as S5
    data = S5.load_iemocap()
    out = {}
    for bucket, session in (("roles", "Ses03"), ("dev", "Ses04")):
        text = {}
        for d in sorted(data[bucket], key=lambda x: x.official_dialogue_id):
            spk, preceding = {}, []
            for i, key in enumerate(d.utterance_ids):
                anonymous = spk.setdefault(int(d.speaker_ids[i]), len(spk) + 1)
                target = [anonymous, d.iemocap_texts[i]]
                text[key] = dict(id=key, history=preceding[-4:], target=target)
                preceding.append(target)
            require(all(k.startswith(session) for k in text), f"{session} key mismatch")
        out[session] = text
    _IEMO_TEXTS, _IEMO_DATA = out, data
    return out, data


def iemo_anchor_inference(run, data):
    """Label-free anchor forwards on Ses03 (fit roles) and Ses04 (binding check)."""
    import torch
    sys.path.insert(0, str(P5RUN))
    import s5core as S5
    t0 = time.perf_counter()
    event(run, "iemo_anchor_forward_start", device="cpu", sessions=("Ses03", "Ses04"))
    ses03 = sorted(data["roles"], key=lambda d: d.official_dialogue_id)
    ses04 = sorted(data["dev"], key=lambda d: d.official_dialogue_id)
    order_fit = sorted(range(len(ses03)),
                       key=lambda i: (hashlib.sha256(f"{IEMO_ROLE_SALT}{ses03[i].official_dialogue_id}"
                                                     .encode()).hexdigest(), ses03[i].official_dialogue_id))
    fs_dlgs = [ses03[i] for i in order_fit[:20]]
    c_dlgs = [ses03[i] for i in order_fit[20:]]
    fs_keys = [k for d in fs_dlgs for k in d.utterance_ids]
    c_keys = [k for d in c_dlgs for k in d.utterance_ids]
    fs_did = [d.official_dialogue_id for d in fs_dlgs for _ in d.utterance_ids]
    c_did = [d.official_dialogue_id for d in c_dlgs for _ in d.utterance_ids]
    s4_did = [d.official_dialogue_id for d in ses04 for _ in d.utterance_ids]
    require(len(fs_keys) + len(c_keys) == 1569 and len(s4_did) == 1512, "iemocap row counts")
    fields = dict(keys=np.array(fs_keys + c_keys), fs_n=np.array([len(fs_keys)]),
                  fs_did=np.array(fs_did), c_did=np.array(c_did), s4_did=np.array(s4_did))
    check = {}
    for seed in SEEDS:
        ckpt = P5RUN / "fits/iemocap" / f"anchor_{seed}" / "last.pt"
        model = S5.mmdfn_model("iemocap")
        cp = torch.load(ckpt, weights_only=True)
        model.load_state_dict(cp["state"])
        lp03 = S5.anchor_forward(model, ses03).numpy().astype(np.float64)
        lp04 = S5.anchor_forward(model, ses04).numpy().astype(np.float64)
        require(lp03.shape == (1569, 6) and lp04.shape == (1512, 6), f"iemocap forward shape {seed}")
        fields[f"lp_{seed}"] = lp03
        stored = read_npz(P5RUN / "pred/iemocap" / f"anchor_dev_{seed}_0.npz")
        by_key = {str(k): i for i, k in enumerate(stored["keys"])}
        idx = [by_key[str(k)] for k in (u for d in ses04 for u in d.utterance_ids)]
        delta = float(np.max(np.abs(np.exp(lp04) - stored["p"].astype(float)[idx])))
        agree = float(np.mean(lp04.argmax(1) == lp04[idx].argmax(1))) if False else \
            float(np.mean(lp04.argmax(1) == stored["lp"].astype(float)[idx].argmax(1)))
        check[str(seed)] = dict(max_abs_p_diff=delta, argmax_agreement=agree,
                                checkpoint_sha=file_sha(ckpt))
        require(delta <= 2e-5 and agree == 1.0, f"iemocap anchor re-inference drift {seed}: {delta}")
        event(run, "iemo_anchor_checked", seed=seed, max_abs_p_diff=delta)
    save_npz(run / "export" / "iemocap_anchor_ses03.npz", **fields)
    dump(run / "export" / "iemocap_anchor_check.json", check)
    event(run, "iemo_anchor_forward_done", seconds=round(time.perf_counter() - t0, 3))
    return dict(fs_keys=fs_keys, c_keys=c_keys, fs_did=fs_did, c_did=c_did, s4_did=s4_did)


# ---------------------------------------------------------------- donors & queues

def margin(p):
    s = np.sort(p, axis=1)
    return s[:, -1] - s[:, -2]


def queue_order(keys, p):
    return np.lexsort((np.asarray(keys), margin(p)))


def word_count(text):
    return len(text.split())


def pool_dialog_rows(keys, did_of, pos_of):
    """Ordered (dialogue -> [row indices]) for window construction. pos_of gives the
    within-dialogue position (numeric for MELD, dialogue-object order for IEMOCAP);
    lexical key order would misorder utterance ::10 before ::2."""
    order = {}
    for i, key in enumerate(keys):
        order.setdefault(did_of[i], []).append(i)
    for dlg in order:
        order[dlg] = sorted(order[dlg], key=lambda i: pos_of[i])
    return order


def build_donors(pool_keys, pool_dlg, pool_rows, targets, pool_pos):
    """targets: list of (key, history[(spk,text)...], own_dlg).

    Candidate windows: n real utterances immediately preceding some utterance of
    another dialogue in the same pool. Minimum summed per-sentence word-count
    difference; ties by SHA(target key | candidate window end key | SALT)."""
    dlg_order = pool_dialog_rows(pool_keys, pool_dlg, pool_pos)
    windows = {}
    for n in range(1, 5):
        cand = []
        for dlg, members in dlg_order.items():
            for end in range(n, len(members)):
                rows_idx = [members[end - n + t] for t in range(n)]
                cand.append((dlg, rows_idx, pool_keys[members[end - 1]]))
        windows[n] = cand
    out = {}
    for key, hist, own_dlg in targets:
        n = len(hist)
        if n == 0:
            out[key] = dict(donor=None, window_len=0, length_diffs=[], donor_texts=[])
            continue
        best = None
        for dlg, rows_idx, cand_key in windows[n]:
            if dlg == own_dlg:
                continue
            diff = sum(abs(word_count(hist[t][1]) - word_count(pool_rows[rows_idx[t]]["target"][1]))
                       for t in range(n))
            tie = hashlib.sha256(f"{key}|{cand_key}|{SALT}".encode()).hexdigest()
            if best is None or (diff, tie) < best[0]:
                best = ((diff, tie), rows_idx, cand_key, dlg)
        require(best is not None, f"no donor for {key} n={n} pool_size={len(pool_keys)}")
        (_, _), rows_idx, cand_key, dlg = best
        out[key] = dict(donor=dict(dialogue=str(dlg), end_key=str(cand_key)), window_len=int(n),
                        length_diffs=[int(abs(word_count(hist[t][1]) -
                                              word_count(pool_rows[rows_idx[t]]["target"][1])))
                                      for t in range(n)],
                        donor_texts=[pool_rows[j]["target"][1] for j in rows_idx])
    return out


# ---------------------------------------------------------------- stage check

def run_expert_subprocess(inp, out_npz, batch=1):
    """Long-run expert entry: the documented batch-1 adaptation (solo forwards).

    The frozen original refuses real MELD data because its 0.008 same-batch probe is
    unreachable for content-invariant batch-shape noise on scope-minimum rows
    (measured 0.01392 at every tail width 100-263 for meld_d1100::0). Batch 1 removes
    co-batching entirely; the b1 entry keeps a recorded legacy probe and adds a
    content-invariance guard. See expert_full_p11_b1.py header."""
    return subprocess.run([str(MLXPY), str(EXPERT_B1), str(inp), str(out_npz), "--batch", "1"],
                          capture_output=True, text=True, cwd=str(ROOT), env=EXPERT_ENV)


EXPERT_ENV = {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "PYTHONDONTWRITEBYTECODE": "1",
              "OPENBLAS_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "OMP_NUM_THREADS": "1",
              "PATH": "/usr/bin:/bin:/usr/local/bin"}


def check_stage(run, record):
    t0 = time.perf_counter()
    event(run, "check_start")
    check_dir = run / "check"
    check_dir.mkdir(exist_ok=True)
    result = {}
    proc = subprocess.run([str(VENV_PY), str(HERE / "router_core_p11.py")],
                          capture_output=True, text=True, cwd=str(ROOT))
    require(proc.returncode == 0 and "PASS" in proc.stdout, f"router core self-test failed:\n{proc.stderr}")
    result["router_core_self_test"] = proc.stdout.strip().splitlines()[-1]

    # synthetic end-to-end through both expert entries, both class spaces
    synthetic = []
    for name, n_cls, classes, infile in (("synthetic", 7, CLASSES, "synthetic_full.json"),
                                         ("synthetic_iemocap", 6, IEMO, "synthetic_iemocap.json")):
        out = check_dir / f"{name}_scores.npz"
        proc = run_expert_subprocess(HERE / infile, out)
        require(proc.returncode == 0, f"synthetic expert failed {name}:\n{(proc.stderr or '')[-800:]}")
        payload = json.loads(proc.stdout.strip().splitlines()[-1])
        require(payload["checkpoint_sha"] == MODEL_SHA, "synthetic checkpoint sha drift")
        require(payload.get("batch_mode") == 1 and payload.get("content_invariance") == "pass",
                f"b1 guard drift {name}")
        z = read_npz(out, payload["output_sha"])
        require([str(c) for c in z["classes"]] == list(classes), f"synthetic class order {name}")
        require([str(v) for v in z["views"]] == ["CURRENT", "HISTORY", "SHAM"], "synthetic views")
        require(z["probabilities"].shape[3] == n_cls and abs(z["probabilities"].sum(-1).max() - 1) < 1e-9,
                f"synthetic probabilities {name}")
        # frozen original entry (batch 4) for cross-entry equivalence on synthetic rows
        out_orig = check_dir / f"{name}_scores_orig.npz"
        proc2 = subprocess.run([str(MLXPY), str(EXPERT_FULL), str(HERE / infile), str(out_orig),
                                "--batch", "4"], capture_output=True, text=True, cwd=str(ROOT),
                               env=EXPERT_ENV)
        require(proc2.returncode == 0, f"frozen-entry synthetic failed {name}:\n{(proc2.stderr or '')[-600:]}")
        payload2 = json.loads(proc2.stdout.strip().splitlines()[-1])
        z2 = read_npz(out_orig, payload2["output_sha"])
        require([str(k) for k in z2["keys"]] == [str(k) for k in z["keys"]], "synthetic key order")
        cross_diff = float(np.max(np.abs(z["probabilities"] - z2["probabilities"])))
        # b1 = solo forwards; frozen = batch 4. The difference IS co-batching shape
        # noise (content-invariant), which can reach O(0.1) on flat near-tied letter
        # distributions. Semantic gates: confident rows (max prob >= 0.9) must not
        # flip class, overall argmax agreement must stay high; raw diffs reported.
        confident_a = z["probabilities"].max(-1) >= 0.9
        confident_b = z2["probabilities"].max(-1) >= 0.9
        flips = ((z["probabilities"].argmax(-1) != z2["probabilities"].argmax(-1)) &
                 (confident_a | confident_b))
        agree = float((z["probabilities"].argmax(-1) == z2["probabilities"].argmax(-1)).mean())
        require(not flips.any(), f"b1 vs frozen entry flipped a confident synthetic row: {int(flips.sum())}")
        require(agree >= 0.75, f"b1 vs frozen entry argmax agreement {agree:.3f}")
        synthetic.append(dict(name=name, rows=int(len(z["keys"])), calls=payload["calls"],
                              seconds=round(payload["seconds"], 3),
                              legacy_probe=payload["legacy_batch_probe_max_delta"],
                              frozen_entry_probe=payload2["batch_probe_max_delta"],
                              b1_vs_frozen_max_diff=cross_diff,
                              b1_vs_frozen_argmax_agreement=agree,
                              confident_flips=int(flips.sum())))
    result["synthetic"] = synthetic

    # negative gates on synthetic fixtures
    negatives = {}
    rng = np.random.default_rng(7)
    p = rng.dirichlet(np.ones(7), 12)
    q = rng.dirichlet(np.ones(7), size=(3, 2, 12))
    try:
        rc.features(p * 7.0, q, "CF")  # logits-scale p must be rejected
        negatives["prob_as_logits_rejected"] = False
    except ValueError:
        negatives["prob_as_logits_rejected"] = True
    # tampered expert npz (swapped row keys / swapped class axis) must be rejected at binding
    z0 = read_npz(check_dir / "synthetic_scores.npz")
    shard0 = dict(index=999, scope="synthetic", rows=int(len(z0["keys"])),
                  keys=[str(k) for k in z0["keys"]][::-1])
    try:
        _verify_expert_npz(z0, shard0)
        negatives["swapped_key_table_rejected"] = False
    except ValueError:
        negatives["swapped_key_table_rejected"] = True
    tam = {k: (v[::-1].copy() if k == "classes" else v) for k, v in z0.items()}
    shard0 = dict(index=999, scope="synthetic", rows=int(z0["keys"].shape[0]),
                  keys=[str(k) for k in z0["keys"]])
    try:
        _verify_expert_npz(dict(tam), shard0)
        negatives["swapped_class_order_rejected"] = False
    except ValueError:
        negatives["swapped_class_order_rejected"] = True
    a = p.argmax(1)
    b = a.copy()
    pred, used = rc.choose_actions(a, b, np.arange(12.0), np.array([f"u{i}" for i in range(12)]),
                                   np.ones(12, bool), 5)
    negatives["same_candidate_never_flip"] = bool(len(used) == 0 and np.all(pred == a))
    a2 = p.argmax(1); b2 = (a2 + 1) % 7
    pred2, used2 = rc.choose_actions(a2, b2, np.arange(12.0), np.array([f"u{i}" for i in range(12)]),
                                     np.ones(12, bool), 5)
    negatives["flip_only_eligible_rows"] = bool(len(used2) == 5 and np.all(pred2[used2] == b2[used2])
                                                and np.all(pred2[~np.isin(np.arange(12), used2)] == a2[~np.isin(np.arange(12), used2)]))
    try:
        build_donors(["meld_d0001::0", "meld_d0001::1"], ["meld_d0001", "meld_d0001"],
                     [dict(target=[1, "x"]), dict(target=[1, "y"])],
                     [("meld_d0001::1", [(1, "hi")], "meld_d0001")], [0, 1])
        negatives["sham_same_dialogue_rejected"] = False
    except ValueError:
        negatives["sham_same_dialogue_rejected"] = True
    # fold out-of-range: unknown unit id has no frames entry
    negatives["fold_out_of_range_rejected"] = "73_3" not in {f"{s}_{f}" for s in SEEDS for f in FOLDS}
    # empty history => identical expert input text for CURRENT and HISTORY views (MLX env probe)
    probe = subprocess.run(
        [str(MLXPY), "-c",
         "import json,sys;sys.path.insert(0,'%s');from expert_p11 import prompt,LABELS;"
         "r={'id':'probe','history':[],'target':[1,'I am fine today.']};"
         "a=prompt(r,'CURRENT',tuple(range(7)));b=prompt(r,'HISTORY',tuple(range(7)));"
         "print('SAME' if a==b else 'DIFF')" % HERE],
        capture_output=True, text=True, cwd=str(ROOT), env=EXPERT_ENV)
    require(probe.returncode == 0, f"prompt probe failed: {probe.stderr[-400:]}")
    negatives["empty_history_identical_prompt"] = "SAME" in probe.stdout
    result["negatives"] = negatives
    require(all(v is True for v in negatives.values()),
            f"negative gate failed: {negatives}")
    digest = dump(check_dir / "check_result.json", result)
    event(run, "check_complete", sha=digest, rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return result


# ---------------------------------------------------------------- stage export

def export_stage(run, record, frames, dev_sets, anchor_p0, p5_pred):
    t0 = time.perf_counter()
    event(run, "export_start")
    (run / "export").mkdir(exist_ok=True)
    text = meld_text()
    event(run, "meld_text_built", rows=len(text))
    iemo_texts, iemo_data = iemo_text()
    event(run, "iemocap_text_built", ses03=len(iemo_texts["Ses03"]), ses04=len(iemo_texts["Ses04"]))
    iemo_roles = iemo_anchor_inference(run, iemo_data)

    # ---- pools (full row sets per split/fold/role) for donor matching
    key2dlg, key2pos = {}, {}
    for key, dlg in zip(iemo_roles["fs_keys"], iemo_roles["fs_did"]):
        key2dlg[key] = dlg
    for key, dlg in zip(iemo_roles["c_keys"], iemo_roles["c_did"]):
        key2dlg[key] = dlg
    for key, dlg in zip([str(k) for k in p5_pred["73"]["keys"]], iemo_roles["s4_did"]):
        key2dlg[key] = dlg
    for d in sorted(iemo_data["roles"], key=lambda x: x.official_dialogue_id) + \
            sorted(iemo_data["dev"], key=lambda x: x.official_dialogue_id):
        for i, key in enumerate(d.utterance_ids):
            key2pos[str(key)] = i
    pools = {}
    for fold in FOLDS:
        for role in ("fs", "c", "h"):
            members = []
            for seed in SEEDS:
                part = frames[f"{seed}_{fold}"][role]
                members.extend(str(k) for k in part["keys"])
            pools[f"meld|{fold}|{role}"] = sorted(set(members))
    pools["dev"] = sorted(str(k) for k in dev_sets["73"]["keys"])
    pools["iemo|ses03|FS"] = sorted(iemo_roles["fs_keys"])
    pools["iemo|ses03|C"] = sorted(iemo_roles["c_keys"])
    pools["iemo|ses04"] = sorted(str(k) for k in p5_pred["73"]["keys"])
    for name, members in list(pools.items()):
        if name.startswith("meld") or name == "dev":
            src = {k: text[k] for k in members}
            dlg = [k.split("::")[0] for k in members]
            pos = [int(k.split("::")[1]) for k in members]
        elif name.startswith("iemo|ses03"):
            src = {k: iemo_texts["Ses03"][k] for k in members}
            dlg = [key2dlg[k] for k in members]
            pos = [key2pos[k] for k in members]
        else:
            src = {k: iemo_texts["Ses04"][k] for k in members}
            dlg = [key2dlg[k] for k in members]
            pos = [key2pos[k] for k in members]
        pools[name] = dict(rows=src, keys=members, dlg=dlg, pos=pos)
    event(run, "pools_built", sizes={k: len(v["keys"]) for k, v in pools.items()})

    # ---- queues
    queues = {}
    for unit, parts in frames.items():
        seed, fold = unit.split("_")
        for role in ("fs", "c", "h"):
            part = parts[role]
            o = queue_order(part["keys"], part["p"])
            queues[f"meld|{unit}|{role}"] = dict(keys=[str(k) for k in part["keys"][o]],
                                                 pool=f"meld|{fold}|{role}",
                                                 budgets={b: math.ceil(b * len(part["keys"])) for b in QB})
    for seed in SEEDS:
        for anchor, p in (("c1", dev_sets[str(seed)]["p"]), ("anchor", anchor_p0[str(seed)])):
            o = queue_order(dev_sets[str(seed)]["keys"], p)
            queues[f"dev|{anchor}|{seed}"] = dict(keys=[str(k) for k in dev_sets[str(seed)]["keys"][o]],
                                                  pool="dev",
                                                  budgets={b: math.ceil(b * 1109) for b in QB})
    z03 = read_npz(run / "export" / "iemocap_anchor_ses03.npz")
    for seed in SEEDS:
        p03 = np.exp(z03[f"lp_{seed}"].astype(float))
        keys03 = [str(k) for k in z03["keys"]]
        fs_n = int(z03["fs_n"][0])
        o = queue_order(np.array(keys03[:fs_n]), p03[:fs_n])
        queues[f"iemo|fs|{seed}"] = dict(keys=[keys03[:fs_n][i] for i in o], pool="iemo|ses03|FS",
                                         budgets={0.20: math.ceil(0.20 * fs_n)})
        o = queue_order(np.array(keys03[fs_n:]), p03[fs_n:])
        queues[f"iemo|c|{seed}"] = dict(keys=[keys03[fs_n:][i] for i in o], pool="iemo|ses03|C",
                                        budgets={0.20: math.ceil(0.20 * (1569 - fs_n))})
        p04 = p5_pred[str(seed)]["p"]
        keys04 = [str(k) for k in p5_pred[str(seed)]["keys"]]
        o = queue_order(np.array(keys04), p04)
        queues[f"iemo|s4|{seed}"] = dict(keys=[keys04[i] for i in o], pool="iemo|ses04",
                                         budgets={b: math.ceil(b * 1512) for b in QB})

    # ---- export union (35% eval queues, 20% fit/cal queues, pilot rows via real pools)
    wanted = {}
    for name, q in queues.items():
        upto = max(q["budgets"].values())
        pool = q["pool"]
        for i in range(upto):
            key = q["keys"][i]
            wanted.setdefault(key, set()).add(pool)
    pilot_pool_of = {}
    for role, tag in (("C", "c"), ("H", "h")):
        for f in FOLDS:
            tab = jload(PILOT / "input_lock.json")["tables"][f"{role}_{f}"]
            for i in tab["indices"]:
                pilot_pool_of[tab["keys"][i]] = f"meld|{f}|{tag}"
    for key, pool in pilot_pool_of.items():
        wanted.setdefault(key, set()).add(pool)
    require(all(len(v) == 1 for v in wanted.values()),
            {k: v for k, v in wanted.items() if len(v) != 1})
    event(run, "export_union", unique_rows=len(wanted), pilot_overlap_rows=len(pilot_pool_of),
          pools={k: len(v["keys"]) for k, v in pools.items()})

    # ---- donors (one per pool, over the pool's full row set)
    donors = {}
    for pool_name, pool in pools.items():
        targets = []
        for i, key in enumerate(pool["keys"]):
            hist = [(int(s), t) for s, t in pool["rows"][key]["history"]]
            targets.append((key, hist, pool["dlg"][i]))
        dd = build_donors(pool["keys"], pool["dlg"], [pool["rows"][k] for k in pool["keys"]],
                          targets, pool["pos"])
        for key, entry in dd.items():
            donors[f"{pool_name}|{key}"] = entry
    event(run, "donors_built", entries=len(donors),
          no_hist=sum(1 for v in donors.values() if v["window_len"] == 0),
          hist_len_hist={str(n): sum(1 for v in donors.values() if v["window_len"] == n) for n in range(5)})
    dump(run / "export" / "donors.json", donors)

    # ---- shard payloads
    def scope_of(key):
        if key.startswith("Ses03"):
            return "iemocap_session03"
        if key.startswith("Ses04"):
            return "iemocap_session04"
        return "historical_dev" if key in pools["dev"]["rows"] else "long_train"

    rows_by_scope = {}
    for key in sorted(wanted):
        scope = scope_of(key)
        base = text[key] if scope in ("long_train", "historical_dev") else \
            iemo_texts["Ses03" if scope == "iemocap_session03" else "Ses04"][key]
        pool = sorted(wanted[key])[0]
        entry = donors[f"{pool}|{key}"]
        sham = [] if entry["window_len"] == 0 else [
            [base["history"][k][0], entry["donor_texts"][k]] for k in range(entry["window_len"])]
        row = dict(id=key, target=list(base["target"]),
                   history=[[int(s), t] for s, t in base["history"]],
                   sham_history=[[int(s), t] for s, t in sham])
        require(len(row["history"]) == len(row["sham_history"]) <= 4, f"history shape {key}")
        rows_by_scope.setdefault(scope, []).append(row)
    shards = []
    idx = 0
    for scope in sorted(rows_by_scope):
        # batch-1 entry: no co-batching, so key-sorted shards are probe-free
        rows = sorted(rows_by_scope[scope], key=lambda r: r["id"])
        for s in range(0, len(rows), SHARD_ROWS):
            part = rows[s:s + SHARD_ROWS]
            path = run / "export" / f"expert_in_{idx:03d}_{scope}.json"
            payload = dict(scope=scope, rows=part)
            payload_sha = sha_bytes(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                               indent=2, allow_nan=False).encode() + b"\n")
            if not path.exists():
                dump(path, payload)
            else:
                require(file_sha(path) == payload_sha, f"existing shard drift {path.name}")
            shards.append(dict(index=idx, scope=scope, rows=len(part), path=str(path),
                               sha=payload_sha, keys=[r["id"] for r in part]))
            idx += 1
    manifest = dict(shards=shards, shard_rows=SHARD_ROWS,
                    scope_counts={k: len(v) for k, v in rows_by_scope.items()},
                    queues={name: dict(pool=q["pool"], budgets=q["budgets"], n=len(q["keys"]))
                            for name, q in queues.items()})
    digest = dump(run / "export" / "shard_manifest.json", manifest)
    dump(run / "export" / "queues.json", {name: dict(pool=q["pool"], budgets=q["budgets"],
                                                     keys=q["keys"]) for name, q in queues.items()})
    event(run, "export_complete", shards=len(shards), sha=digest, rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return manifest, queues, iemo_roles


def _iemo_dlg(key, src):
    return key.rsplit("_", 1)[0]


# ---------------------------------------------------------------- stage expert

def _verify_expert_npz(z, shard):
    """Key/class/view/shape binding for one expert shard output. Raises on tampering."""
    n_cls = 6 if shard["scope"].startswith("iemocap") else 7
    require([str(k) for k in z["keys"]] == shard["keys"], f"key table drift shard {shard['index']}")
    require(z["probabilities"].shape == (3, 2, shard["rows"], n_cls), f"expert shape {shard['index']}")
    require(z["probabilities"].min() >= 0 and abs(z["probabilities"].sum(-1).max() - 1) < 1e-9,
            f"probability range shard {shard['index']}")
    require([str(c) for c in z["classes"]] == list(IEMO if n_cls == 6 else CLASSES),
            f"class order shard {shard['index']}")
    require([str(v) for v in z["views"]] == ["CURRENT", "HISTORY", "SHAM"],
            f"views shard {shard['index']}")
    require(z["token_lengths"].shape == (3, 2, shard["rows"]), f"token lengths {shard['index']}")


def expert_stage(run):
    t0 = time.perf_counter()
    event(run, "expert_start")
    manifest = jload(run / "export" / "shard_manifest.json")
    out_dir = run / "expert"
    out_dir.mkdir(exist_ok=True)
    logs = []
    for shard in manifest["shards"]:
        out_npz = out_dir / f"expert_out_{shard['index']:03d}.npz"
        log_path = out_dir / f"expert_log_{shard['index']:03d}.json"
        if log_path.exists() and out_npz.exists():
            log = jload(log_path)
            require(log["output_sha"] == file_sha(out_npz), f"resume digest drift {shard['index']}")
            logs.append(log)
            continue
        proc = run_expert_subprocess(ROOT / shard["path"], out_npz)
        (out_dir / f"expert_stderr_{shard['index']:03d}.log").write_text(
            (proc.stderr or "")[-4000:], encoding="utf-8")
        if proc.returncode != 0:
            event(run, "expert_shard_failed", index=shard["index"], returncode=proc.returncode,
                  stderr=(proc.stderr or "")[-2000:])
            raise RuntimeError(f"expert shard {shard['index']} failed:\n{(proc.stderr or '')[-1500:]}")
        payload = json.loads(proc.stdout.strip().splitlines()[-1])
        require(payload["checkpoint_sha"] == MODEL_SHA, f"checkpoint sha drift shard {shard['index']}")
        require(payload["rows"] == shard["rows"], f"row count drift shard {shard['index']}")
        require(payload.get("batch_mode") == 1 and payload.get("content_invariance") == "pass",
                f"b1 guard drift shard {shard['index']}: {payload.get('content_invariance')}")
        z = read_npz(out_npz, payload["output_sha"])
        _verify_expert_npz(z, shard)
        payload.update(shard=shard["index"], scope=shard["scope"], input_sha=shard["sha"])
        dump(log_path, payload)
        logs.append(payload)
        event(run, "expert_shard_done", index=shard["index"], rows=shard["rows"],
              seconds=round(payload["seconds"], 3), calls=payload["calls"])
    summary = dict(shards=len(logs), calls=int(sum(l["calls"] for l in logs)),
                   seconds=float(sum(l["seconds"] for l in logs)),
                   rows=int(sum(l["rows"] for l in logs)),
                   probe_max=float(max(l["legacy_batch_probe_max_delta"] for l in logs)),
                   content_invariance_pass=int(sum(1 for l in logs if l.get("content_invariance") == "pass")),
                   skipped_probes=int(sum(1 for l in logs if l.get("content_invariance") == "skipped_no_duplicate_length")),
                   entry="expert_full_p11_b1.py",
                   entry_sha=file_sha(EXPERT_B1),
                   frozen_entry_sha=file_sha(EXPERT_FULL),
                   batch_mode=1)
    dump(out_dir / "expert_summary.json", summary)
    event(run, "expert_complete", **summary, wall=round(time.perf_counter() - t0, 3),
          rss_gib=round(rss_gib(), 3))
    return summary


def load_scores(run):
    manifest = jload(run / "export" / "shard_manifest.json")
    scores = {}
    for shard in manifest["shards"]:
        z = read_npz(run / "expert" / f"expert_out_{shard['index']:03d}.npz")
        for i, key in enumerate(z["keys"]):
            scores[str(key)] = dict(scope=shard["scope"],
                                    q=z["probabilities"][:, :, i, :].astype(float),
                                    tokens=np.array(z["token_lengths"][:, :, i]))
    return scores


def gather_q(scores, keys, n_cls):
    q = np.stack([scores[str(k)]["q"] for k in keys])
    require(q.shape == (len(keys), 3, 2, n_cls), "q gather shape")
    return np.transpose(q, (1, 2, 0, 3))


# ---------------------------------------------------------------- stage fit

def pilot_overlap_check(run, scores):
    """For rows overlapping the pilot: verify identical text/class mapping and report
    score deltas caused by different batch plans (per taskbook §4, no bitwise claim)."""
    lock = jload(PILOT / "input_lock.json")
    z = read_npz(PILOT / "expert_scores.npz", jload(PILOT / "expert_run.json")["output_sha"])
    pilot_rows = {r["id"]: r for r in jload(PILOT / "blind_text.json")["rows"]}
    by_key = {str(k): i for i, k in enumerate(z["keys"])}
    text = meld_text()
    report = dict(rows=0, max_p_diff={}, argmax_agree={}, text_mismatch=[])
    diffs = {("CURRENT", 0): [], ("CURRENT", 1): [], ("HISTORY", 0): [], ("HISTORY", 1): []}
    agree = {v: [0, 0] for v in ("CURRENT", "HISTORY")}
    for key, i in by_key.items():
        if key not in pilot_rows or str(key) not in scores:
            continue
        row = pilot_rows[key]
        base = text[key]
        same_text = (list(map(str, row["target"])) == list(map(str, base["target"])) and
                     [list(map(str, h)) for h in row["history"]] ==
                     [list(map(str, h)) for h in base["history"]])
        if not same_text:
            report["text_mismatch"].append(key)
        report["rows"] += 1
        q = scores[str(key)]["q"]  # [3,2,7]
        for v, vi in (("CURRENT", 0), ("HISTORY", 1)):
            for order in range(2):
                diffs[(v, order)].append(float(np.max(np.abs(q[vi, order] - z["probabilities"][vi, order, i]))))
            agree[v][0] += int(q[vi].mean(axis=0).argmax() == z["probabilities"][vi, :, i, :].mean(axis=0).argmax())
            agree[v][1] += 1
    for k, v in diffs.items():
        report["max_p_diff"][f"{k[0]}_order{k[1]}"] = max(v) if v else None
    for v, (hit, n) in agree.items():
        report["argmax_agree"][v] = dict(agreed=hit, n=n, ratio=round(hit / n, 4) if n else None)
    dump(run / "fit" / "pilot_overlap_check.json", report)
    event(run, "pilot_overlap_checked", **{k: v for k, v in report.items() if k != "text_mismatch"},
          text_mismatch_n=len(report["text_mismatch"]))
    require(not report["text_mismatch"], f"pilot overlap text mismatch: {report['text_mismatch'][:5]}")
    require(report["rows"] >= 276, f"pilot overlap rows {report['rows']}")
    # long run is solo (batch 1); the pilot used batch 12 - shape noise on a few
    # hypersensitive rows can reach ~0.056, so agreement is asserted at 0.8 and the
    # exact per-view deltas are reported for the reviewer
    for v, (hit, n) in agree.items():
        require(hit / n >= 0.8, f"pilot overlap {v} argmax agreement {hit}/{n}")
    return report


def fit_stage(run, record, frames, scores, iemo_roles, z03):
    t0 = time.perf_counter()
    event(run, "fit_start")
    (run / "fit").mkdir(exist_ok=True)
    pilot_overlap_check(run, scores)
    fits = {}
    for seed in SEEDS:
        for fold in FOLDS:
            unit = f"{seed}_{fold}"
            part = frames[unit]
            fits[unit] = _fit_unit_meld(run, unit, part, scores)
    for seed in SEEDS:
        fits[f"iemo_{seed}"] = _fit_unit_iemo(run, seed, scores, iemo_roles, z03)
    digest = dump(run / "fit" / "fits.json", fits)
    n_fit = sum(1 for u in fits.values() for arm in LEARNED if u.get(arm, {}).get("status") == "fit")
    event(run, "fit_complete", sha=digest, learned_fits=n_fit, rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return fits


def _fit_unit_meld(run, unit, part, scores):
    fits = dict(fs_pool=len(part["fs"]["keys"]), c_pool=len(part["c"]["keys"]))
    o = queue_order(part["fs"]["keys"], part["fs"]["p"])
    sup = o[:math.ceil(MAIN_QB * len(part["fs"]["keys"]))]
    sup_keys = [str(k) for k in part["fs"]["keys"][sup]]
    require(all(k in scores for k in sup_keys), f"missing expert scores fs {unit}")
    q_fs = gather_q(scores, sup_keys, 7)
    p_fs = part["fs"]["p"][sup]
    x7, a, b = rc.features(p_fs, q_fs, "ORDINARY")
    x9cf, a2, b2 = rc.features(p_fs, q_fs, "CF")
    x9sc, a3, b3 = rc.features(p_fs, q_fs, "SHAM_CF")
    np.testing.assert_array_equal(a, a2); np.testing.assert_array_equal(b, b2)
    np.testing.assert_array_equal(a, a3); np.testing.assert_array_equal(b, b3)
    event(run, "fs_labels_open", unit=unit, pool=len(sup_keys),
          candidates=int((a != b).sum()))
    labels = p9.phase_labels("train", "S",
                             {unit: dict(official=part["fs"]["official"][sup])}, CLASSES,
                             c1_lock(), run)[unit]
    fits["fs_support"] = int(len(sup_keys))
    fits["fs_candidates"] = int((a != b).sum())
    for arm, x in (("ORDINARY", x7), ("CF", x9cf), ("SHAM_CF", x9sc)):
        try:
            model = rc.fit(x, a, b, labels)
            fits[arm] = dict(status="fit", **model)
        except (ValueError, RuntimeError) as exc:
            fits[arm] = dict(status="fallback", reason=str(exc))
            event(run, "fit_fallback", unit=unit, arm=arm, reason=str(exc))
    # ---- C gate + C_BLEND alpha (menus selected on FULL C coverage wF1)
    event(run, "c_labels_open", unit=unit, pool=len(part["c"]["keys"]), coverage="full")
    y_c_full = p9.phase_labels("train", "C",
                               {unit: dict(official=part["c"]["official"])}, CLASSES,
                               c1_lock(), run)[unit]
    o = queue_order(part["c"]["keys"], part["c"]["p"])
    sup_c = o[:math.ceil(MAIN_QB * len(part["c"]["keys"]))]
    sup_c_keys = [str(k) for k in part["c"]["keys"][sup_c]]
    require(all(k in scores for k in sup_c_keys), f"missing expert scores c {unit}")
    q_c = gather_q(scores, sup_c_keys, 7)
    p_c = part["c"]["p"][sup_c]
    y_c = y_c_full[sup_c]
    n_c = len(part["c"]["keys"])
    a_full_c = part["c"]["p"].argmax(1)
    a_c = p_c.argmax(1)
    np.testing.assert_array_equal(a_c, a_full_c[sup_c])
    qbar_c = q_c[1].mean(axis=0)
    b_c = ((1 - rc.ALPHA_CANDIDATE) * p_c + rc.ALPHA_CANDIDATE * qbar_c).argmax(1)
    k_c = min(int(MAIN_AB * n_c), int((a_c != b_c).sum()))
    fits["c_support"] = int(len(sup_c_keys))
    fits["c_candidates"] = int((a_c != b_c).sum())
    fits["c_quota_k"] = int(k_c)
    keys_full_c = np.array([str(k) for k in part["c"]["keys"]])
    queries_c = np.isin(np.arange(n_c), sup_c)
    b_full_c = a_full_c.copy()
    b_full_c[sup_c] = b_c
    if fits["CF"]["status"] == "fit":
        xcf, aa, bb = rc.features(p_c, q_c, "CF")
        np.testing.assert_array_equal(aa, a_c)
        np.testing.assert_array_equal(bb, b_c)
        score_sup, _ = rc.risk(xcf, fits["CF"], a_c, b_c)
        score_c_full = np.full(n_c, -np.inf)
        score_c_full[sup_c] = score_sup
        gate = {}
        for tau in TAU_MENU:
            pred, _ = rc.choose_actions(a_full_c, b_full_c, score_c_full, keys_full_c,
                                        queries_c, k_c, minimum=tau)
            gate[_tau_key(tau)] = float(100 * wf1_cm(cm_of(y_c_full, pred, 7)))
        best = max(gate.values())
        tau_star = max((t for t in TAU_MENU if gate[_tau_key(t)] == best),
                       key=lambda t: (math.inf if not math.isfinite(t) else t))
        fits["gate"] = dict(tau=_tau_key(tau_star), menu=gate, selected_value=best)
    else:
        fits["gate"] = dict(tau="inf", menu={}, selected_value=None, reason="cf fallback")
    blend = {}
    qbar_full_c = np.zeros((n_c, 7))
    qbar_full_c[sup_c] = qbar_c
    for alpha in C_MENU:
        pred_full = a_full_c.copy()
        m = a_c != b_c
        blended_sup = ((1 - alpha) * p_c + alpha * qbar_c)[m]
        pred_full[sup_c[m]] = blended_sup.argmax(1)
        blend[str(alpha)] = float(100 * wf1_cm(cm_of(y_c_full, pred_full, 7)))
    best = max(blend.values())
    alpha_star = min(a for a in C_MENU if blend[str(a)] == best)
    fits["c_blend"] = dict(alpha=float(alpha_star), menu=blend)
    return fits


def _fit_unit_iemo(run, seed, scores, iemo_roles, z03):
    fits = dict(fs_pool=len(iemo_roles["fs_keys"]), c_pool=len(iemo_roles["c_keys"]))
    p03 = np.exp(z03[f"lp_{seed}"].astype(float))
    keys03 = [str(k) for k in z03["keys"]]
    fs_n = int(z03["fs_n"][0])
    o = queue_order(np.array(keys03[:fs_n]), p03[:fs_n])
    sup = o[:math.ceil(MAIN_QB * fs_n)]
    sup_keys = [keys03[:fs_n][i] for i in sup]
    require(all(k in scores for k in sup_keys), f"missing expert scores iemo fs {seed}")
    q_fs = gather_q(scores, sup_keys, 6)
    p_fs = p03[:fs_n][sup]
    x7, a, b = rc.features(p_fs, q_fs, "ORDINARY")
    x9cf, a2, b2 = rc.features(p_fs, q_fs, "CF")
    x9sc, a3, b3 = rc.features(p_fs, q_fs, "SHAM_CF")
    np.testing.assert_array_equal(a, a2); np.testing.assert_array_equal(b, b2)
    np.testing.assert_array_equal(a, a3); np.testing.assert_array_equal(b, b3)
    event(run, "iemocap_labels_open", session="Ses03", purpose="fit", seed=seed,
          pool=len(sup_keys), candidates=int((a != b).sum()))
    labels = _iemo_labels(run, sup_keys)
    fits["fs_support"] = int(len(sup_keys))
    fits["fs_candidates"] = int((a != b).sum())
    for arm, x in (("ORDINARY", x7), ("CF", x9cf), ("SHAM_CF", x9sc)):
        try:
            model = rc.fit(x, a, b, labels)
            fits[arm] = dict(status="fit", **model)
        except (ValueError, RuntimeError) as exc:
            fits[arm] = dict(status="fallback", reason=str(exc))
            event(run, "fit_fallback", unit=f"iemo_{seed}", arm=arm, reason=str(exc))
    o = queue_order(np.array(keys03[fs_n:]), p03[fs_n:])
    sup_c = o[:math.ceil(MAIN_QB * (1569 - fs_n))]
    sup_c_keys = [keys03[fs_n:][i] for i in sup_c]
    require(all(k in scores for k in sup_c_keys), f"missing expert scores iemo c {seed}")
    q_c = gather_q(scores, sup_c_keys, 6)
    p_c = p03[fs_n:][sup_c]
    event(run, "iemocap_labels_open", session="Ses03", purpose="calibration", seed=seed,
          pool=1569 - fs_n, coverage="full")
    y_c_full = _iemo_labels(run, keys03[fs_n:])
    y_c = y_c_full[sup_c]
    n_c = 1569 - fs_n
    a_full_c = p03[fs_n:].argmax(1)
    a_c = p_c.argmax(1)
    np.testing.assert_array_equal(a_c, a_full_c[sup_c])
    qbar_c = q_c[1].mean(axis=0)
    b_c = ((1 - rc.ALPHA_CANDIDATE) * p_c + rc.ALPHA_CANDIDATE * qbar_c).argmax(1)
    k_c = min(int(MAIN_AB * n_c), int((a_c != b_c).sum()))
    fits["c_support"] = int(len(sup_c_keys))
    fits["c_candidates"] = int((a_c != b_c).sum())
    fits["c_quota_k"] = int(k_c)
    keys_full_c = np.array(keys03[fs_n:])
    queries_c = np.isin(np.arange(n_c), sup_c)
    b_full_c = a_full_c.copy()
    b_full_c[sup_c] = b_c
    if fits["CF"]["status"] == "fit":
        xcf, aa, bb = rc.features(p_c, q_c, "CF")
        np.testing.assert_array_equal(aa, a_c)
        np.testing.assert_array_equal(bb, b_c)
        score_sup, _ = rc.risk(xcf, fits["CF"], a_c, b_c)
        score_c_full = np.full(n_c, -np.inf)
        score_c_full[sup_c] = score_sup
        gate = {}
        for tau in TAU_MENU:
            pred, _ = rc.choose_actions(a_full_c, b_full_c, score_c_full, keys_full_c,
                                        queries_c, k_c, minimum=tau)
            gate[_tau_key(tau)] = float(100 * wf1_cm(cm_of(y_c_full, pred, 6)))
        best = max(gate.values())
        tau_star = max((t for t in TAU_MENU if gate[_tau_key(t)] == best),
                       key=lambda t: (math.inf if not math.isfinite(t) else t))
        fits["gate"] = dict(tau=_tau_key(tau_star), menu=gate, selected_value=best)
    else:
        fits["gate"] = dict(tau="inf", menu={}, selected_value=None, reason="cf fallback")
    blend = {}
    for alpha in C_MENU:
        pred_full = a_full_c.copy()
        m = a_c != b_c
        blended_sup = ((1 - alpha) * p_c + alpha * qbar_c)[m]
        pred_full[sup_c[m]] = blended_sup.argmax(1)
        blend[str(alpha)] = float(100 * wf1_cm(cm_of(y_c_full, pred_full, 6)))
    best = max(blend.values())
    alpha_star = min(a for a in C_MENU if blend[str(a)] == best)
    fits["c_blend"] = dict(alpha=float(alpha_star), menu=blend)
    return fits


def _tau_key(tau):
    return "inf" if tau == float("inf") else ("-inf" if tau == float("-inf") else repr(tau))


def _tau_val(key):
    return float("inf") if key == "inf" else (float("-inf") if key == "-inf" else float(key))


_IEMO_BASE = None


def _iemo_base():
    global _IEMO_BASE
    if _IEMO_BASE is None:
        path = ROOT / "data/features/m3net/IEMOCAP_features.pkl"
        with path.open("rb") as f:
            _IEMO_BASE = pickle.load(f, encoding="latin1")
    return _IEMO_BASE


def _iemo_labels(run, keys):
    """Active label read for the listed IEMOCAP keys (fit/calibration or scoring).

    Only the listed keys' labels are consumed; Session 5 is never touched."""
    base = _iemo_base()
    labels, ids = base[2], base[0]
    out = []
    for key in keys:
        did = key.rsplit("_", 1)[0]
        require(did.startswith("Ses03") or did.startswith("Ses04"), f"session boundary {key}")
        utt = [str(u) for u in ids[did]]
        require(utt.count(key) == 1, f"iemocap key {key}")
        out.append(int(labels[did][utt.index(key)]))
    return np.array(out, dtype=np.int64)


# ---------------------------------------------------------------- blind assembly

def _scatter(n, mask, values, n_cls):
    out = np.full((n, n_cls), np.nan)
    out[mask] = values
    return out.astype(np.float32)


def blind_stage(run, frames, scores, fits, dev_sets, anchor_p0, p5_pred, iemo_roles, z03):
    t0 = time.perf_counter()
    event(run, "blind_start")
    (run / "blind").mkdir(exist_ok=True)
    packages = {}
    units = {}
    for seed in SEEDS:
        for fold in FOLDS:
            unit = f"{seed}_{fold}"
            part = frames[unit]["h"]
            keys = [str(k) for k in part["keys"]]
            o = queue_order(part["keys"], part["p"])
            units[unit] = dict(keys=keys, p=part["p"], did=part["did"],
                               official=part["official"],
                               masks={b: o[:math.ceil(b * len(keys))] for b in QB},
                               fit=fits[unit])
    packages["H"] = _assemble_units(run, "H", units, scores, 7)

    dev_units = {}
    for tag, getter in (("dev_c1", lambda s: dev_sets[str(s)]["p"]),
                        ("dev_anchor", lambda s: anchor_p0[str(s)])):
        for seed in SEEDS:
            p = getter(seed)
            keys = [str(k) for k in dev_sets[str(seed)]["keys"]]
            o = queue_order(dev_sets[str(seed)]["keys"], p)
            dev_units[str(seed)] = dict(keys=keys, p=p, did=dev_sets[str(seed)]["did"],
                                        masks={b: o[:math.ceil(b * len(keys))] for b in QB},
                                        fold_units=[f"{seed}_{f}" for f in FOLDS])
        packages[tag] = _assemble_dev(run, tag, dev_units, scores, fits)
        dev_units = {}

    iemo_units = {}
    for seed in SEEDS:
        p04 = p5_pred[str(seed)]["p"]
        keys = [str(k) for k in p5_pred[str(seed)]["keys"]]
        o = queue_order(np.array(keys), p04)
        iemo_units[str(seed)] = dict(keys=keys, p=p04, did=np.array(iemo_roles["s4_did"]),
                                     masks={b: o[:math.ceil(b * len(keys))] for b in QB},
                                     fit=fits[f"iemo_{seed}"])
    packages["iemo"] = _assemble_units(run, "iemo", iemo_units, scores, 6)
    event(run, "blind_complete", scopes=list(packages), rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return packages


def _assemble_units(run, tag, units, scores, n_cls):
    """Per-unit blind assembly. Scores/features computed on the 35% queue prefix
    (superset of the 10/20% prefixes); the main operating point uses the 20% mask."""
    fields = {}
    meta = {}
    for unit, u in units.items():
        keys = u["keys"]
        p = np.asarray(u["p"], float)
        n = len(keys)
        a_full = p.argmax(1)
        sup = u["masks"][0.35]
        sup_keys = [keys[i] for i in sup]
        q = gather_q(scores, sup_keys, n_cls)
        p_sup = p[sup]
        qbar = [q[0].mean(axis=0), q[1].mean(axis=0), q[2].mean(axis=0)]
        a_sup = p_sup.argmax(1)
        b_sup = ((1 - rc.ALPHA_CANDIDATE) * p_sup + rc.ALPHA_CANDIDATE * qbar[1]).argmax(1)
        b_full = a_full.copy()
        b_full[sup] = b_sup
        fields[f"{unit}__keys"] = np.array(keys)
        fields[f"{unit}__a"] = a_full.astype(np.int64)
        fields[f"{unit}__b"] = b_full.astype(np.int64)
        fields[f"{unit}__p"] = p.astype(np.float32)
        fields[f"{unit}__did"] = np.asarray(u["did"])
        if u.get("official") is not None:
            fields[f"{unit}__official"] = np.asarray(u["official"]).astype(np.int64)
        fields[f"{unit}__support35"] = sup.astype(np.int64)
        for b in QB:
            fields[f"{unit}__mask_{b}"] = u["masks"][b].astype(np.int64)
        fields[f"{unit}__q_hist"] = _scatter(n, sup, qbar[1], n_cls)
        fields[f"{unit}__q_cur"] = _scatter(n, sup, qbar[0], n_cls)
        fields[f"{unit}__q_sham"] = _scatter(n, sup, qbar[2], n_cls)
        agree = np.full(n, -1, np.int8)
        agree[sup] = (q[1, 0].argmax(axis=1) == q[1, 1].argmax(axis=1))
        fields[f"{unit}__perm_agree"] = agree
        fit = u["fit"] or {}
        main = u["masks"][MAIN_QB]
        main_keys = [keys[i] for i in main]
        # fixed arms: blend on the 20% support
        for view, qm in (("CURRENT", qbar[0]), ("HISTORY", qbar[1]), ("SHAM", qbar[2])):
            blended = p.copy()
            sel = np.isin(sup, main)
            blended[sup[sel]] = ((1 - BLEND[0]) * p_sup[sel] + BLEND[1] * qm[sel])
            fields[f"{unit}__FIXED_{view}"] = blended.argmax(1).astype(np.int64)
            fields[f"{unit}__p_FIXED_{view}"] = blended.astype(np.float32)
        hard = a_full.copy()
        hard[main] = qbar[1][np.isin(sup, main)].argmax(1)
        fields[f"{unit}__HARD_EXPERT"] = hard.astype(np.int64)
        alpha = fit.get("c_blend", {}).get("alpha", 0.0)
        blended = p.copy()
        sel = np.isin(sup, main)
        blended[sup[sel]] = ((1 - alpha) * p_sup[sel] + alpha * qbar[1][sel])
        fields[f"{unit}__C_BLEND"] = blended.argmax(1).astype(np.int64)
        fields[f"{unit}__p_C_BLEND"] = blended.astype(np.float32)
        fields[f"{unit}__c_blend_alpha"] = np.array([alpha])
        fields[f"{unit}__p_SOURCE"] = p.astype(np.float32)
        # learned-arm scores on the 35% support
        arm_scores = {}
        for arm in ("EXPERT_MARGIN",) + LEARNED:
            score = np.full(n, -np.inf)
            if arm == "EXPERT_MARGIN":
                with np.errstate(divide="ignore"):
                    logq = np.log(np.maximum(qbar[1], rc.EPS))
                    logp = np.log(np.maximum(p_sup, rc.EPS))
                s_sup = logq[np.arange(len(sup)), b_sup] - logp[np.arange(len(sup)), a_sup]
            else:
                model = fit.get(arm)
                if model and model.get("status") == "fit":
                    x, aa, bb = rc.features(p_sup, q, arm)
                    np.testing.assert_array_equal(aa, a_sup)
                    np.testing.assert_array_equal(bb, b_sup)
                    s_sup, _ = rc.risk(x, model, a_sup, b_sup)
                else:
                    s_sup = np.full(len(sup), -np.inf)
            score[sup] = s_sup
            arm_scores[arm] = score
            fields[f"{unit}__s_{arm}"] = score.astype(np.float64)
        k_main = min(int(MAIN_AB * n), int((a_full[main] != b_full[main]).sum()))
        fields[f"{unit}__k_main"] = np.array([k_main])
        queries_main = np.isin(np.arange(n), main)
        for arm in QUOTA_ARMS:
            base_score = arm_scores["CF"] if arm == "CF_PROTECTED" else arm_scores[arm]
            minimum = _tau_val(fit.get("gate", {}).get("tau", "inf")) if arm == "CF_PROTECTED" \
                else -float("inf")
            pred, used = rc.choose_actions(a_full, b_full, base_score, np.array(keys),
                                           queries_main, k_main, minimum=minimum)
            fields[f"{unit}__{arm}"] = pred.astype(np.int64)
            fields[f"{unit}__used_{arm}"] = used.astype(np.int64)
        meta[unit] = dict(n=n, support35=int(len(sup)), support_main=int(len(main)),
                          k=k_main, candidates_main=int((a_full[main] != b_full[main]).sum()),
                          candidates35=int((a_full[sup] != b_full[sup]).sum()),
                          fit_status={arm: fit.get(arm, {}).get("status", "missing") for arm in LEARNED},
                          gate_tau=fit.get("gate", {}).get("tau", "inf"),
                          c_blend_alpha=float(alpha))
    path = run / "blind" / f"{tag}_blind.npz"
    seal_path = run / "blind" / f"{tag}_seal.json"
    if seal_path.exists() and path.exists():
        prior = jload(seal_path)
        if prior.get("predictions_sha") == file_sha(path):
            event(run, "blind_resume_skipped", scope=tag, sha=prior["predictions_sha"])
            return dict(path=str(path), seal=str(seal_path),
                        seal_sha=file_sha(seal_path), meta=prior["units"], fields=None)
    save_npz(path, **fields)
    loaded = read_npz(path, file_sha(path))
    for k, v in fields.items():
        np.testing.assert_array_equal(loaded[k], v, err_msg=k)
    seal = dict(scope=tag, predictions_sha=file_sha(path), units=meta, labels_read=0,
                class_order=list(CLASSES) if n_cls == 7 else list(IEMO),
                fits_sha=file_sha(run / "fit" / "fits.json"),
                note="all predictions are label-free; scores on the 35% queue prefix")
    seal_sha = dump(run / "blind" / f"{tag}_seal.json", seal)
    event(run, "predictions_sealed", scope=tag, sha=seal_sha, units=len(meta))
    return dict(path=str(path), seal=str(run / "blind" / f"{tag}_seal.json"), seal_sha=seal_sha,
                meta=meta, fields=fields)


def _assemble_dev(run, tag, units, scores, fits):
    fields = {}
    meta = {}
    for unit, u in units.items():
        keys = u["keys"]
        p = np.asarray(u["p"], float)
        n = len(keys)
        a_full = p.argmax(1)
        sup = u["masks"][0.35]
        sup_keys = [keys[i] for i in sup]
        q = gather_q(scores, sup_keys, 7)
        p_sup = p[sup]
        qbar = q[1].mean(axis=0)
        a_sup = p_sup.argmax(1)
        b_sup = ((1 - rc.ALPHA_CANDIDATE) * p_sup + rc.ALPHA_CANDIDATE * qbar).argmax(1)
        b_full = a_full.copy()
        b_full[sup] = b_sup
        fields[f"{unit}__keys"] = np.array(keys)
        fields[f"{unit}__a"] = a_full.astype(np.int64)
        fields[f"{unit}__b"] = b_full.astype(np.int64)
        fields[f"{unit}__p"] = p.astype(np.float32)
        fields[f"{unit}__did"] = np.asarray(u["did"])
        fields[f"{unit}__support35"] = sup.astype(np.int64)
        for b in QB:
            fields[f"{unit}__mask_{b}"] = u["masks"][b].astype(np.int64)
        fields[f"{unit}__q_hist"] = _scatter(n, sup, qbar, 7)
        main = u["masks"][MAIN_QB]
        sel = np.isin(sup, main)
        blended = p.copy()
        blended[sup[sel]] = (1 - BLEND[0]) * p_sup[sel] + BLEND[1] * qbar[sel]
        fields[f"{unit}__FIXED_HISTORY"] = blended.argmax(1).astype(np.int64)
        fields[f"{unit}__p_FIXED_HISTORY"] = blended.astype(np.float32)
        fields[f"{unit}__p_SOURCE"] = p.astype(np.float32)
        # fold-averaged CF risk on the same dev features
        fold_models = [(fits.get(fu, {}) or {}).get("CF") for fu in u["fold_units"]]
        usable = [m for m in fold_models if m and m.get("status") == "fit"]
        taus = [_tau_val((fits.get(fu, {}) or {}).get("gate", {}).get("tau", "inf")) for fu in u["fold_units"]]
        clipped = [1.0 if (not math.isfinite(t) and t > 0) else (-1.0 if not math.isfinite(t) else
                                                                float(np.clip(t, -1, 1))) for t in taus]
        r_mean = np.full(len(sup), -np.inf)
        if usable:
            x, aa, bb = rc.features(p_sup, q, "CF")
            np.testing.assert_array_equal(aa, a_sup)
            np.testing.assert_array_equal(bb, b_sup)
            r_mean = np.mean([rc.risk(x, m, a_sup, b_sup)[0] for m in usable], axis=0)
        score_full = np.full(n, -np.inf)
        score_full[sup] = r_mean
        fields[f"{unit}__s_CF"] = score_full.astype(np.float64)
        k_dev = min(int(MAIN_AB * n), int((a_full[main] != b_full[main]).sum()))
        fields[f"{unit}__k_main"] = np.array([k_dev])
        pred_cf, used_cf = rc.choose_actions(a_full, b_full, score_full, np.array(keys),
                                             np.isin(np.arange(n), main), k_dev)
        fields[f"{unit}__CF"] = pred_cf.astype(np.int64)
        fields[f"{unit}__used_CF"] = used_cf.astype(np.int64)
        if usable:
            elig = np.where(r_mean - float(np.mean(clipped)) > 0, r_mean, -np.inf)
            gate_scores = np.full(n, -np.inf)
            gate_scores[sup] = elig
            pred_cp, used_cp = rc.choose_actions(a_full, b_full, gate_scores, np.array(keys),
                                                 np.isin(np.arange(n), main), k_dev)
        else:
            pred_cp, used_cp = a_full.copy(), np.array([], int)
        fields[f"{unit}__CF_PROTECTED"] = pred_cp.astype(np.int64)
        fields[f"{unit}__used_CF_PROTECTED"] = used_cp.astype(np.int64)
        fields[f"{unit}__gate_usable_folds"] = np.array([len(usable)])
        fields[f"{unit}__taus_clipped"] = np.array(clipped)
        alphas = [(fits.get(fu, {}) or {}).get("c_blend", {}).get("alpha", 0.0) for fu in u["fold_units"]]
        blends = []
        for alpha in alphas:
            bl = p.copy()
            bl[sup[sel]] = (1 - alpha) * p_sup[sel] + alpha * qbar[sel]
            blends.append(bl)
        cblend = np.mean(blends, axis=0)
        fields[f"{unit}__C_BLEND"] = cblend.argmax(1).astype(np.int64)
        fields[f"{unit}__p_C_BLEND"] = cblend.astype(np.float32)
        fields[f"{unit}__alphas"] = np.array(alphas)
        meta[unit] = dict(n=n, support35=int(len(sup)), support_main=int(len(main)),
                          k=k_dev, candidates_main=int((a_full[main] != b_full[main]).sum()),
                          usable_folds=len(usable), alphas=[float(a) for a in alphas],
                          taus_clipped=[float(c) for c in clipped])
    path = run / "blind" / f"{tag}_blind.npz"
    seal_path = run / "blind" / f"{tag}_seal.json"
    if seal_path.exists() and path.exists():
        prior = jload(seal_path)
        if prior.get("predictions_sha") == file_sha(path):
            event(run, "blind_resume_skipped", scope=tag, sha=prior["predictions_sha"])
            return dict(path=str(path), seal=str(seal_path),
                        seal_sha=file_sha(seal_path), meta=prior["units"], fields=None)
    save_npz(path, **fields)
    loaded = read_npz(path, file_sha(path))
    for k, v in fields.items():
        np.testing.assert_array_equal(loaded[k], v, err_msg=k)
    seal = dict(scope=tag, predictions_sha=file_sha(path), units=meta, labels_read=0,
                class_order=list(CLASSES), fits_sha=file_sha(run / "fit" / "fits.json"),
                note="fold parameters applied to one dev p0/q; r averaged across folds")
    seal_sha = dump(run / "blind" / f"{tag}_seal.json", seal)
    event(run, "predictions_sealed", scope=tag, sha=seal_sha, units=len(meta))
    return dict(path=str(path), seal=str(run / "blind" / f"{tag}_seal.json"), seal_sha=seal_sha,
                meta=meta, fields=fields)


# ---------------------------------------------------------------- pilot replay

def pilot_replay(run, frames):
    """Re-score the pilot's sealed artifacts (labels already consumed by the pilot)."""
    t0 = time.perf_counter()
    event(run, "pilot_replay_start")
    lock = jload(PILOT / "input_lock.json")
    z = read_npz(PILOT / "expert_scores.npz", jload(PILOT / "expert_run.json")["output_sha"])
    require(z["probabilities"].shape == (2, 2, 276, 7), "pilot score shape")
    by_key = {str(k): i for i, k in enumerate(z["keys"])}
    results = {}
    for role in ("H",):
        y_rows, p_rows, dids = [], [], []
        sel_rows, sel_ids = [], []
        offset = 0
        for f in FOLDS:
            unit = f"73_{f}"
            tab = lock["tables"][f"{role}_{f}"]
            part = frames[unit]["h"]
            # bind pilot table rows to the current fold-anchored source
            lk = {str(k): i for i, k in enumerate(part["keys"])}
            idx = [lk[str(k)] for k in tab["keys"]]
            np.testing.assert_allclose(part["p"][idx], np.asarray(tab["p"]), atol=2e-12, rtol=0)
            labels = p9.phase_labels("train", "H", {unit: dict(official=part["official"])},
                                     CLASSES, c1_lock(), run)[unit]
            y_rows.append(labels)
            p_rows.append(part["p"])
            dids.append(part["did"])
            ix = np.asarray(tab["indices"])
            sel_rows.append(ix + offset)
            sel_ids.append([str(tab["keys"][i]) for i in ix])
            offset += len(part["keys"])
        y = np.concatenate(y_rows)
        base_p = np.concatenate(p_rows)
        did = np.concatenate(dids)
        base = base_p.argmax(1)
        sel = np.concatenate(sel_rows)
        sel_keys = sum(sel_ids, [])
        id_rows = np.array([by_key[k] for k in sel_keys])
        q_hist = z["probabilities"][1][:, id_rows, :].mean(axis=0)
        q_cur = z["probabilities"][0][:, id_rows, :].mean(axis=0)
        alphas_report = {}
        for view, qv, chosen in (("CURRENT", q_cur, lock and jload(PILOT / "c_lock.json")["selected_alphas"]["CURRENT"]),
                                 ("HISTORY", q_hist, jload(PILOT / "c_lock.json")["selected_alphas"]["HISTORY"])):
            alt = base.copy()
            alt[sel] = ((1 - chosen) * base_p[sel] + chosen * qv).argmax(1)
            results[f"pilot_{view}_alpha{chosen}"] = diag(y, alt, base, 7)
            if view == "HISTORY":
                alphas_report["selected"] = chosen
                results["pilot_FIXED_HISTORY"] = diag(y, alt, base, 7)
        alt = base.copy()
        alt[sel] = ((1 - 0.25) * base_p[sel] + 0.25 * q_hist).argmax(1)
        results["pilot_fixed_alpha_0.25"] = diag(y, alt, base, 7)
        alt = base.copy()
        alt[sel] = ((1 - 1.0) * base_p[sel] + 1.0 * q_hist).argmax(1)
        results["pilot_expert_override"] = diag(y, alt, base, 7)
        results["pilot_SOURCE"] = diag(y, base, base, 7)
        hard = base.copy()
        hard[sel] = q_hist.argmax(1)
        results["pilot_HARD_EXPERT"] = diag(y, hard, base, 7)
    # numeric expectations from the pilot's own frozen results (read, not hardcoded)
    pilot_res = jload(PILOT / "pilot_results.json")["metrics"]["H"]
    fh = results["pilot_FIXED_HISTORY"]
    require(abs(fh["wf1_pct"] - pilot_res["HISTORY"]["selected"]["full"]["wf1_pct"]) < 1e-9,
            f"pilot FIXED_HISTORY drift: {fh['wf1_pct']}")
    exp = pilot_res["HISTORY"]["selected"]["full"]
    require((fh["fixes"], fh["harms"], fh["wrong_to_wrong"]) == (exp["fixes"], exp["harms"], exp["wrong_to_wrong"]),
            f"pilot flips drift: {fh['fixes']}/{fh['harms']}/{fh['wrong_to_wrong']}")
    require(abs(results["pilot_SOURCE"]["wf1_pct"] - pilot_res["SOURCE"]["wf1_pct"]) < 1e-9,
            f"pilot SOURCE drift: {results['pilot_SOURCE']['wf1_pct']}")
    for key, expect in (("pilot_fixed_alpha_0.25", pilot_res["HISTORY"]["fixed_alpha_025"]["full"]),
                        ("pilot_expert_override", pilot_res["HISTORY"]["expert_override"]["full"])):
        require(abs(results[key]["wf1_pct"] - expect["wf1_pct"]) < 1e-9,
                f"{key} drift: {results[key]['wf1_pct']} vs {expect['wf1_pct']}")
    dump(run / "audit" / "pilot_replay.json", results)
    event(run, "pilot_replay_complete", seconds=round(time.perf_counter() - t0, 3))
    return results


def _sealed_npz(package):
    """Load a blind npz with its seal chain verified (seal file sha + npz sha)."""
    seal = jload(package["seal"])
    require(file_sha(package["seal"]) == package["seal_sha"], "seal file drift")
    require(seal["predictions_sha"] == file_sha(package["path"]), "npz/sha drift vs seal")
    return read_npz(package["path"], seal["predictions_sha"])


# ---------------------------------------------------------------- stage score

def _design(dids_per_stratum):
    rng = np.random.default_rng(BOOT_SEED)
    designs = {}
    for name, count in dids_per_stratum:
        sample = np.vstack((np.arange(count), rng.integers(0, count, (BOOT_DRAWS, count))))
        designs[name] = sample
    return designs


def score_scope(run, tag, package, labels, n_cls, seeds, seed_units, strata):
    """strata: list of (stratum_name, dialogue_count). seed_units: {seed: [(unit, stratum)]}."""
    seal = jload(package["seal"])
    require(file_sha(package["seal"]) == package["seal_sha"], f"seal file drift {tag}")
    require(seal["predictions_sha"] == file_sha(package["path"]), f"seal drift {tag}")
    z = read_npz(package["path"], seal["predictions_sha"])
    require(seal["labels_read"] == 0, f"labels read before seal {tag}")
    designs = _design(strata)
    stratum_count = dict(strata)
    ends = H_ENDS if tag in ("H", "iemo") else DEV_ENDS
    samples = {e: [] for e in ends}
    observed = {}
    prob_ends = ("SOURCE",) + FIXED_ARMS + ("C_BLEND",)
    for seed in seeds:
        seed_obs = {}
        for end in ends:
            cm_draws = 0
            y_rows, pred_rows, base_rows, prob_rows = [], [], [], []
            for unit, stratum in seed_units[seed]:
                y = labels[unit]
                pred = z[f"{unit}__a"] if end == "SOURCE" else z[f"{unit}__{end}"]
                base = z[f"{unit}__a"]
                did = z[f"{unit}__did"]
                design = designs[stratum]
                dids_unique = np.unique(did)
                require(len(dids_unique) == stratum_count[stratum],
                        f"stratum dialogue count {tag} {unit}")
                ix = np.searchsorted(dids_unique, did)
                require(np.array_equal(dids_unique[ix], did), "did alignment")
                counts = np.bincount(n_cls * n_cls * ix + n_cls * y + pred,
                                     minlength=n_cls * n_cls * len(dids_unique)).reshape(-1, n_cls, n_cls)
                cm_draws = cm_draws + counts[design].sum(axis=1)
                y_rows.extend(y)
                pred_rows.extend(pred)
                base_rows.extend(base)
                if end in prob_ends:
                    prob_rows.append(z[f"{unit}__p_{end}"].astype(float))
            y, pred, base = map(np.array, (y_rows, pred_rows, base_rows))
            point = diag(y, pred, base, n_cls)
            if end in prob_ends:
                q = np.concatenate(prob_rows)
                require(q.shape == (len(y), n_cls), f"probability rows {tag} {end}")
                point["nll"] = float(-np.log(np.maximum(q[np.arange(len(y)), y], 1e-12)).mean())
                point["brier"] = float(np.square(q - np.eye(n_cls)[y]).sum(axis=1).mean())
            seed_obs[end] = point
            samples[end].append(np.array([point["wf1_pct"] / 100] + [wf1_cm(cm) for cm in cm_draws]))
        observed[str(seed)] = seed_obs
    contrasts = {}
    pairs = [(e, "SOURCE") for e in ends if e != "SOURCE"] + [p for p in MECHANISM_PAIRS
                                                              if p[0] in ends and p[1] in ends]
    for treatment, baseline in dict.fromkeys(pairs):
        paired = np.asarray(samples[treatment]) - np.asarray(samples[baseline])
        mean = paired.mean(axis=0)
        contrasts[f"{treatment}_minus_{baseline}"] = dict(
            seeds_pp=(100 * paired[:, 0]).tolist(), mean_pp=float(100 * mean[0]),
            seed_sd_pp=float(100 * np.std(paired[:, 0], ddof=1)),
            ci95_pp=(100 * np.quantile(mean[1:], [.025, .975])).tolist())
    summary = {e: {k: float(np.mean([observed[str(s)][e][k] for s in seeds]))
                   for k in ("wf1_pct", "accuracy_pct", "changes", "fixes", "harms",
                             "wrong_to_wrong", "net", "nll", "brier") if k in observed[str(seeds[0])][e]}
               for e in ends}
    return dict(per_seed=observed, averages=summary, contrasts=contrasts)


# ---------------------------------------------------------------- stage diagnose

def _pooled(tag, package, seeds, seed_units, labels, n_cls):
    """Per-seed pooled arrays from a sealed blind package (no metrics computed)."""
    z = _sealed_npz(package)
    out = {}
    for seed in seeds:
        keys, ys, dids = [], [], []
        for unit, _ in seed_units[seed]:
            keys.extend(str(k) for k in z[f"{unit}__keys"])
            ys.extend(labels[unit])
            dids.extend(z[f"{unit}__did"])
        out[str(seed)] = dict(keys=np.array(keys), y=np.array(ys), did=np.array(dids),
                              z=z, units=[u for u, _ in seed_units[seed]])
    return out


def _unit_view(z, unit, end):
    return z[f"{unit}__{end}"]


def curve_grid(run, package, seeds, seed_units, labels, n_cls, pilot_keys):
    """Query/action budget curves on H, derived from sealed arrays + frozen fits."""
    z = _sealed_npz(package)
    seals = jload(package["seal"])["units"]
    QFIELD = {"CURRENT": "q_cur", "HISTORY": "q_hist", "SHAM": "q_sham"}

    def pooled(cell_pred):
        vals = []
        for seed in seeds:
            y_all, pred_all = [], []
            for unit, _ in seed_units[seed]:
                y_all.extend(labels[unit])
                pred_all.extend(cell_pred(unit))
            vals.append(100 * wf1_cm(cm_of(np.array(y_all), np.array(pred_all), n_cls)))
        return float(np.mean(vals))

    grid = {}
    for b in QB:
        cells = {}
        source_pred = {unit: z[f"{unit}__a"] for seed in seeds for unit, _ in seed_units[seed]}
        cells["SOURCE"] = pooled(lambda unit: source_pred[unit])
        for view in ("CURRENT", "HISTORY", "SHAM"):
            field = QFIELD[view]
            def make(view=view, field=field):
                def pred_fn(unit):
                    p = z[f"{unit}__p"].astype(float)
                    sup = z[f"{unit}__support35"]
                    mask = z[f"{unit}__mask_{b}"]
                    qv = z[f"{unit}__{field}"][sup].astype(float)
                    p_sup = p[sup]
                    sel = np.isin(sup, mask)
                    blended = p.copy()
                    blended[sup[sel]] = (1 - BLEND[0]) * p_sup[sel] + BLEND[1] * qv[sel]
                    return blended.argmax(1)
                return pred_fn
            cells[f"FIXED_{view}"] = pooled(make())
        for arm in QUOTA_ARMS:
            for ab in AB:
                def pred_fn(unit, arm=arm, ab=ab):
                    a = z[f"{unit}__a"]
                    mask = z[f"{unit}__mask_{b}"]
                    keys = np.array([str(k) for k in z[f"{unit}__keys"]])
                    n = len(keys)
                    cand = int((a[mask] != z[f"{unit}__b"][mask]).sum())
                    k = min(int(ab * n), cand)
                    score = z[f"{unit}__s_{('CF' if arm == 'CF_PROTECTED' else arm)}"]
                    minimum = _tau_val(seals[unit]["gate_tau"]) if arm == "CF_PROTECTED" \
                        else -float("inf")
                    pred, _ = rc.choose_actions(a, z[f"{unit}__b"], score, keys,
                                                np.isin(np.arange(n), mask), k, minimum=minimum)
                    return pred
                cells[f"{arm}@{int(ab*100)}%"] = pooled(pred_fn)
        grid[str(b)] = {name: dict(wf1_pct=round(v, 6), minus_source_pp=round(v - cells["SOURCE"], 6))
                        for name, v in cells.items() if name != "SOURCE"}
        grid[str(b)]["SOURCE_wf1_pct"] = round(cells["SOURCE"], 6)
    return grid


def reachability(run, package, seeds, seed_units, labels, n_cls):
    z = _sealed_npz(package)
    out = {}
    for seed in seeds:
        agg = dict(support_candidates=0, max_fix=0, max_harm=0, already_correct=0,
                   coverage_errors=0)
        for unit, _ in seed_units[seed]:
            a = z[f"{unit}__a"]
            b = z[f"{unit}__b"]
            mask = z[f"{unit}__mask_0.2"]
            y = labels[unit]
            cand = mask[a[mask] != b[mask]]
            agg["support_candidates"] += int(len(cand))
            agg["max_fix"] += int(((a[cand] != y[cand]) & (b[cand] == y[cand])).sum())
            agg["max_harm"] += int(((a[cand] == y[cand]) & (b[cand] != y[cand])).sum())
            agg["already_correct"] += int((a[cand] == y[cand]).sum())
            agg["coverage_errors"] += int((a != y).sum())
        out[str(seed)] = agg
    return out


def layered_diag(run, package, seeds, seed_units, labels, n_cls, scope, donors_path):
    """Post-hoc strata with true denominators; scoring-context label use only."""
    z = _sealed_npz(package)
    donors = jload(donors_path)
    sham_len = {}
    for k, v in donors.items():
        key = k.rsplit("|", 1)[1]
        sham_len[key] = v["window_len"]
    if scope == "H":
        text = meld_text()
        spk_of = lambda key: text[key]["target"][0]
        pos_of = lambda key: int(key.split("::")[1])
    else:
        iemo_texts, iemo_data = iemo_text()
        all_texts = {**iemo_texts["Ses03"], **iemo_texts["Ses04"]}
        spk_of = lambda key: all_texts[key]["target"][0]
        pos_map = {}
        for d in sorted(iemo_data["roles"], key=lambda x: x.official_dialogue_id) + \
                sorted(iemo_data["dev"], key=lambda x: x.official_dialogue_id):
            for i, key in enumerate(d.utterance_ids):
                pos_map[str(key)] = i
        pos_of = lambda key: pos_map[key]
    arms = ("CF", "SHAM_CF", "FIXED_HISTORY", "C_BLEND", "HARD_EXPERT")
    layers = {}
    for seed in seeds:
        keys, ys, per_unit = [], [], []
        for unit, _ in seed_units[seed]:
            ks = [str(k) for k in z[f"{unit}__keys"]]
            keys.extend(ks)
            per_unit.append((unit, ks))
        y = np.array([l for unit, _ in seed_units[seed] for l in labels[unit]])
        a_all = np.concatenate([z[f"{u}__a"] for u, _ in seed_units[seed]])
        p_all = np.concatenate([z[f"{u}__p"].astype(float) for u, _ in seed_units[seed]])
        preds = {arm: np.concatenate([z[f"{u}__{arm}"] for u, _ in seed_units[seed]]) for arm in arms}
        # layer membership
        spk = np.array([spk_of(k) for k in keys])
        pos = np.array([pos_of(k) for k in keys])
        prev_spk = np.full(len(keys), -1)
        prev_y = np.full(len(keys), -1)
        by_dlg = {}
        for i, k in enumerate(keys):
            d = k.split("::")[0] if k.startswith("meld") else k.rsplit("_", 1)[0]
            by_dlg.setdefault(d, []).append(i)
        for d, rows in by_dlg.items():
            rows = sorted(rows, key=lambda i: pos[i])
            for j, i in enumerate(rows):
                if j > 0:
                    prev_spk[i] = spk[rows[j - 1]]
                    prev_y[i] = y[rows[j - 1]]
        trans = np.where(prev_y < 0, "no_pred", np.where(prev_y != y, "transition", "non_trans"))
        first = pos == 0
        spk_change = (prev_spk >= 0) & (prev_spk != spk)
        conf = p_all.max(axis=1)
        conf_layer = np.select([conf < 0.4, conf < 0.7], ["<0.4", "0.4-0.7"], ">=0.7")
        srt = np.argsort(-p_all, axis=1, kind="stable")
        rank = np.array([int(np.where(srt[i] == y[i])[0][0]) for i in range(len(y))])
        rank_layer = np.select([rank == 0, rank == 1], ["rank1", "rank2"], "rank3+")
        perm_agree = np.concatenate([z[f"{u}__perm_agree"] for u, _ in seed_units[seed]])
        support35 = np.concatenate([z[f"{u}__support35"] for u, _ in seed_units[seed]])
        in_sup = np.zeros(len(keys), bool)
        in_sup[support35] = True
        sham = np.array([sham_len.get(k, -1) for k in keys])
        layer_defs = {
            "transition": trans == "transition", "non_transition": trans == "non_trans",
            "no_same_speaker_predecessor": trans == "no_pred",
            "first_utterance": first, "speaker_change": spk_change,
            "conf<0.4": conf_layer == "<0.4", "conf0.4-0.7": conf_layer == "0.4-0.7",
            "conf>=0.7": conf_layer == ">=0.7",
            "true_rank1": rank_layer == "rank1", "true_rank2": rank_layer == "rank2",
            "true_rank3+": rank_layer == "rank3+",
            "expert_perm_agree": perm_agree == 1, "expert_perm_disagree": perm_agree == 0,
            "sham_len0": (sham == 0) & in_sup, "sham_len1-2": np.isin(sham, [1, 2]) & in_sup,
            "sham_len3-4": np.isin(sham, [3, 4]) & in_sup,
        }
        seed_layers = {}
        for name, m in layer_defs.items():
            entry = dict(n=int(m.sum()))
            for arm in arms:
                pred = preds[arm]
                ch = (pred != a_all) & m
                entry[arm] = dict(flip=int(ch.sum()),
                                  fix=int((ch & (pred == y)).sum()),
                                  harm=int((ch & (a_all == y)).sum()))
            seed_layers[name] = entry
        neutral = CLASSES.index("neutral") if n_cls == 7 else IEMO.index("neutral")
        flows = {}
        for arm in arms:
            ch = preds[arm] != a_all
            flows[arm] = dict(out_of_neutral=int((ch & (a_all == neutral)).sum()),
                              into_neutral=int((ch & (preds[arm] == neutral)).sum()))
        seed_layers["neutral_flow"] = flows
        layers[str(seed)] = seed_layers
    return layers


def risk_calibration(run, packages, seeds, seed_units, labels, scores, fits):
    """Three-outcome NLL/Brier for fitted risk models and net-gain reliability of r."""
    out = {}
    for tag, package in (("H", packages["H"]),):
        z = _sealed_npz(package)
        for arm in ("ORDINARY", "SHAM_CF", "CF"):
            rows = []
            for seed in seeds:
                y_all, q3_all, r_all, m_all = [], [], [], []
                for unit, _ in seed_units[seed]:
                    fit = fits[unit].get(arm)
                    if not fit or fit.get("status") != "fit":
                        continue
                    sup = z[f"{unit}__support35"]
                    keys = [str(k) for k in z[f"{unit}__keys"][sup]]
                    p = z[f"{unit}__p"].astype(float)[sup]
                    q = gather_q(scores, keys, 7)
                    model = dict(fit)
                    x, a, b = rc.features(p, q, arm)
                    s, q3 = rc.risk(x, model, a, b)
                    cand = a != b
                    y = labels[unit][sup]
                    tgt = np.select([y == a, y == b], [0, 1], default=2)[cand]
                    y_all.append(tgt)
                    q3_all.append(q3[cand])
                    r_all.append(s[cand])
                    realized = (y[cand] == b[cand]).astype(float) - (y[cand] == a[cand]).astype(float)
                    m_all.append(realized)
                if not y_all:
                    continue
                tgt = np.concatenate(y_all)
                q3 = np.concatenate(q3_all)
                r = np.concatenate(r_all)
                realized = np.concatenate(m_all)
                nll = float(-np.log(np.maximum(q3[np.arange(len(tgt)), tgt], 1e-12)).mean())
                brier = float(np.square(q3 - np.eye(3)[tgt]).sum(axis=1).mean())
                qs = np.quantile(r, np.linspace(0, 1, 11))
                bins = np.clip(np.digitize(r, qs[1:-1]), 0, 9)
                rel = []
                for d in range(10):
                    m = bins == d
                    if m.sum() >= 5:
                        rel.append(dict(bin=d, n=int(m.sum()), mean_r=float(r[m].mean()),
                                        realized_net_gain=float(realized[m].mean())))
                rows.append(dict(seed=str(seed), n=int(len(tgt)), nll=nll, brier=brier,
                                 reliability=rel))
            out[f"{tag}_{arm}"] = rows
    return out


def exclusion_sensitivity(run, package, seeds, seed_units, labels, pilot_keys, n_cls):
    """wF1 excluding the 180 pilot-queried H utterances (post-hoc, pre-locked keys)."""
    z = _sealed_npz(package)
    pilot = set(pilot_keys)
    out = {}
    for arm in ("SOURCE", "FIXED_HISTORY", "C_BLEND", "SHAM_CF", "CF", "CF_PROTECTED"):
        per_seed = []
        for seed in seeds:
            y_all, pred_all, base_all = [], [], []
            for unit, _ in seed_units[seed]:
                keys = np.array([str(k) for k in z[f"{unit}__keys"]])
                keep = np.array([k not in pilot for k in keys])
                pred = z[f"{unit}__{arm}"] if arm != "SOURCE" else z[f"{unit}__a"]
                y_all.extend(labels[unit][keep])
                pred_all.extend(pred[keep])
                base_all.extend(z[f"{unit}__a"][keep])
            y, pred, base = map(np.array, (y_all, pred_all, base_all))
            ch = pred != base
            per_seed.append(dict(wf1_pct=float(100 * wf1_cm(cm_of(y, pred, n_cls))),
                                 n=int(len(y)), changes=int(ch.sum()),
                                 fixes=int((ch & (pred == y)).sum()),
                                 harms=int((ch & (base == y)).sum())))
        out[arm] = dict(seeds=per_seed,
                        mean_wf1_pct=float(np.mean([s["wf1_pct"] for s in per_seed])))
    return out


def efficiency_ledger(run, scores):
    manifest = jload(run / "export" / "shard_manifest.json")
    queues = jload(run / "export" / "queues.json")
    seals = {tag: jload(run / "blind" / f"{tag}_seal.json")["units"]
             for tag in ("H", "dev_c1", "dev_anchor", "iemo")}
    tok_sum = np.zeros(3)
    n_rows = 0
    hist_rows = 0
    for shard in manifest["shards"]:
        z = read_npz(run / "expert" / f"expert_out_{shard['index']:03d}.npz")
        tl = z["token_lengths"]  # [3, 2, N] views x orders x rows
        tok_sum += tl.sum(axis=(1, 2))
        n_rows += shard["rows"]
        hist_rows += int((tl[1].min(axis=0) > tl[0].min(axis=0)).sum())
    summary = jload(run / "expert" / "expert_summary.json")
    model_bytes = (MODEL_SNAP / "model.safetensors").stat().st_size
    per_arm = {}
    for tag in ("H", "dev_c1", "dev_anchor", "iemo"):
        per_arm[tag] = {u: dict(support_main=int(seals[tag][u]["support_main"]),
                                support35=int(seals[tag][u]["support35"]),
                                k_main=int(seals[tag][u]["k"]))
                        for u in seals[tag]}
    total_main = sum(v["support_main"] for tag in per_arm for v in per_arm[tag].values())
    total_35 = sum(v["support35"] for tag in per_arm for v in per_arm[tag].values())
    anchor_seconds = None
    for line in (run / "attempts.jsonl").read_text().splitlines():
        ev = json.loads(line)
        if ev["event"] == "iemo_anchor_forward_done":
            anchor_seconds = ev["seconds"]
    return dict(
        cache=dict(rows=n_rows, calls=summary["calls"], seconds=round(summary["seconds"], 3),
                   shards=summary["shards"], probe_max=summary["probe_max"],
                   avg_tokens_per_view={"CURRENT": round(float(tok_sum[0] / n_rows), 2),
                                        "HISTORY": round(float(tok_sum[1] / n_rows), 2),
                                        "SHAM": round(float(tok_sum[2] / n_rows), 2)},
                   rows_where_history_longer_than_current=hist_rows),
        deployment=dict(queries_main_all_scopes=total_main,
                        calls_main_all_scopes=total_main * 6,
                        queries_35_all_scopes=total_35,
                        calls_35_all_scopes=total_35 * 6,
                        cached_calls=summary["calls"],
                        per_scope=per_arm,
                        note="cached union cost vs per-arm deployment cost reported separately"),
        expert_model=dict(path=str(MODEL_SNAP), weights_gib=round(model_bytes / 2**30, 3),
                          quantization="4bit (mlx-community build; local, offline)"),
        backbone_reference=dict(iemocap_anchor_forward_seconds=anchor_seconds,
                                note="P5 MM-DFN anchor forward over Ses03+Ses04 (3 anchors, CPU); "
                                     "MELD backbone inference cost not re-measured this round"),
        queues={name: dict(pool=q["pool"], budgets=q["budgets"]) for name, q in queues.items()})


def diagnose_stage(run, record, frames, packages, labels_bundle, scores, fits, iemo_roles):
    t0 = time.perf_counter()
    event(run, "diagnose_start")
    (run / "diagnose").mkdir(exist_ok=True)
    h_labels, dev_labels, ses04_labels = labels_bundle
    out = {}
    seed_units_h = {s: [(f"{s}_{f}", f) for f in FOLDS] for s in SEEDS}
    seed_units_one = {s: [(str(s), None)] for s in SEEDS}
    out["curves_H"] = curve_grid(run, packages["H"], SEEDS, seed_units_h, h_labels, 7,
                                 record["pilot"]["keys"]["H"])
    out["reachability_H"] = reachability(run, packages["H"], SEEDS, seed_units_h, h_labels, 7)
    out["layers_H"] = layered_diag(run, packages["H"], SEEDS, seed_units_h, h_labels, 7, "H",
                                   run / "export" / "donors.json")
    out["layers_iemo"] = layered_diag(run, packages["iemo"], SEEDS, seed_units_one,
                                      {str(s): ses04_labels[str(s)] for s in SEEDS}, 6, "iemo",
                                      run / "export" / "donors.json")
    out["risk_calibration"] = risk_calibration(run, packages, SEEDS, seed_units_h, h_labels,
                                               scores, fits)
    out["exclusion_H"] = exclusion_sensitivity(run, packages["H"], SEEDS, seed_units_h, h_labels,
                                               record["pilot"]["keys"]["H"], 7)
    out["efficiency"] = efficiency_ledger(run, scores)
    dump(run / "diagnose" / "diagnose.json", out)
    event(run, "diagnose_complete", seconds=round(time.perf_counter() - t0, 3))
    return out


def score_stage(run, record, frames, packages, dev_sets, anchor_p0):
    t0 = time.perf_counter()
    event(run, "score_start")
    (run / "score").mkdir(exist_ok=True)
    results = {}
    # ---- MELD H
    h_frames = {u: dict(official=frames[u]["h"]["official"]) for u in frames}
    event(run, "h_labels_open", units=len(h_frames))
    h_labels = p9.phase_labels("train", "H", h_frames, CLASSES, c1_lock(), run)
    strata = [(f, 68) for f in FOLDS]
    seed_units = {s: [(f"{s}_{f}", f) for f in FOLDS] for s in SEEDS}
    results["H"] = score_scope(run, "H", packages["H"], h_labels, 7, SEEDS, seed_units, strata)
    # ---- dev (both anchors; labels opened once)
    dev_frames = {str(s): dict(official=dev_sets[str(s)]["official"]) for s in SEEDS}
    event(run, "dev_labels_open")
    dev_labels = p9.phase_labels("dev", "dev", dev_frames, CLASSES, c1_lock(), run)
    for tag in ("dev_c1", "dev_anchor"):
        results[tag] = score_scope(run, tag, packages[tag],
                                   {u: dev_labels[u] for u in dev_labels}, 7, SEEDS,
                                   {s: [(str(s), None)] for s in SEEDS}, [(None, 114)])
    # reference wF1 checks
    for tag, ref in (("dev_c1", DEV_REF_WF1), ("dev_anchor", ANCHOR_REF_WF1)):
        got = float(np.mean([results[tag]["per_seed"][str(s)]["SOURCE"]["wf1_pct"] for s in SEEDS]))
        require(abs(got - ref) < 1e-6, f"{tag} SOURCE reference drift: {got} vs {ref}")
    # ---- IEMOCAP Ses04
    z = _sealed_npz(packages["iemo"])
    ses04_keys = [str(k) for k in z["73__keys"]]
    event(run, "iemocap_labels_open", session="Ses04", purpose="scoring", targets=len(ses04_keys))
    ses04_labels = {u.split("__")[0]: _iemo_labels(run, [str(k) for k in z[u]])
                    for u in z if u.endswith("__keys") and u != "keys"}
    results["iemo"] = score_scope(run, "iemo", packages["iemo"], ses04_labels, 6, SEEDS,
                                  {s: [(str(s), None)] for s in SEEDS}, [(None, 30)])
    dump(run / "score" / "metrics.json", results)
    event(run, "score_complete", rss_gib=round(rss_gib(), 3),
          seconds=round(time.perf_counter() - t0, 3))
    return results, (h_labels, dev_labels, ses04_labels)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "status"))
    parser.add_argument("--run", type=Path, default=None)
    args = parser.parse_args()
    if args.command == "status":
        for path in sorted(RUNS.glob("run_*")):
            print(path.name, "complete" if (path / "score" / "metrics.json").exists() else "partial")
        return
    run = (args.run or (RUNS / f"run_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}")).resolve()
    first = not run.exists()
    run.mkdir(parents=True, exist_ok=True)
    if first:
        event(run, "run_open", code=code_lock(), command=" ".join(sys.argv))
    t_all = time.perf_counter()
    done = (run / "source_lock.json").exists()
    if done:
        record = jload(run / "source_lock.json")
        frames = load_train_full()
        dev_sets, _, _ = p9.load_dev()
        anchor_z = read_npz(P10RUN / "dev_fold_anchors.npz")
        anchor_p0 = {str(s): np.mean([np.exp(anchor_z[f"{s}_{f}_lp"].astype(float)) for f in FOLDS], axis=0)
                     for s in SEEDS}
        p5_pred = {str(s): dict(keys=read_npz(P5RUN / "pred/iemocap" / f"anchor_dev_{s}_0.npz")["keys"],
                                p=read_npz(P5RUN / "pred/iemocap" / f"anchor_dev_{s}_0.npz")["p"].astype(float))
                   for s in SEEDS}
    else:
        record, frames, dev_sets, anchor_p0, p5_pred = source_stage(run)
    if not (run / "check" / "check_result.json").exists():
        check_stage(run, record)
    export_marker = run / "export" / "shard_manifest.json"
    if not export_marker.exists():
        manifest, queues, iemo_roles = export_stage(run, record, frames, dev_sets, anchor_p0, p5_pred)
    else:
        manifest = jload(export_marker)
        queues = {k: dict(pool=v["pool"], budgets={float(k2): v2 for k2, v2 in v["budgets"].items()},
                          keys=v["keys"]) for k, v in jload(run / "export" / "queues.json").items()}
        iemo_roles = None
    expert_stage(run)
    scores = load_scores(run)
    if iemo_roles is None:
        z03 = read_npz(run / "export" / "iemocap_anchor_ses03.npz")
        iemo_roles = dict(fs_keys=[str(k) for k in z03["keys"]][:int(z03["fs_n"][0])],
                          c_keys=[str(k) for k in z03["keys"]][int(z03["fs_n"][0]):],
                          s4_did=None)
        # rebuild did arrays from pools
        iemo_texts, iemo_data = iemo_text()
        ses03 = sorted(iemo_data["roles"], key=lambda d: d.official_dialogue_id)
        order_fit = sorted(range(len(ses03)),
                           key=lambda i: (hashlib.sha256(f"{IEMO_ROLE_SALT}{ses03[i].official_dialogue_id}"
                                                         .encode()).hexdigest(), ses03[i].official_dialogue_id))
        fs_dlgs = [ses03[i] for i in order_fit[:20]]
        c_dlgs = [ses03[i] for i in order_fit[20:]]
        ses04 = sorted(iemo_data["dev"], key=lambda d: d.official_dialogue_id)
        iemo_roles["fs_did"] = [d.official_dialogue_id for d in fs_dlgs for _ in d.utterance_ids]
        iemo_roles["c_did"] = [d.official_dialogue_id for d in c_dlgs for _ in d.utterance_ids]
        iemo_roles["s4_did"] = [d.official_dialogue_id for d in ses04 for _ in d.utterance_ids]
    z03 = read_npz(run / "export" / "iemocap_anchor_ses03.npz")
    fits_marker = run / "fit" / "fits.json"
    if not fits_marker.exists():
        fits = fit_stage(run, record, frames, scores, iemo_roles, z03)
    else:
        fits = jload(fits_marker)
    packages = blind_stage(run, frames, scores, fits, dev_sets, anchor_p0, p5_pred, iemo_roles, z03)
    if not (run / "audit" / "pilot_replay.json").exists():
        (run / "audit").mkdir(exist_ok=True)
        pilot_replay(run, frames)
    if not (run / "score" / "metrics.json").exists():
        results, labels_bundle = score_stage(run, record, frames, packages, dev_sets, anchor_p0)
    else:
        results = jload(run / "score" / "metrics.json")
        labels_bundle = _reopen_labels(run, record, frames, packages, dev_sets)
    if not (run / "diagnose" / "diagnose.json").exists():
        scores = load_scores(run)
        diagnose_stage(run, record, frames, packages, labels_bundle, scores, fits, iemo_roles)
    if not (run / "audit" / "recheck.json").exists():
        (run / "audit").mkdir(exist_ok=True)
        proc = subprocess.run([str(VENV_PY), str(HERE / "recheck_p11.py"), str(run)],
                              capture_output=True, text=True, cwd=str(ROOT))
        (run / "audit" / "recheck_stdout.log").write_text(
            (proc.stdout or "")[-6000:] + "\n---stderr---\n" + (proc.stderr or "")[-3000:],
            encoding="utf-8")
        event(run, "recheck_finished", returncode=proc.returncode)
        if proc.returncode != 0:
            raise RuntimeError(f"recheck failed; see audit/recheck_stdout.log")
    dump(run / "completion.json", dict(
        wall_seconds=round(time.perf_counter() - t_all, 3),
        stages=["source", "check", "export", "expert", "fit", "blind", "replay", "score"],
        fits=len(fits), expert_calls=expert_summary(run), rss_gib=round(rss_gib(), 3),
        neural_forwards="expert_only", official_test_reads=0, iemocap_ses05_reads=0,
        next="S4-P11 independent review"))
    print(json.dumps({tag: results[tag]["contrasts"].get("CF_minus_SHAM_CF")
                      for tag in results}, indent=2, default=str))


def _reopen_labels(run, record, frames, packages, dev_sets):
    """Resume path: reopen label sets in the same scoring context (events recorded)."""
    h_frames = {u: dict(official=frames[u]["h"]["official"]) for u in frames}
    event(run, "h_labels_reopen", units=len(h_frames))
    h_labels = p9.phase_labels("train", "H", h_frames, CLASSES, c1_lock(), run)
    dev_frames = {str(s): dict(official=dev_sets[str(s)]["official"]) for s in SEEDS}
    event(run, "dev_labels_reopen")
    dev_labels = p9.phase_labels("dev", "dev", dev_frames, CLASSES, c1_lock(), run)
    z = _sealed_npz(packages["iemo"])
    event(run, "iemocap_labels_reopen", session="Ses04", purpose="scoring")
    ses04_labels = {}
    for u in z:
        if u.endswith("__keys") and u != "keys":
            name = u.split("__")[0]
            ses04_labels[name] = _iemo_labels(run, [str(k) for k in z[u]])
    return h_labels, dev_labels, ses04_labels


def expert_summary(run):
    s = jload(run / "expert" / "expert_summary.json")
    return s["calls"]


if __name__ == "__main__":
    main()
