"""Full-width C1 wrapper, with the upstream implementation imported unchanged."""
import torch
from src.models.sota_b1_sdt import UP, sdt_forward
from src.training.sota_b1_engine import build_mmdfn

ARMS=("AUTHOR_CLASSWISE","AUTHOR_SOFTMAX","MMDFN_SAME")
SEEDS=(73,101,2026)


def model(arm):
    if arm=="MMDFN_SAME":
        return build_mmdfn()
    assert arm in ARMS
    return UP.Transformer_Based_Model(
        dataset="MELD",temp=8,D_text=1024,D_visual=342,D_audio=300,n_head=8,
        n_classes=7,hidden_dim=1024,n_speakers=9,dropout=.3,modal_dropout=0.,
        fusion_mode="class_reliability" if arm==ARMS[0] else "softmax",
        use_speaker_embeddings=True,circumplex_alpha=0.,va_map=None)


def weights(device):
    return torch.tensor([1/x for x in (.469507,.119346,.026116,.073096,.168369,.026335,.117231)],
                        dtype=torch.float32,device=device)


def author_terms(out, mask, labels, w):
    assert out[-2] is None and out[-1] is None
    valid=mask.bool()
    active=torch.ones_like(labels,dtype=torch.float32)
    nll=UP.MaskedNLLLoss(w)
    kl=UP.MaskedKLDivLoss()
    return (nll(out[3][valid],labels,active),
            sum(nll(x[valid],labels,active) for x in out[:3]),
            sum(kl(x[valid],out[8][valid],active) for x in out[5:8]))


def move(batch,device):
    return {k:v.to(device) if torch.is_tensor(v) else v for k,v in batch.items()}


def forward(net, arm, batch):
    if arm==ARMS[-1]:
        return net(*(batch[k] for k in ("text","audio","visual","qmask","umask","lengths")))[1]
    return sdt_forward(net,batch)
