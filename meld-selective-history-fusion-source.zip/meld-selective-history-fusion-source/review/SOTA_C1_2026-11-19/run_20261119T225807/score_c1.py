"""Resolve trusted prediction metadata from the run lock, then bind dev labels."""
import csv
import json
import sys
from pathlib import Path

import numpy as np
from src.evaluation import sota_b1_score as sc

RUN=Path(__file__).resolve().parent
ROOT=Path("third_party/MELD/data/MELD")


def read_labels(keys):
    wanted={tuple(k) for k in keys}
    lookup={}
    with (ROOT/"dev_sent_emo.csv").open(newline="",encoding="utf-8") as f:
        for r in csv.DictReader(f):
            k=(int(r["Dialogue_ID"]),int(r["Utterance_ID"]))
            if k in wanted:
                if k in lookup:
                    raise ValueError("duplicate label")
                lookup[k]=sc.spec.CLASS_ORDER.index(r["Emotion"])
    if lookup.keys()!=wanted:
        raise ValueError("label key coverage")
    return np.asarray([lookup[tuple(k)] for k in keys])


def trusted(run):
    lock=run/"lock.json"
    if (run/"lock.sha256").read_text().strip()!=sc.sha256_file(lock):
        raise ValueError("run lock SHA")
    plan=json.loads(lock.read_text())
    keys=run/"dev_keys.json"
    if sc.sha256_file(keys)!=plan["dev_key_sha"]:
        raise ValueError("locked dev key table")
    return plan,json.loads(keys.read_text())


def score(unit, epoch, *, run=RUN, label_reader=read_labels, final=False):
    plan,keys=trusted(run)
    if type(epoch) is not int or unit not in plan["units"]:
        raise ValueError("unregistered unit")
    cfg=plan["units"][unit]
    if not 0<=epoch<=cfg["epochs"]:
        raise ValueError("unregistered epoch")
    path=run/"fits"/unit/f"epoch_{epoch:03d}.npz"
    meta=json.loads(path.with_suffix(".json").read_text())
    expected=dict(split="dev",unit=unit,seed=cfg["seed"],arm=cfg["arm"],
                  feature_sha256=plan["feature_sha256"],epoch=epoch,sha256=sc.sha256_file(path))
    if meta!=expected:
        raise ValueError("prediction metadata or SHA")
    if final:
        frozen=json.loads((run/"final"/"freeze.json").read_text())
        if frozen["units"][unit]!=[epoch,expected["sha256"]]:
            raise ValueError("final manifest best mapping")
        if sc.sha256_file(run/"final"/"unlabeled.json")!=frozen["sha256"]:
            raise ValueError("final prediction freeze SHA")
    with np.load(path,allow_pickle=False) as data:
        if not np.array_equal(data["keys"],keys) or len(set(map(tuple,keys)))!=len(keys):
            raise ValueError("prediction keys")
        p,lp=data["p"],data["lp"]
    if (p.shape!=(len(keys),7) or lp.shape!=p.shape or not np.isfinite(p).all()
            or not np.isfinite(lp).all() or (p<0).any()
            or not np.allclose(p.sum(1),1,rtol=0,atol=1e-6)
            or not np.allclose(np.exp(lp),p,rtol=1e-5,atol=1e-7)):
        raise ValueError("probability and logp")
    y=label_reader(keys)
    result=sc.metrics_from_cm(sc.confusion(y,p.argmax(1)))
    result["macro_f1"]=float(np.mean([c["f1"] for c in result["per_class"]]))
    result["nll"]=float(-lp[np.arange(len(y)),y].mean(dtype=np.float64))
    return result,y


if __name__=="__main__":
    if len(sys.argv)!=3:
        raise SystemExit("usage: score_c1.py REGISTERED_UNIT EPOCH")
    print(json.dumps(score(sys.argv[1],int(sys.argv[2]))[0]))
