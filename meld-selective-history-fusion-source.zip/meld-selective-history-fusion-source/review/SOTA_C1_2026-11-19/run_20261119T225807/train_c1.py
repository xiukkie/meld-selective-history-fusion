"""Locked same-input MELD C1 training, dev predictions first and labels isolated."""
import datetime
import hashlib
import json
import resource
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch
from src.data import sota_b1_data as data
from src.evaluation.sota_b1_score import is_better, sha256_file
from src.training.s2d1_v11 import focal_loss_mmdfn
from src.utils.seed import seed_everything
from model_c1 import ARMS,SEEDS,author_terms,forward,model,move,weights
from score_c1 import RUN,trusted

BINDING=Path("review/SOTA_B1_2026-11-19/run_20261119T175349/evidence/binding_full.json")
START=datetime.datetime.fromisoformat((RUN/"start.txt").read_text().strip()).timestamp()


def dump(path,obj,mode="x"):
    with path.open(mode) as f:
        json.dump(obj,f,ensure_ascii=False,separators=(",",":"))
        f.write("\n")


def guard():
    if time.time()-START>=195*60:
        raise TimeoutError("195-minute experiment window; 15 reserved for delivery")


def labels(batch, targets, device):
    return torch.tensor([targets[k] for k in batch["keys"]],device=device)


def pred(net,arm,dev,batch_size,device):
    net.eval()
    rows=[]
    with torch.inference_mode():
        for i in range(0,len(dev),batch_size):
            b=move(data.collate(dev[i:i+batch_size]),device)
            out=forward(net,arm,b)
            lp=out if arm==ARMS[-1] else out[3][b["umask"].T.bool()]
            rows.append(lp.cpu())
    return torch.cat(rows)


def state_digest(net):
    h=hashlib.sha256()
    for name, value in net.state_dict().items():
        h.update(name.encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def fit(unit,cfg,plan,keys,train,dev,targets):
    guard()
    directory=RUN/"fits"/unit
    seed,arm,device,bs=(cfg[k] for k in ("seed","arm","device","batch"))
    dump(RUN/"attempts.jsonl",dict(event="request",unit=unit,at=time.time()),"a")
    begun=time.monotonic()
    steps=0
    try:
        directory.mkdir()
        seed_everything(seed)
        net=model(arm).to(device)
        initial=dict(state_sha256=state_digest(net),cpu_rng_sha256=hashlib.sha256(torch.get_rng_state().numpy()).hexdigest())
        if device=="mps":
            torch.mps.manual_seed(seed)
            initial["mps_rng_sha256"]=hashlib.sha256(torch.mps.get_rng_state().numpy()).hexdigest()
        initial["parameters"]=sum(p.numel() for p in net.parameters())
        dump(directory/"initial.json",initial)
        author=arm!=ARMS[-1]
        opt=torch.optim.Adam(net.parameters(),lr=5e-6 if author else 5e-4,
                             weight_decay=1e-5 if author else 1e-4)
        w=weights(device)
        ix={d.dialogue_id:d for d in train}
        batch_path=RUN/f"batch_{seed}_{'author' if author else 'mmdfn'}.json"
        assert sha256_file(batch_path)==plan["batch_files"][batch_path.name]
        batches=json.loads(batch_path.read_text())
        best,stale=None,0
        for epoch in range(cfg["epochs"]+1):
            guard()
            tick=time.monotonic()
            total=0.
            if epoch:
                net.train()
                for bspec in batches[epoch-1]["batches"]:
                    b=move(data.collate([ix[k] for k in bspec["dialogue_ids"]]),device)
                    y=labels(b,targets,device)
                    opt.zero_grad(set_to_none=True)
                    out=forward(net,arm,b)
                    loss=sum(author_terms(out,b["umask"].T,y,w)) if author else focal_loss_mmdfn(out,y,torch.ones_like(y))
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(net.parameters(),1.,error_if_nonfinite=True)
                    opt.step()
                    steps+=1
                    total+=float(loss.detach())
            eval_start=time.monotonic()
            lp=pred(net,arm,dev,bs,device)
            destination=directory/f"epoch_{epoch:03d}.npz"
            with destination.open("xb") as f:
                np.savez_compressed(f,keys=np.asarray(keys,dtype=np.int64),p=lp.exp().numpy(),lp=lp.numpy())
            sha=sha256_file(destination)
            dump(destination.with_suffix(".json"),dict(split="dev",unit=unit,seed=seed,arm=arm,
                 feature_sha256=plan["feature_sha256"],epoch=epoch,sha256=sha))
            scored=json.loads(subprocess.check_output([sys.executable,str(RUN/"score_c1.py"),unit,str(epoch)]))
            scored.update(epoch=epoch,prediction_sha256=sha)
            improved=is_better(scored,best)
            if improved:
                best,stale=scored,0
                tmp=directory/"best.tmp"
                torch.save(dict(unit=unit,epoch=epoch,state=net.state_dict()),tmp)
                tmp.replace(directory/"best.pt")
            else:
                stale+=1
            record=dict(epoch=epoch,metrics=scored,improved=improved,steps=steps,train_loss_sum=total,
                        train_seconds=eval_start-tick,eval_seconds=time.monotonic()-eval_start,
                        rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                        mps_driver_bytes=torch.mps.driver_allocated_memory() if device=="mps" else None)
            dump(directory/"history.jsonl",record,"a")
            if stale==cfg["patience"]:
                break
        dump(directory/"record.json",dict(unit=unit,best_epoch=best["epoch"],steps=steps,last_epoch=epoch,
              best_sha256=sha256_file(directory/"best.pt"),seconds=time.monotonic()-begun))
    except BaseException as e:
        dump(RUN/"attempts.jsonl",dict(event="failed",unit=unit,steps=steps,error=repr(e),at=time.time()),"a")
        raise
    dump(RUN/"attempts.jsonl",dict(event="complete",unit=unit,steps=steps,at=time.time()),"a")


def main():
    torch.set_num_threads(5)
    torch.set_num_interop_threads(15)
    plan,keys=trusted(RUN)
    for path,digest in plan["protected"].items():
        assert sha256_file(path)==digest
    for name,digest in plan["code"].items():
        assert sha256_file(RUN/name)==digest
    binding=json.loads(BINDING.read_text())
    train,dev=[data.load_dialogues(s,binding=binding) for s in ("train","dev")]
    labels_train=data.load_train_labels(binding=binding)
    (RUN/"fits").mkdir(exist_ok=True)
    complete={x["unit"] for x in map(json.loads,(RUN/"attempts.jsonl").read_text().splitlines()) if x["event"]=="complete"}
    for seed in SEEDS:
        for arm in ARMS:
            unit=f"{seed}_{arm}"
            if unit not in complete:
                fit(unit,plan["units"][unit],plan,keys,train,dev,labels_train)


if __name__=="__main__":
    main()
