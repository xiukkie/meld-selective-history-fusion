"""Time actual singleton Gemma inference on the frozen P11 dev C1 queue."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

from certified import decide
from replay import CLASSES, HERE, ROOT, MODEL_SHA, SEEDS, arrays, dump, js, sha


P11_PLAN = ROOT / "review/S4P11_plan_2026-11-22"
EXPERT_LOCK = ROOT / "review/S4T1_plan_2026-11-23/lock.json"
EXPERT_LOCK_SHA = "b9500e2a76557cdb9dc6788ad966b69f69742f2b99950496b75fbbb7148eaa3e"
LIVE = ("FULL_2", "BASE_CERT", "TWO_STAGE_CERT")


def inputs(folder):
    seal = js(folder / "seal.json")
    if seal["scope"] != "p11_dev_c1" or sorted(seal["files"]) != [
            "reference.npz", "replay.json", "workload.json"
    ]:
        raise ValueError("invalid timing scope or seal")
    payload = js(folder / "workload.json", seal["files"]["workload.json"])
    if payload["scope"] != "p11_dev_c1":
        raise ValueError("only historical dev workload may be timed")
    report = js(folder / "replay.json", seal["files"]["replay.json"])
    z = arrays(folder / "reference.npz", seal["files"]["reference.npz"])
    for s in SEEDS:
        records = payload["seeds"][str(s)]
        keys = [r["id"] for r in records["rows"]]
        if (len(keys) != 222 or len(set(keys)) != 222 or
                any(not 1039 <= int(k.split("::")[0][6:]) <= 1152 for k in keys)):
            raise ValueError("invalid dev C1 query keys")
        if (z[f"p_{s}"].shape != (222, 7) or z[f"q_{s}"].shape != (222, 2, 7)
                or z[f"pred_{s}"].shape != (222,) or any(
                    set(r) != {"id", "target", "history"} or len(r["history"]) > 4
                    for r in records["rows"])):
            raise ValueError("invalid dev C1 workload")
    return payload, z, report


def load_expert():
    if os.environ.get("HF_HUB_OFFLINE") != "1" or os.environ.get("TRANSFORMERS_OFFLINE") != "1":
        raise RuntimeError("Gemma must be loaded offline")
    sys.path.insert(0, str(P11_PLAN))
    from expert_p11 import (MODEL, LABELS, ORDERS, alternative_tokens, answer_probs,
                            frozen_logits, token_ids)
    from mlx_vlm.utils import load_model
    from transformers import AutoTokenizer

    hashes = js(EXPERT_LOCK, EXPERT_LOCK_SHA)["expert_assets"]
    if tuple(LABELS) != CLASSES or hashes["model.safetensors"] != MODEL_SHA:
        raise ValueError("Gemma lock or class mismatch")
    for name, h in hashes.items():
        if sha(MODEL / name) != h:
            raise ValueError(f"Gemma local asset drift {name}")
    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    model = load_model(MODEL,lazy=False).eval()
    load_seconds = time.perf_counter()-started
    groups = alternative_tokens(tokenizer)

    def evaluate(row, j):
        order = ORDERS[j]
        tokens = token_ids(tokenizer, row, "HISTORY", order)
        q = np.empty(7, dtype=np.float64)
        q[list(order)] = answer_probs(frozen_logits(model,tokenizer,[tokens]),groups)[0]
        return q, len(tokens)

    return evaluate, load_seconds


def run_arm(mode, rows, probabilities, expert_reference, full_labels, alphas, chosen, expert):
    elapsed, issued, tokens, expected, actual = [], [], [], [], []
    labels = []
    entire = time.perf_counter()
    for i in chosen:
        responses = []
        def query(j):
            if j != len(responses):
                raise ValueError("expert callback order mismatch")
            q, n = expert(rows[i], j)
            responses.append((q, n))
            return q
        t0 = time.perf_counter()
        label, calls = decide(probabilities[i], alphas, query, mode)
        elapsed.append(time.perf_counter()-t0)
        if len(responses) != calls:
            raise AssertionError("counted calls differ from real work")
        labels.append(label)
        issued.append(calls)
        tokens.append(sum(n for _,n in responses))
        for j, (q, _) in enumerate(responses):
            actual.append(q)
            expected.append(expert_reference[i,j])
    wall = time.perf_counter()-entire
    old = full_labels[chosen]
    np.testing.assert_array_equal(labels,old)
    drift = float(np.max(np.abs(np.array(actual)-np.array(expected)))) if actual else 0.
    if drift > 2e-5:
        raise ValueError(f"Gemma runtime drift versus P11 {drift}")
    np.testing.assert_array_equal(np.argmax(actual,1) if actual else [],
                                  np.argmax(expected,1) if expected else [])
    return dict(arm=mode, seconds=wall, calls=sum(issued), forwarded_tokens=sum(tokens),
                disagreement=0, expert_max_p_diff=drift, p50_ms=float(np.median(elapsed)*1000),
                p95_ms=float(np.quantile(elapsed,.95)*1000), per_query_seconds=elapsed,
                per_query_calls=issued, per_query_tokens=tokens, labels=labels)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--pilot",action="store_true")
    args = parser.parse_args()
    payload, ref, archive = inputs(args.source)
    source_seal = sha(args.source / "seal.json")
    args.out.mkdir(exist_ok=False,parents=True)
    expert, load_s = load_expert()
    warmup = payload["seeds"]["73"]["rows"][0]
    for j in range(2):
        q, _ = expert(warmup,j)
        np.testing.assert_allclose(q,ref["q_73"][0,j],atol=2e-5,rtol=0)

    data, warm_calls = [], 2
    seeds = (2026,) if args.pilot else SEEDS
    for s in seeds:
        chosen = np.linspace(0,221,24,dtype=int) if args.pilot else np.arange(222)
        rec = payload["seeds"][str(s)]
        arms = (("FULL_2", "TWO_STAGE_CERT"),) if args.pilot else (LIVE, tuple(reversed(LIVE)))
        for rep, modes in enumerate(arms, start=1):
            for mode in modes:
                result = run_arm(mode,rec["rows"],ref[f"p_{s}"],ref[f"q_{s}"],ref[f"pred_{s}"],
                                 rec["alphas"],chosen,expert)
                if not args.pilot and result["calls"] != archive["dev_c1"]["seeds"][str(s)]["arms"][mode]["calls"]:
                    raise ValueError("live expert call count differs from frozen replay")
                result.update(seed=s,replicate=rep,indices=chosen.tolist())
                data.append(result)
                with (args.out/"progress.jsonl").open("a",encoding="utf-8") as f:
                    key = {k:result[k] for k in ("seed","replicate","arm","calls","seconds")}
                    f.write(json.dumps(key)+"\n")
                print(key,flush=True)
    dump(args.out / "benchmark.json", dict(scope="p11_dev_c1",pilot=args.pilot,source_seal=source_seal,
                                           model_load_seconds=load_s, warmup_model_calls=warm_calls,
                                           score_label_reads=0, records=data))


if __name__ == "__main__":
    main()
