"""Validate paired timing outputs and calculate the method-level cost summary."""
import argparse
from pathlib import Path

import numpy as np

from replay import SEEDS, dump, js, sha


LIVE = ("FULL_2", "BASE_CERT", "TWO_STAGE_CERT")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--live", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    observed = js(args.live)
    if (observed["scope"] != "p11_dev_c1" or observed["pilot"]
            or observed["source_seal"] != sha(args.source / "seal.json") or observed["score_label_reads"]):
        raise ValueError("wrong timing evaluation identity")
    sealed = js(args.source / "seal.json")
    archive = js(args.source / "replay.json", sealed["files"]["replay.json"])
    records = observed["records"]
    rows = {(r["seed"],r["replicate"],r["arm"]):r for r in records}
    expected = [(s,i,a) for s in SEEDS for i in (1,2) for a in LIVE]
    if list(rows) != [(s,i,a) for s in SEEDS for i in (1,2)
                     for a in (LIVE if i == 1 else tuple(reversed(LIVE)))] or len(rows) != len(records):
        raise ValueError("missing, duplicated or reordered timing records")
    summary = {}
    for s in SEEDS:
        detail = {}
        for rep in (1,2):
            ref = rows[s,rep,"FULL_2"]
            comp = {}
            for arm in LIVE:
                m = rows[s,rep,arm]
                old = archive["dev_c1"]["seeds"][str(s)]["arms"][arm]
                if (m["indices"] != list(range(222)) or m["disagreement"] or min(m["per_query_seconds"]) <= 0
                        or len(m["per_query_seconds"]) != 222 or len(m["per_query_calls"]) != 222
                        or m["seconds"] <= 0 or sum(m["per_query_calls"]) != m["calls"]
                        or sum(m["per_query_tokens"]) != m["forwarded_tokens"] or m["calls"] != old["calls"]):
                    raise ValueError("invalid timing, call count or cohort")
                np.testing.assert_array_equal(m["labels"],ref["labels"])
                comp[arm] = dict(seconds=m["seconds"], calls=m["calls"],
                                 forwarded_tokens=m["forwarded_tokens"],
                                 time_saved=1.-m["seconds"]/ref["seconds"],
                                 calls_saved=1.-m["calls"]/ref["calls"],
                                 tokens_saved=1.-m["forwarded_tokens"]/ref["forwarded_tokens"],
                                 paired_difference_seconds=m["seconds"]-ref["seconds"])
            detail[str(rep)] = comp
        summary[str(s)] = detail
    main_saving = [summary[str(s)][str(rep)]["TWO_STAGE_CERT"]["time_saved"]
                   for s in SEEDS for rep in (1,2)]
    base2_saving = [
        1.-rows[s,r,"TWO_STAGE_CERT"]["seconds"]/rows[s,r,"BASE_CERT"]["seconds"]
        for s in SEEDS for r in (1,2)
    ]
    dump(args.out, dict(checked_timer_units=len(expected), inputs_sha=sha(args.live),
                        model_load_seconds=observed["model_load_seconds"],
                        warmup_model_calls=observed["warmup_model_calls"],
                        two_stage_time_saving_median=float(np.median(main_saving)),
                        two_stage_time_saving_range=[min(main_saving),max(main_saving)],
                        against_base_cert_saving_median=float(np.median(base2_saving)),
                        per_seed_rep=summary))


if __name__ == "__main__":
    main()
