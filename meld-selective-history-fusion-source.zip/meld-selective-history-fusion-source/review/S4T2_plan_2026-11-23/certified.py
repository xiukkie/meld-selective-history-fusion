"""Preserve full two-permutation top-1 while omitting dominated evaluations."""
import math

import numpy as np


N_CLASSES = 7
EPS = 1e-12
MODES = ("FULL_2", "ONE_ORDER", "BASE_CERT", "TWO_STAGE_CERT")


def probability(value, tolerance):
    row = np.asarray(value, dtype=np.float64)
    if (row.shape != (N_CLASSES,) or not np.isfinite(row).all()
            or (row < 0).any() or (row > 1).any()
            or abs(float(row.sum()) - 1.) > tolerance):
        raise ValueError("invalid canonical probability row")
    return row


def margin_certificate(partial, remaining_mass):
    """The unknown scores can add at most remaining_mass to any competing gap."""
    winner = int(partial.argmax())
    rival = max(partial[:winner].max(initial=-np.inf), partial[winner+1:].max(initial=-np.inf))
    if partial[winner] - rival > remaining_mass + EPS:
        return winner
    return None


def full_probability(p, first, second, alphas):
    """Preserve the arithmetic and tie policy of the frozen P11/S4-T1 reference."""
    q = (first + second) * .5
    return np.mean([(1. - a) * p + a * q for a in alphas], axis=0)


def decide(p, alphas, query, mode="TWO_STAGE_CERT"):
    """Return (class id, actual callback count); only call query(order) when needed.

    Each alpha is a frozen fold-local weight. The result is a label only.
    Certified early exits have no complete fused probability vector.
    """
    if mode not in MODES:
        raise ValueError("unknown stopping policy")
    weights = tuple(float(a) for a in alphas)
    if not weights or any(not math.isfinite(a) or not 0 <= a <= 1 for a in weights):
        raise ValueError("invalid frozen fusion weights")
    p = probability(p, 2e-6)
    alpha = math.fsum(weights) / len(weights)
    base = (1. - alpha) * p
    if mode in ("BASE_CERT", "TWO_STAGE_CERT"):
        if not any(weights):
            return int(p.argmax()), 0
        safe = margin_certificate(base, alpha)
        if safe is not None:
            return safe, 0
    first = probability(query(0), 1e-12)
    if mode == "ONE_ORDER":
        return int((base + alpha * first).argmax()), 1
    if mode == "TWO_STAGE_CERT":
        safe = margin_certificate(base + .5 * alpha * first, .5 * alpha)
        if safe is not None:
            return safe, 1
    second = probability(query(1), 1e-12)
    return int(full_probability(p, first, second, weights).argmax()), 2
