import unittest

import numpy as np

from certified import N_CLASSES, decide, margin_certificate


class TestCertified(unittest.TestCase):
    def test_boundary_and_ties(self):
        self.assertIsNone(margin_certificate(np.array([.5, .25]), .25))
        self.assertIsNone(margin_certificate(np.array([.25, .25]), 0.))
        self.assertEqual(margin_certificate(np.array([.25, .51]), .25), 1)

    def test_no_extra_forward_on_certified_exit(self):
        p = np.array([.9, .1, 0., 0., 0., 0., 0.])
        q = np.array([1., 0., 0., 0., 0., 0., 0.])
        expect = [None, q]
        for row, steps in ((p, 0), (np.array([.53, .47, 0., 0., 0., 0., 0.]), 1)):
            calls = []
            def query(j):
                calls.append(j)
                self.assertEqual(j, 0)
                return expect[1]
            self.assertEqual(decide(row, (.25,), query), (0, steps))
            self.assertEqual(len(calls), steps)

    def test_adversarial_remaining_mass_forces_second(self):
        p = np.array([.51, .49, 0., 0., 0., 0., 0.])
        q = np.array([[.51, .49, 0., 0., 0., 0., 0.], [0., 1., 0., 0., 0., 0., 0.]])
        calls = []
        def query(j):
            calls.append(j)
            return q[j]
        self.assertEqual(decide(p, (.25,), query), (1, 2))
        self.assertEqual(calls, [0, 1])

    def test_randomized_and_simplex_corner_completions(self):
        rng = np.random.default_rng(20261123)
        seen = set()
        for j in range(256):
            p = rng.dirichlet(np.ones(N_CLASSES))
            a = tuple(rng.choice([0., .125, .25, .5, 1.], size=3))
            first = rng.dirichlet(np.ones(N_CLASSES))
            completions = np.vstack((np.eye(N_CLASSES),rng.dirichlet(np.ones(N_CLASSES))))
            for second in completions:
                bank = [first, second]
                full, calls_full = decide(p, a, bank.__getitem__, "FULL_2")
                label, calls = decide(p, a, bank.__getitem__)
                self.assertEqual(label, full)
                self.assertEqual(calls_full, 2)
                seen.add(calls)
        self.assertEqual(seen, {0,1,2})

    def test_invalid_input(self):
        p = np.ones(N_CLASSES)/N_CLASSES
        for bad in ([-.1], [np.nan], [], [1.1]):
            with self.assertRaises(ValueError):
                decide(p, bad, lambda _: p)
        with self.assertRaises(ValueError):
            decide(p, (.25,), lambda _: p * .7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
