"""Replay the locked H and C1 dev archives, and stage a blind timing workload."""
import argparse
import hashlib
import io
import json
from pathlib import Path

import numpy as np

from certified import MODES, decide


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
P11 = ROOT / "review/S4P11_2026-11-22/run_20261122T100722468056Z"
MODEL_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"
CLASSES = ("neutral", "surprise", "fear", "sadness", "joy", "disgust", "anger")
SEEDS = (73, 101, 2026)


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def read(path, expected=None):
    raw = path.read_bytes()
    if expected is not None and hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError(f"SHA mismatch {path}")
    return raw


def js(path, expected=None):
    return json.loads(read(path, expected))


def arrays(path, expected):
    with np.load(io.BytesIO(read(path, expected)), allow_pickle=False) as z:
        return dict(z)


def dump(path, data):
    with path.open("x", encoding="utf-8") as f:
        json.dump(data, f, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")


def bank():
    experts, prompts = {}, {}
    for shard in js(P11 / "export/shard_manifest.json")["shards"]:
        if shard["scope"] not in ("historical_dev", "long_train"):
            continue
        i = shard["index"]
        log = js(P11 / "expert" / f"expert_log_{i:03d}.json")
        if (log["checkpoint_sha"] != MODEL_SHA or log["batch_mode"] != 1
                or log["content_invariance"] != "pass" or log["input_sha"] != shard["sha"]):
            raise ValueError(f"old expert identity mismatch {i}")
        z = arrays(P11 / "expert" / f"expert_out_{i:03d}.npz", log["output_sha"])
        source = js(Path(shard["path"]), shard["sha"])
        if (list(z["keys"]) != shard["keys"] or list(z["classes"]) != list(CLASSES)
                or list(z["views"]) != ["CURRENT", "HISTORY", "SHAM"] or source["scope"] != shard["scope"]):
            raise ValueError(f"old source schema mismatch {i}")
        for j, row in enumerate(source["rows"]):
            key = row["id"]
            if key != z["keys"][j] or key in experts:
                raise ValueError(f"old expert key mismatch {key}")
            experts[key] = z["probabilities"][1, :, j]
            if shard["scope"] == "historical_dev":
                prompts[key] = {k: row[k] for k in ("id", "target", "history")}
    return experts, prompts


def evaluate(scope, experts, prompts, fit_path):
    seal = js(P11 / "blind" / f"{scope}_seal.json")
    if seal["labels_read"] != 0 or seal["scope"] != scope:
        raise ValueError("old blind identity mismatch")
    fits = js(fit_path, seal["fits_sha"])
    z = arrays(P11 / "blind" / f"{scope}_blind.npz", seal["predictions_sha"])
    if scope == "dev_c1":
        weights_expected = {
            73: [.125, .125, .125], 101: [.25, 0., .125], 2026: [0., .25, .25],
        }
    table, bench, vectors = {}, {}, {}
    union = {mode: set() for mode in MODES}
    selected_union = set()
    for seed in SEEDS:
        per = {mode: dict(calls=0, changed=0, exits=[0, 0, 0]) for mode in MODES}
        units = [f"{seed}_{f}" for f in range(3)] if scope == "H" else [str(seed)]
        payload, prob, reference = [], [], []
        queried = 0
        for unit in units:
            keys = z[f"{unit}__keys"]
            p = z[f"{unit}__p"].astype(float)
            query = z[f"{unit}__mask_0.2"]
            top = np.sort(p,axis=1)[:, -2:]
            expected = np.lexsort((keys, top[:, 1] - top[:, 0]))[:(len(keys)+4)//5]
            np.testing.assert_array_equal(expected, query)
            chosen = set(query.tolist())
            full = z[f"{unit}__C_BLEND"]
            untouched = np.arange(len(p))[~np.isin(np.arange(len(p)),query)]
            np.testing.assert_array_equal(full[untouched], p[untouched].argmax(1))
            if scope == "H":
                a = [fits[unit]["c_blend"]["alpha"]]
                np.testing.assert_array_equal(a, z[f"{unit}__c_blend_alpha"])
            else:
                a = [fits[f"{seed}_{f}"]["c_blend"]["alpha"] for f in range(3)]
                np.testing.assert_array_equal(a, z[f"{unit}__alphas"])
                if scope == "dev_c1":
                    np.testing.assert_array_equal(a, weights_expected[seed])
            queried += len(chosen)
            for i in query:
                key = keys[i]
                q = experts[key]
                selected_union.add(key)
                for mode in MODES:
                    row = per[mode]
                    got, n = decide(p[i], a, q.__getitem__, mode)
                    row["calls"] += n
                    row["exits"][n] += 1
                    row["changed"] += int(got != full[i])
                    union[mode].update((key,j) for j in range(n))
                    if mode != "ONE_ORDER" and got != full[i]:
                        raise ValueError(f"full-fusion class mismatch {scope}/{unit}/{key}/{mode}")
                if scope == "dev_c1":
                    payload.append(prompts[key])
                    prob.append(p[i])
                    reference.append(q)
        for row in per.values():
            row["saving_rate"] = 1. - row["calls"]/(2*queried)
        table[str(seed)] = dict(queried=queried,arms=per)
        if scope == "dev_c1":
            bench[str(seed)] = dict(alphas=a, rows=payload)
            vectors[f"p_{seed}"] = np.stack(prob)
            vectors[f"q_{seed}"] = np.stack(reference)
            vectors[f"pred_{seed}"] = z[f"{seed}__C_BLEND"][z[f"{seed}__mask_0.2"]]
    return dict(seeds=table, union_queries=len(selected_union),
                union_calls={mode:len(x) for mode,x in union.items()},
                seal_sha=sha(P11 / "blind" / f"{scope}_seal.json")), bench, vectors


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    args.out.mkdir(exist_ok=False, parents=True)
    experts, prompts = bank()
    results = {}
    for scope in ("H", "dev_anchor", "dev_c1"):
        summary, workload, vectors = evaluate(scope, experts, prompts, P11 / "fit/fits.json")
        results[scope] = summary
    # dev_c1 comes last and is the sole allowed live benchmark scope.
    dump(args.out / "workload.json", dict(scope="p11_dev_c1", seeds=workload))
    with (args.out / "reference.npz").open("xb") as f:
        np.savez_compressed(f, **vectors)
    dump(args.out / "replay.json", results)
    names = ("workload.json", "reference.npz", "replay.json")
    dump(args.out / "seal.json", dict(scope="p11_dev_c1", files={n:sha(args.out/n) for n in names}))
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
