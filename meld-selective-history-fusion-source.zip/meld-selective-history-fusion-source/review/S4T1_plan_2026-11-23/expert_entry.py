"""Frozen Gemma singleton HISTORY inference for S4-T1."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time

import numpy as np

from core import CLASSES, require, sha, write_npz

P11 = Path(__file__).resolve().parents[1] / "S4P11_plan_2026-11-22"
MODEL_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("payload", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--expected-sha", required=True)
    args = parser.parse_args()
    require(not args.out.exists(), "expert output already exists")
    require(os.environ.get("HF_HUB_OFFLINE") == "1" and
            os.environ.get("TRANSFORMERS_OFFLINE") == "1", "expert must run offline")
    raw = args.payload.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == args.expected_sha, "expert input digest mismatch")
    task = json.loads(raw)
    require(set(task) == {"scope", "rows"} and task["scope"] in ("s4t1_dev_probe", "s4t1_test"),
            "expert scope mismatch")
    rows = task["rows"]
    require(bool(rows) and len(rows) <= 1566, "expert support size mismatch")
    keys = []
    for row in rows:
        require(set(row) == {"id", "history", "target"} and len(row["history"]) <= 4,
                "undeclared fields in expert row")
        keys.append(row["id"])
        for part in [row["target"], *row["history"]]:
            require(isinstance(part, list) and len(part) == 2 and
                    type(part[0]) is int and 1 <= part[0] <= 9 and
                    isinstance(part[1], str) and len(part[1]) <= 400,
                    "invalid anonymized text row")
    require(len(keys) == len(set(keys)) and sorted(keys) == keys, "expert keys must be unique and ordered")
    sys.path.insert(0, str(P11))
    from expert_p11 import (LABELS, LIMIT, MODEL, ORDERS, alternative_tokens, answer_probs,
                            frozen_logits, token_ids)
    from mlx_vlm.utils import load_model
    from transformers import AutoTokenizer

    require(tuple(LABELS) == CLASSES and sha(MODEL / "model.safetensors") == MODEL_SHA,
            "Gemma class order or weight mismatch")
    tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False)
    model = load_model(MODEL, lazy=False).eval()
    groups = alternative_tokens(tok)
    probs = np.empty((2, len(rows), len(CLASSES)), dtype=np.float64)
    counts = np.empty(probs.shape[:-1], dtype=np.int64)
    started = time.monotonic()
    for i, row in enumerate(rows):
        for j, order in enumerate(ORDERS):
            ids = token_ids(tok, row, "HISTORY", order)
            require(0 < len(ids) <= LIMIT, "token length overflow")
            probs[j, i, list(order)] = answer_probs(frozen_logits(model, tok, [ids]), groups)[0]
            counts[j, i] = len(ids)
    require(np.isfinite(probs).all() and np.all(probs >= 0)
            and np.allclose(probs.sum(-1), 1., rtol=0., atol=1e-12), "invalid expert output")
    write_npz(args.out, keys=np.asarray(keys), classes=np.asarray(CLASSES), view=np.array("HISTORY"),
              orders=np.asarray(ORDERS), p=probs, token_lengths=counts)
    print(json.dumps(dict(input_sha=args.expected_sha, output_sha=sha(args.out), batch=1,
                          model_sha=MODEL_SHA, rows=len(keys), calls=2*len(keys),
                          peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                          forward_seconds=time.monotonic()-started)))


if __name__ == "__main__":
    main()
