"""Executable synthetic tests for queue/weights, keys, and the real score gate."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import confirm as r
import core as c


class TestConfirm(unittest.TestCase):
    def test_ties_weights_identity(self):
        p = np.array([[.55, .35, .02, .02, .02, .02, .02]] * 6)
        names = ["z", "y", "x", "w", "v", "a"]
        np.testing.assert_array_equal(c.queue(p, names), [5, 4])
        q = np.zeros((2, 7))
        q[:, 1] = 1
        qidx = c.queue(p, names)
        right = c.blend(p, q, qidx, (.125,))
        wrong = c.blend(p, q, qidx, (.5,))
        np.testing.assert_allclose(right[qidx], .875*p[qidx]+.125*q, rtol=0, atol=1e-15)
        np.testing.assert_array_equal(right[:4], p[:4])
        np.testing.assert_array_equal(c.blend(p, q, qidx, (0.,)), p)
        self.assertTrue(np.all(right[qidx].argmax(1) != wrong[qidx].argmax(1)))
        with self.assertRaises(ValueError):
            c.probability(.25*right)

    def test_csv_gold_independence_and_temporal_direction(self):
        src = b'Dialogue_ID,Emotion,Utterance_ID,Speaker,Utterance\n11,neutral,3,A,"a,a"\n11,anger,8,B,b\n'
        swapped = src.replace(b"neutral", b"surprise").replace(b"anger", b"fear")
        first = c.structure(src)
        self.assertEqual(first, c.structure(swapped))
        official = np.array([[11, 8], [11, 3]])
        np.testing.assert_array_equal(r.gold_from_bytes(src, official), [6, 0])
        self.assertFalse(np.array_equal(r.gold_from_bytes(src, official),
                                        r.gold_from_bytes(swapped, official)))
        rows = c.history_rows(["a", "b"], list(first[11].values()))
        self.assertEqual(rows[0]["history"], [])
        self.assertEqual(rows[1]["history"], [[1, "a,a"]])
        with self.assertRaises(ValueError):
            r.gold_from_bytes(src, np.array([[11, 7], [11, 3]]))
        with self.assertRaises(ValueError):
            c.structure(src + b"11,sadness,8,B,b\n")
        with self.assertRaises(ValueError):
            c.order_to(["a", "b"], ["a", "a"])

    def test_asymmetric_f1_and_bootstrap_multiplicity(self):
        cm = np.zeros((7, 7), dtype=int)
        cm[:2, :2] = [[1, 0], [1, 1]]
        self.assertAlmostEqual(c.weighted_f1(cm), 200. / 3.)
        draws = c.draw_counts(3, count=20)
        self.assertTrue(np.any(draws > 1))
        np.testing.assert_array_equal(draws.sum(1), 3)

    def test_real_score_entry_and_frozen_replay(self):
        rng = np.random.default_rng(32)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run, check = root / "official", root / "check.json"
            run.mkdir()
            c.dump(check, dict(status="pass", lock_sha="fixture"))
            raw = ["Dialogue_ID,Utterance_ID,Emotion"]
            geometry, keys, official = [], [], []
            for i in range(280):
                n = 10 if i < 90 else 9
                a = [f"meld_d{1153+i:04d}::{j}" for j in range(n)]
                pairs = [[i, j] for j in range(n)]
                geometry.append(dict(keys=a, official_pairs=pairs))
                keys.extend(a)
                official.extend(pairs)
                raw.extend(f"{i},{j},{c.CLASSES[(i+j)%7]}" for j in range(n))
            block = ("\n".join(raw) + "\n").encode()
            official = np.array(official)
            self.assertEqual(len(keys), 2610)
            ar = {(s, a): rng.dirichlet(np.ones(7), len(keys)) for s in c.SEEDS for a in c.BACKBONES}
            union = sorted({keys[i] for ids in r.queues(ar, keys).values() for i in ids})
            q = rng.dirichlet(np.ones(7), (2, len(union)))
            expert = {k: q[:, j].mean(0) for j, k in enumerate(union)}
            assembled, queue = r.assemble(ar, keys, expert)
            cp = {f"{s}_{a}": dict(sha=f"sha-{s}-{a}", epoch=1, batch=2)
                  for s in c.SEEDS for a in c.BACKBONES}
            lock = dict(official_csv=dict(test="test-fixture"), checkpoints=cp,
                        expert_assets={"model.safetensors": "expert-fixture"},
                        official_test_key_sha=r.official_key_sha(official))
            c.dump(run / "geometry.json", geometry)
            c.write_npz(run / "backbones.npz", keys=np.asarray(keys), official=official, **r.encode_models(ar))
            c.dump(run / "backbones.json", {u: dict(checkpoint_sha=v["sha"], epoch=1, batch=2, rows=len(keys))
                                           for u, v in cp.items()})
            c.dump(run / "expert_input.json", dict(scope="s4t1_test", rows=[dict(id=k) for k in union]))
            c.write_npz(run / "expert_output.npz", keys=np.asarray(union), classes=np.asarray(c.CLASSES),
                        view=np.array("HISTORY"), orders=np.asarray(r.ORDERS), p=q,
                        token_lengths=np.ones(q.shape[:2], dtype=int))
            c.dump(run / "expert.json", dict(input_sha=c.sha(run/"expert_input.json"),
                                            output_sha=c.sha(run/"expert_output.npz"), batch=1,
                                            model_sha="expert-fixture", rows=len(union), calls=2*len(union)))
            c.write_npz(run / "blind.npz", keys=np.asarray(keys), official=official,
                        **{f"query_{s}": idx for s, idx in queue.items()}, **r.encode_models(assembled))
            files = {p.name: c.sha(p) for p in run.iterdir()}
            seal = dict(scope="official_meld_test", lock_sha="fixture", preflight_sha=c.sha(check),
                        official_csv_sha="test-fixture", scoring_label_reads=0, keys=2610, dialogues=280,
                        files=files, unique_expert_queries=len(union), expert_calls=2*len(union))
            with patch.multiple(r, RUN=run, PREFLIGHT=check), patch.object(r, "raw_for", return_value=block) as read:
                with self.assertRaises(FileNotFoundError):
                    r.score_test(lock, "fixture")
                read.assert_not_called()
                c.dump(run/"seal.json", seal)
                r.log("blind_sealed", sha=c.sha(run/"seal.json"))
                with self.assertRaises(ValueError):
                    r.score_test(lock, "wrong lock")
                read.assert_not_called()
                path = run/"expert.json"
                original = path.read_bytes()
                path.write_bytes(original+b"\n")
                with self.assertRaises(ValueError):
                    r.score_test(lock, "fixture")
                read.assert_not_called()
                path.write_bytes(original)
                with contextlib.redirect_stdout(io.StringIO()):
                    r.score_test(lock, "fixture")
                    r.audit_test(lock, "fixture")
                self.assertEqual(read.call_count, 1)
                self.assertTrue((run/"audit.json").exists())
                with self.assertRaises(FileExistsError):
                    r.score_test(lock, "fixture")
                self.assertEqual(read.call_count, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
