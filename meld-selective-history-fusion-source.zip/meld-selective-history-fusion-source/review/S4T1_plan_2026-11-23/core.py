"""Pure input binding, frozen decisions, and MELD dialogue-cluster scoring."""
import csv
import hashlib
import io
import json
from pathlib import Path

import numpy as np


SEEDS = (73, 101, 2026)
CLASSES = ("neutral", "surprise", "fear", "sadness", "joy", "disgust", "anger")
BACKBONES = ("MMDFN_SAME", "AUTHOR_CLASSWISE", "AUTHOR_SOFTMAX")
ARMS = ("C_BLEND", "FIXED_HISTORY", *BACKBONES)
PRIMARY = ("C_BLEND", "MMDFN_SAME")
PAIRS = (PRIMARY, ("FIXED_HISTORY", "MMDFN_SAME"), ("C_BLEND", "FIXED_HISTORY"),
         ("C_BLEND", "AUTHOR_CLASSWISE"), ("C_BLEND", "AUTHOR_SOFTMAX"),
         ("FIXED_HISTORY", "AUTHOR_CLASSWISE"), ("FIXED_HISTORY", "AUTHOR_SOFTMAX"),
         ("MMDFN_SAME", "AUTHOR_CLASSWISE"), ("MMDFN_SAME", "AUTHOR_SOFTMAX"),
         ("AUTHOR_CLASSWISE", "AUTHOR_SOFTMAX"))
BOOT_SEED = 2026112301
DRAWS = 2000


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def same_sha(path, expected):
    got = sha(path)
    require(got == expected, f"digest mismatch: {path}")
    return got


def dump(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def write_npz(path, **arrays):
    with Path(path).open("xb") as stream:
        np.savez_compressed(stream, **arrays)


def verified_bytes(path, digest):
    raw = Path(path).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == digest, f"digest mismatch: {path}")
    return raw


def npz(path, digest):
    with np.load(io.BytesIO(verified_bytes(path, digest)), allow_pickle=False) as pack:
        return dict(pack)


def projected_csv(raw, columns):
    """Project only the explicitly named columns; never return other cells."""
    stream = io.StringIO(raw.decode("utf-8-sig"), newline="")
    reader = csv.reader(stream)
    names = next(reader)
    require(len(names) == len(set(names)) and set(columns) <= set(names), "bad CSV header")
    take = [names.index(name) for name in columns]
    for row in reader:
        require(len(row) == len(names), f"bad CSV width at line {reader.line_num}")
        yield tuple(row[i] for i in take)


def structure(raw):
    dialogues = {}
    for d, u, speaker, utterance in projected_csv(
        raw, ("Dialogue_ID", "Utterance_ID", "Speaker", "Utterance")
    ):
        dialogue = dialogues.setdefault(int(d), {})
        j = int(u)
        require(j not in dialogue and j >= 0, f"duplicate or negative utterance ID {d}/{u}")
        require(speaker.strip(), f"empty speaker {d}/{u}")
        dialogue[j] = (speaker, utterance)
    return dialogues


def history_rows(keys, texts):
    """Construct frozen P11 prompts from the same ordered dialogue prefix."""
    speakers, past, rows = {}, [], []
    for key, (speaker, text) in zip(keys, texts, strict=True):
        anonymous = speakers.setdefault(speaker, len(speakers) + 1)
        target = [anonymous, " ".join(text.split())[:400]]
        rows.append(dict(id=key, target=target, history=past[-4:]))
        past.append(target)
    return rows


def order_to(expected, actual):
    lookup = {key: i for i, key in enumerate(actual)}
    require(len(lookup) == len(actual) == len(expected) == len(set(expected)),
            "duplicate key or unequal count")
    require(set(expected) == set(lookup), "missing or surplus key")
    return np.array([lookup[key] for key in expected], dtype=np.int64)


def probability(arr, tol=2e-6):
    arr = np.asarray(arr, dtype=np.float64)
    require(arr.ndim == 2 and arr.shape[1] == len(CLASSES), "wrong class axis")
    require(np.all(np.isfinite(arr)) and np.all(arr >= 0), "invalid probability")
    require(np.allclose(arr.sum(axis=1), 1., rtol=0., atol=tol), "probability does not sum to one")
    return arr


def queue(p, keys):
    p = probability(p)
    keys = np.asarray(keys)
    require(len(p) == len(keys) == len(set(keys)), "queue keys are invalid")
    top = np.sort(p, axis=1)[:, -2:]
    n = (len(keys) + 4) // 5
    return np.lexsort((keys, top[:, 1] - top[:, 0]))[:n]


def blend(p, q_on_queue, selected, alphas):
    """Replay P11's mean of full fold-local probability matrices."""
    p = probability(p)
    q = probability(q_on_queue)
    ids = np.asarray(selected)
    require(ids.ndim == 1 and np.issubdtype(ids.dtype, np.integer) and
            len(ids) == len(q) == len(set(ids)) and
            np.all((0 <= ids) & (ids < len(p))), "bad query indices")
    require(len(alphas) > 0 and all(0 <= a <= 1 for a in alphas), "invalid alpha")
    folds = []
    for alpha in alphas:
        prob = p.copy()
        prob[ids] = (1.0 - alpha) * p[ids] + alpha * q
        folds.append(prob)
    result = np.mean(folds, axis=0)
    mask = np.ones(len(p), dtype=bool)
    mask[ids] = False
    result[mask] = p[mask]
    return probability(result)


def draw_counts(n, count=DRAWS, rng_seed=BOOT_SEED):
    sampled = np.random.Generator(np.random.PCG64(rng_seed)).integers(n, size=(count, n))
    return np.stack([np.bincount(row, minlength=n) for row in sampled])


def confusion_by_dialogue(y, pred, index, n):
    width = len(CLASSES)
    idx = index * width * width + y * width + pred
    return np.bincount(idx, minlength=n * width * width).reshape(n, width, width)


def weighted_f1(cm):
    support = cm.sum(axis=-1)
    denom = support + cm.sum(axis=-2)
    tp = cm.diagonal(axis1=-2, axis2=-1)
    f1 = np.divide(2. * tp, denom, out=np.zeros_like(denom, dtype=float), where=denom > 0)
    return 100. * np.sum(support * f1, axis=-1) / np.sum(support, axis=-1)


def point(y, p, cm):
    support = cm.sum(axis=-1)
    denom = support + cm.sum(axis=-2)
    f1 = np.divide(2. * cm.diagonal(), denom, out=np.zeros_like(denom, dtype=float), where=denom > 0)
    return dict(wf1_pct=float(weighted_f1(cm)), acc_pct=float(100. * np.trace(cm) / len(y)),
                macro_f1_pct=float(100. * f1.mean()), class_f1_pct=(100. * f1).tolist(),
                support=support.tolist(), confusion=cm.tolist(),
                nll=float(-np.log(p[np.arange(len(y)), y].clip(1e-12)).mean()),
                brier=float(np.square(p - np.eye(len(CLASSES))[y]).sum(1).mean()))


def score_all(y, official_dialogue_ids, arrays, draws):
    _, index = np.unique(np.asarray(official_dialogue_ids), return_inverse=True)
    n = draws.shape[1]
    require(n == len(set(index)) and np.all(draws.sum(1) == n), "bad cluster draws")
    require(y.shape == index.shape and np.issubdtype(y.dtype, np.integer)
            and np.all((0 <= y) & (y < len(CLASSES))), "wrong gold shape or class")
    points, vectors, pred = {}, {}, {}
    for seed in SEEDS:
        for arm in ARMS:
            unit = seed, arm
            p = probability(arrays[unit])
            require(len(p) == len(y), "score row mismatch")
            pred[unit] = p.argmax(1)
            by_d = confusion_by_dialogue(y, pred[unit], index, n)
            identity = by_d.sum(axis=0)
            points[unit] = point(y, p, identity)
            drawn = (draws @ by_d.reshape(n, -1)).reshape(-1, len(CLASSES), len(CLASSES))
            vectors[unit] = weighted_f1(drawn)
    contrasts, samples = {}, {}
    for a, b in PAIRS:
        seeds = [points[s, a]["wf1_pct"] - points[s, b]["wf1_pct"] for s in SEEDS]
        v = np.mean([vectors[s, a] - vectors[s, b] for s in SEEDS], axis=0)
        key = f"{a}_minus_{b}"
        samples[key] = v
        changes = []
        for s in SEEDS:
            left, right = pred[s, a], pred[s, b]
            ch = left != right
            fix = int(np.sum(ch & (left == y)))
            harm = int(np.sum(ch & (right == y)))
            changes.append(dict(seed=s, changed=int(ch.sum()), fix=fix, harm=harm,
                                net=fix - harm, wrong_to_wrong=int(ch.sum()) - fix - harm))
        contrasts[key] = dict(mean_pp=float(np.mean(seeds)), seeds_pp=seeds,
                              sd_pp=float(np.std(seeds, ddof=1)),
                              ci95_pp=np.quantile(v, [.025, .975]).tolist(), changes=changes)
    return dict(class_order=list(CLASSES), n_utterances=len(y), n_dialogues=n,
                per_seed={f"{s}__{a}": points[s, a] for s in SEEDS for a in ARMS},
                means={a: dict(wf1_pct=float(np.mean([points[s, a]["wf1_pct"] for s in SEEDS])),
                               wf1_sd_pp=float(np.std([points[s, a]["wf1_pct"] for s in SEEDS], ddof=1)))
                       for a in ARMS},
                contrasts=contrasts), samples
