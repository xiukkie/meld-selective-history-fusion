"""S4-T1 locked MELD inference, seal, one label-binding pass, and archive audit."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pickle
import resource
import subprocess
import sys
import tempfile
import time
import traceback

import numpy as np

import core as c


PLAN = Path(__file__).resolve().parent
ROOT = PLAN.parents[1]
C1 = ROOT / "review/SOTA_C1_2026-11-19/run_20261119T225807"
P11 = ROOT / "review/S4P11_2026-11-22/run_20261122T100722468056Z"
P11_PLAN = ROOT / "review/S4P11_plan_2026-11-22"
MODEL = Path.home() / (".cache/huggingface/hub/models--mlx-community--gemma-3-4b-it-4bit/"
                       "snapshots/93724907d4ed1745d2fe50baadf3b0b01a65abf2")
MELD = ROOT / "third_party/MELD/data/MELD"
FEATURES = ROOT / "data/features/m3net"
RUN = ROOT / "review/S4T1_2026-11-23/official"
PREFLIGHT = PLAN / "dev_acceptance.json"
ALPHAS = {73: (.125, .125, .125), 101: (.25, 0., .125), 2026: (0., .25, .25)}
ORDERS = (tuple(range(7)), (4, 3, 0, 6, 1, 5, 2))
SPLITS = {"dev": (1039, 114, 1109), "test": (1153, 280, 2610)}
MAX_PROB_DRIFT = 2e-6
EXPERT_SHA = "94d3d701367d78584a9334ca00672b1c86e4aefa6a94167556c0485381e74af3"


def js(path, expected=None):
    return json.loads(path.read_bytes() if expected is None else c.verified_bytes(path, expected))


def official_key_sha(official):
    return hashlib.sha256(np.asarray(official, dtype="<i8").tobytes()).hexdigest()


def log(event, **extra):
    with (RUN / "events.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(dict(event=event, utc=datetime.now(timezone.utc).isoformat(), **extra),
                           ensure_ascii=False, allow_nan=False) + "\n")


def checked_lock(sha):
    lock = js(PLAN / "lock.json", sha)
    c.require(lock["method"] == "S4-T1.1" and lock["class_order"] == list(c.CLASSES)
              and lock["seeds"] == list(c.SEEDS) and lock["arms"] == list(c.ARMS)
              and lock["alphas"] == {str(s): list(ALPHAS[s]) for s in c.SEEDS}
              and lock["primary"] == list(c.PRIMARY) and lock["bootstrap_seed"] == c.BOOT_SEED
              and lock["bootstrap_draws"] == c.DRAWS
              and lock["expert_assets"]["model.safetensors"] == EXPERT_SHA, "experiment config mismatch")
    for name, digest in lock["assets"].items():
        c.same_sha(ROOT / name, digest)
    for name, digest in lock["expert_assets"].items():
        c.same_sha(MODEL / name, digest)
    return lock


def raw_for(split, lock):
    return c.verified_bytes(MELD / f"{split}_sent_emo.csv", lock["official_csv"][split])


def load_features(filename, lock):
    # The checked, historically used pickles are local trusted inputs. Consume
    # verified bytes, and only index explicitly declared non-label fields below.
    path = FEATURES / filename
    return pickle.loads(c.verified_bytes(path, lock["assets"][str(path.relative_to(ROOT))]),
                        encoding="latin1")


def inputs(split, lock):
    """Project official keys/text/speaker and bind to every frozen feature row."""
    from src.data import sota_b1_data as data
    from src.data.text import decode_pkl_text

    start, n_dialogues, n_rows = SPLITS[split]
    groups = c.structure(raw_for(split, lock))
    c.require(len(groups) == n_dialogues and sum(map(len, groups.values())) == n_rows,
              f"{split} official dialogue/utterance count mismatch")
    base = load_features("MELD_features_raw1.pkl", lock)
    rob = load_features("meld_features_roberta.pkl", lock)
    expected = set(range(start, start+n_dialogues))
    by_split = [set(map(int, rob[i])) for i in (8, 9, 10)]
    c.require(len(set.union(*by_split)) == sum(map(len, by_split)), "feature split overlap")
    c.require(by_split[2 if split == "dev" else 1] == expected
              and set(map(int, base[8])) == by_split[1], f"{split} feature split mismatch")
    if split == "dev":
        binding = js(ROOT / lock["dev_binding"])["dev"]
    dialogues, keys, official, text, geometry = [], [], [], {}, []
    for position, (did, utterances) in enumerate(groups.items()):
        k = start + position
        items = sorted(utterances.items())
        pairs = [[did, uid] for uid, _ in items]
        names = [pair[0] for _, pair in items]
        texts = [pair for _, pair in items]
        ids = [f"meld_d{k:04d}::{j}" for j in range(len(items))]
        normalized = [data._norm(utterance) for _, utterance in texts]
        n = len(items)
        c.require([data._norm(decode_pkl_text(v)) for v in base[6][k]] == normalized,
                  f"{split} text binding mismatch at {k}, official {did}")
        slots = data._speaker_slots(names)
        onehot = np.asarray(base[1][k], dtype=np.float32)
        c.require(onehot.shape == (n, 9) and np.all(slots < 9) and
                  np.array_equal(onehot, np.eye(9, dtype=np.float32)[slots]),
                  f"{split} speaker binding mismatch at {k}, official {did}")
        if split == "dev":
            entry = binding[str(k)]
            c.require(entry["utterance_keys"] == ids and
                      [list(map(int, pair)) for pair in entry["official"]] == pairs,
                      "dev trusted binding mismatch")
        feats = dict(text=np.asarray(rob[3][k], dtype=np.float32),
                     audio=np.asarray(base[4][k], dtype=np.float32),
                     visual=np.asarray(base[5][k], dtype=np.float32))
        for name, arr in feats.items():
            c.require(arr.shape == (n, data.spec.FEATURE_DIMS[name]) and np.isfinite(arr).all(),
                      f"{split} numeric feature mismatch {k}/{name}")
        dialogues.append(data.SotaDialogue(
            dialogue_id=f"meld_d{k:04d}", official_dialogue_id=str(did), split=split,
            utterance_ids=ids, official_utterance_ids=[f"{d}::{u}" for d, u in pairs],
            speaker_ids=slots, speaker_onehot=onehot, features=feats, p_index=data._p_index(slots)))
        keys.extend(ids)
        official.extend(pairs)
        text.update({row["id"]: row for row in c.history_rows(ids, texts)})
        geometry.append(dict(internal_id=k, official_pairs=pairs, keys=ids, speaker_slots=slots.tolist()))
    c.require(len(set(keys)) == n_rows and len(set(map(tuple, official))) == n_rows,
              "geometry has duplicate keys")
    official = np.array(official)
    if split == "test":
        c.require(official_key_sha(official) == lock["official_test_key_sha"],
                  "test ordered official key digest mismatch")
    return dialogues, keys, official, text, geometry


def predict_backbones(dialogues, expected, lock, report=None):
    import torch
    from src.data.sota_b1_data import collate
    from model_c1 import model, forward

    torch.set_num_threads(5)
    torch.set_num_interop_threads(15)
    records, outputs = {}, {}
    for s in c.SEEDS:
        for arm in c.BACKBONES:
            since = time.monotonic()
            unit = f"{s}_{arm}"
            ref = lock["checkpoints"][unit]
            path = C1 / "fits" / unit / "best.pt"
            c.same_sha(path, ref["sha"])
            chk = torch.load(path, map_location="cpu", weights_only=True)
            c.require(chk["unit"] == unit and chk["epoch"] == ref["epoch"],
                      f"wrong checkpoint binding {unit}")
            net = model(arm)
            net.load_state_dict(chk["state"], strict=True)
            del chk
            net.eval()
            gathered, keys = [], []
            with torch.inference_mode():
                for start in range(0, len(dialogues), ref["batch"]):
                    b = collate(dialogues[start:start+ref["batch"]])
                    out = forward(net, arm, b)
                    lp = out if arm == "MMDFN_SAME" else out[3][b["umask"].T.bool()]
                    c.require(tuple(lp.shape) == (len(b["keys"]), len(c.CLASSES)) and
                              bool(torch.isfinite(lp).all()) and
                              bool(torch.abs(torch.logsumexp(lp, 1)).max() <= 2e-6),
                              f"invalid logits/row counts {unit}")
                    keys.extend(b["keys"])
                    gathered.append(lp.exp().cpu().numpy())
            del net, out, lp, b
            p = np.concatenate(gathered)
            c.require(keys == expected, f"backbone forward order mismatch {unit}")
            outputs[s, arm] = c.probability(p)
            records[unit] = dict(seconds=time.monotonic()-since, rows=len(p), epoch=ref["epoch"],
                                 checkpoint_sha=ref["sha"], batch=ref["batch"])
            if report:
                report("backbone_complete", unit=unit, **records[unit])
    return outputs, records


def queues(arrays, keys):
    return {s: c.queue(arrays[s, "MMDFN_SAME"], keys) for s in c.SEEDS}


def assemble(arrays, keys, bank):
    result = dict(arrays)
    query = queues(arrays, keys)
    union = {keys[i] for ids in query.values() for i in ids}
    c.require(set(bank) == union, "expert cache missing or surplus queries")
    for s, ids in query.items():
        p = arrays[s, "MMDFN_SAME"]
        q = np.stack([bank[keys[i]] for i in ids])
        for name, alpha in (("C_BLEND", ALPHAS[s]), ("FIXED_HISTORY", (.125,))):
            result[s, name] = c.blend(p, q, ids, alpha)
    return result, query


def run_expert(directory, name, rows, scope, timeout):
    inp = directory / f"{name}_input.json"
    out = directory / f"{name}_output.npz"
    c.dump(inp, dict(scope=scope, rows=rows))
    digest = c.sha(inp)
    env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
               PYTHONDONTWRITEBYTECODE="1", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    exe = P11_PLAN / ".pilot_env/bin/python"
    start = time.monotonic()
    with (directory / f"{name}_stdout.log").open("x") as stdout, (
            directory / f"{name}_stderr.log").open("x") as stderr:
        subprocess.run([str(exe), str(PLAN / "expert_entry.py"), str(inp), str(out),
                        "--expected-sha", digest], cwd=ROOT, env=env,
                       stdout=stdout, stderr=stderr, check=True, timeout=timeout)
    meta = json.loads((directory / f"{name}_stdout.log").read_text().splitlines()[-1])
    meta["wall_seconds"] = time.monotonic() - start
    c.require(meta["input_sha"] == digest, "expert returned wrong input identity")
    z = c.npz(out, meta["output_sha"])
    c.require(meta["batch"] == 1 and meta["rows"] == len(rows) and meta["calls"] == 2*len(rows)
              and meta["model_sha"] == EXPERT_SHA,
              "expert runtime identity mismatch")
    q = expert_bank(z, [r["id"] for r in rows])
    return q, meta


def expert_bank(z, keys):
    c.require(list(z["keys"]) == keys and list(z["classes"]) == list(c.CLASSES) and
              str(z["view"]) == "HISTORY" and z["orders"].tolist() == [list(o) for o in ORDERS]
              and z["p"].shape == (2, len(keys), len(c.CLASSES))
              and z["token_lengths"].shape == (2, len(keys))
              and np.all((z["token_lengths"] > 0) & (z["token_lengths"] <= 512)),
              "wrong expert output schema or row binding")
    for row in z["p"]:
        c.probability(row, tol=1e-12)
    return {key: z["p"][:, i].mean(axis=0) for i, key in enumerate(keys)}


def archived_dev_bank(expected, text):
    shards = js(P11 / "export/shard_manifest.json")["shards"]
    ref, full = {}, {}
    for shard in shards:
        if shard["scope"] != "historical_dev":
            continue
        piece = shard["index"]
        meta = js(P11 / "expert" / f"expert_log_{piece:03d}.json")
        obj = js(Path(shard["path"]), shard["sha"])
        z = c.npz(P11 / "expert" / f"expert_out_{piece:03d}.npz", meta["output_sha"])
        c.require(meta["input_sha"] == shard["sha"] and meta["batch_mode"] == 1 and
                  meta["checkpoint_sha"] == EXPERT_SHA
                  and list(z["keys"]) == shard["keys"] and list(z["classes"]) == list(c.CLASSES)
                  and list(z["views"]) == ["CURRENT", "HISTORY", "SHAM"],
                  "old expert shard identity mismatch")
        for i, row in enumerate(obj["rows"]):
            key = row["id"]
            c.require(key == z["keys"][i] and key not in ref, "bad dev expert key identity")
            c.require(text[key] == {k: row[k] for k in ("id", "target", "history")},
                      f"expert dev prompt transport mismatch {key}")
            ref[key] = z["probabilities"][1, :, i].mean(0)
            full[key] = z["probabilities"][1, :, i]
    c.require(set(expected) <= set(ref), "dev expert cache does not cover frozen queue")
    return {k: ref[k] for k in expected}, full


def run_dev_check(lock, lock_sha, output):
    start = time.monotonic()
    dialogues, keys, official, text, _ = inputs("dev", lock)
    p, seconds = predict_backbones(dialogues, keys, lock)
    c1_drift = {}
    for s in c.SEEDS:
        for arm in c.BACKBONES:
            unit = f"{s}_{arm}"
            epoch = lock["checkpoints"][unit]["epoch"]
            path = C1 / "fits" / unit / f"epoch_{epoch:03d}.npz"
            old = c.npz(path, lock["assets"][str(path.relative_to(ROOT))])
            np.testing.assert_array_equal(official, old["keys"])
            np.testing.assert_array_equal(p[s, arm].argmax(1), old["p"].argmax(1))
            d = float(np.abs(p[s, arm] - old["p"]).max())
            c.require(d <= MAX_PROB_DRIFT, f"dev checkpoint parity failed {s}/{arm}")
            c1_drift[unit] = d
    seal = js(P11 / "blind/dev_c1_seal.json")
    c.same_sha(P11 / "fit/fits.json", seal["fits_sha"])
    archive = c.npz(P11 / "blind/dev_c1_blind.npz", seal["predictions_sha"])
    # Queue parity must hold on real backbone outputs, not just on archived p0.
    queue_now = queues(p, keys)
    for s in c.SEEDS:
        np.testing.assert_array_equal(keys, archive[f"{s}__keys"])
        np.testing.assert_array_equal(ALPHAS[s], archive[f"{s}__alphas"])
        np.testing.assert_array_equal(queue_now[s], archive[f"{s}__mask_0.2"])
    union = sorted({keys[i] for ids in queue_now.values() for i in ids})
    bank, old_full = archived_dev_bank(union, text)
    result, _ = assemble(p, keys, bank)
    blend_drift = {}
    for s in c.SEEDS:
        np.testing.assert_array_equal(result[s, "C_BLEND"].argmax(1), archive[f"{s}__C_BLEND"])
        d = float(np.abs(result[s, "C_BLEND"] - archive[f"{s}__p_C_BLEND"]).max())
        c.require(d <= MAX_PROB_DRIFT, "dev C_BLEND probability drift")
        blend_drift[s] = d
    # Predictions changed by the 50/50 legacy bug must be caught on actual dev.
    changed = 0
    for s, ids in queue_now.items():
        new = result[s, "FIXED_HISTORY"]
        bad = c.blend(p[s, "MMDFN_SAME"], np.stack([bank[keys[i]] for i in ids]), ids, (.5,))
        np.testing.assert_array_equal(bad.argmax(1), archive[f"{s}__FIXED_HISTORY"])
        changed += int(np.sum(new.argmax(1) != bad.argmax(1)))
    c.require(changed == 303, f"fixed-weight regression fixture changed: {changed}")
    # Real dev traverses the same keyed label join, scorer and independent check.
    y = gold_from_bytes(raw_for("dev", lock), official)
    draws = c.draw_counts(114)
    dev_metrics, samples = c.score_all(y, official[:, 0], result, draws)
    frozen = dict(y=y, cluster_draw_counts=draws, **samples)
    dev_audit = verify_scores(official, result, frozen, dev_metrics)
    expected_wf1 = [66.25451214776382, 66.21582991800267, 65.78000283605017,
                    62.75963141900977, 63.22466837959187]
    dev_means = {a: dev_metrics["means"][a]["wf1_pct"] for a in c.ARMS}
    np.testing.assert_allclose(list(dev_means.values()), expected_wf1, rtol=0, atol=1e-8)
    indices = np.linspace(0, len(union)-1, 8, dtype=int)
    sample = [union[i] for i in indices]
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="mel_dev_parity_") as tmp:
        only, meta = run_expert(Path(tmp), "probe", [text[k] for k in sample], "s4t1_dev_probe", 180)
        z = c.npz(Path(tmp) / "probe_output.npz", meta["output_sha"])
        expected = np.stack([old_full[key] for key in sample], axis=1)
        expert_drift = float(np.abs(z["p"] - expected).max())
        np.testing.assert_array_equal(z["p"].argmax(-1), expected.argmax(-1))
        c.require(expert_drift <= 2e-5 and len(only) == 8, "single-row expert dev parity failed")
        c.require(len(set(sample)) == 8, "duplicate spot check")
    c.dump(output, dict(status="pass", scope="dev_only", lock_sha=lock_sha, n=len(keys),
                        backbone_max_p_drift=c1_drift, c_blend_max_p_drift=blend_drift,
                        fixed_weight_negative_control_changed=changed, sampled_expert_keys=sample,
                        expert_max_p_drift=expert_drift, expert_probe=meta,
                        dev_means=dev_means, dev_audit=dev_audit,
                        timings=seconds, seconds=time.monotonic()-start))
    print(output)


def encode_models(result):
    return {f"p__{s}__{arm}": p for (s, arm), p in result.items()}


def decode_models(z, arms):
    expected = {f"p__{s}__{a}" for s in c.SEEDS for a in arms}
    c.require(expected == {key for key in z if key.startswith("p__")}, "wrong unit or arm matrix")
    return {(s, a): c.probability(z[f"p__{s}__{a}"]) for s in c.SEEDS for a in arms}


def predict_test(lock, lock_sha):
    c.require(js(PREFLIGHT)["status"] == "pass" and js(PREFLIGHT)["lock_sha"] == lock_sha,
              "missing dev acceptance for this lock")
    RUN.parent.mkdir(parents=True, exist_ok=True)
    RUN.mkdir(exist_ok=False)
    log("formal_prediction_start", lock_sha=lock_sha)
    try:
        start = time.monotonic()
        dialogues, keys, official, text, geometry = inputs("test", lock)
        c.dump(RUN / "geometry.json", geometry)
        log("blind_test_columns_projected", columns=["Dialogue_ID", "Utterance_ID", "Speaker", "Utterance"],
            n=len(keys))
        arrays, records = predict_backbones(dialogues, keys, lock, report=log)
        c.write_npz(RUN / "backbones.npz", keys=np.asarray(keys), official=official,
                    **encode_models(arrays))
        c.dump(RUN / "backbones.json", records)
        union = sorted({keys[i] for ids in queues(arrays, keys).values() for i in ids})
        del dialogues
        bank, meta = run_expert(RUN, "expert", [text[k] for k in union], "s4t1_test", 2400)
        c.dump(RUN / "expert.json", meta)
        result, query = assemble(arrays, keys, bank)
        c.write_npz(RUN / "blind.npz", keys=np.asarray(keys), official=official,
                    **{f"query_{s}": j for s, j in query.items()}, **encode_models(result))
        files = ("geometry.json", "backbones.npz", "backbones.json", "expert_input.json",
                 "expert_output.npz", "expert.json", "blind.npz")
        seal = dict(scope="official_meld_test", lock_sha=lock_sha, preflight_sha=c.sha(PREFLIGHT),
                    official_csv_sha=lock["official_csv"]["test"], scoring_label_reads=0,
                    files={n: c.sha(RUN / n) for n in files}, keys=len(keys), dialogues=len(geometry),
                    unique_expert_queries=len(union), expert_calls=2*len(union), seconds=time.monotonic()-start,
                    backbone_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        c.dump(RUN / "seal.json", seal)
        log("blind_sealed", sha=c.sha(RUN / "seal.json"))
    except BaseException as exc:
        log("failed", stage="blind", error=repr(exc), trace=traceback.format_exc())
        raise


def verified_blind(lock, lock_sha):
    seal = js(RUN / "seal.json")
    events = [json.loads(x) for x in (RUN / "events.jsonl").read_text().splitlines()]
    expected = [x["sha"] for x in events if x["event"] == "blind_sealed"]
    c.require(expected == [c.sha(RUN / "seal.json")], "no unique original seal digest")
    c.require(seal["scope"] == "official_meld_test" and seal["lock_sha"] == lock_sha
              and seal["official_csv_sha"] == lock["official_csv"]["test"] and
              seal["preflight_sha"] == c.sha(PREFLIGHT) and seal["scoring_label_reads"] == 0
              and seal["keys"] == 2610 and seal["dialogues"] == 280, "wrong test seal identity")
    fs = seal["files"]
    required = ("geometry.json", "backbones.npz", "backbones.json", "expert_input.json",
                "expert_output.npz", "expert.json", "blind.npz")
    c.require(set(fs) == set(required), "wrong seal file set")
    geometry = js(RUN / "geometry.json", fs["geometry.json"])
    back = c.npz(RUN / "backbones.npz", fs["backbones.npz"])
    expert = c.npz(RUN / "expert_output.npz", fs["expert_output.npz"])
    inp = js(RUN / "expert_input.json", fs["expert_input.json"])
    meta = js(RUN / "expert.json", fs["expert.json"])
    models = js(RUN / "backbones.json", fs["backbones.json"])
    blind = c.npz(RUN / "blind.npz", fs["blind.npz"])
    c.require(inp["scope"] == "s4t1_test" and meta["input_sha"] == fs["expert_input.json"]
              and meta["output_sha"] == fs["expert_output.npz"] and meta["batch"] == 1 and
              meta["model_sha"] == lock["expert_assets"]["model.safetensors"], "expert seal mismatch")
    c.require(set(models) == set(lock["checkpoints"]), "checkpoint metadata units mismatch")
    for unit, ref in lock["checkpoints"].items():
        c.require(models[unit]["checkpoint_sha"] == ref["sha"] and models[unit]["epoch"] == ref["epoch"]
                  and models[unit]["rows"] == 2610 and models[unit]["batch"] == ref["batch"],
                  f"wrong checkpoint in archive {unit}")
    keys = [k for g in geometry for k in g["keys"]]
    official = np.array([pair for g in geometry for pair in g["official_pairs"]])
    c.require(len(set(keys)) == len(keys) == seal["keys"] and
              len(set(map(tuple, official))) == len(keys) and
              len({int(d) for d in official[:, 0]}) == len(geometry) == seal["dialogues"]
              and official_key_sha(official) == lock["official_test_key_sha"],
              "non-unique archived geometry")
    for z in (back, blind):
        np.testing.assert_array_equal(z["keys"], keys)
        np.testing.assert_array_equal(z["official"], official)
    allowed_models = {f"p__{s}__{a}" for s in c.SEEDS for a in c.ARMS}
    c.require(set(blind) == allowed_models | {"keys", "official"} | {f"query_{s}" for s in c.SEEDS},
              "unexpected column in sealed forecast")
    c.require(set(back) == {f"p__{s}__{a}" for s in c.SEEDS for a in c.BACKBONES} | {"keys", "official"},
              "unexpected column in frozen backbone archive")
    bank = expert_bank(expert, [row["id"] for row in inp["rows"]])
    c.require(len(bank) == meta["rows"] == seal["unique_expert_queries"]
              and 2*len(bank) == meta["calls"] == seal["expert_calls"], "expert count mismatch")
    ar, queue = assemble(decode_models(back, c.BACKBONES), keys, bank)
    for s in c.SEEDS:
        np.testing.assert_array_equal(queue[s], blind[f"query_{s}"])
    for key, p in decode_models(blind, c.ARMS).items():
        np.testing.assert_array_equal(ar[key], p)
    return official, ar, seal


def gold_from_bytes(raw, official):
    tags = {}
    for d, u, emotion in c.projected_csv(raw, ("Dialogue_ID", "Utterance_ID", "Emotion")):
        k = int(d), int(u)
        c.require(k not in tags and emotion in c.CLASSES, f"invalid test label key/class {k}")
        tags[k] = c.CLASSES.index(emotion)
    c.require(set(tags) == set(map(tuple, official)), "gold/forecast keys differ")
    return np.array([tags[tuple(k)] for k in official], dtype=np.int64)


def score_test(lock, lock_sha):
    official, ar, _ = verified_blind(lock, lock_sha)
    with (RUN / "score_entered").open("x") as f:
        f.write(c.sha(RUN / "seal.json") + "\n")
    try:
        log("scoring_label_read_started")
        y = gold_from_bytes(raw_for("test", lock), official)
        draws = c.draw_counts(280)
        metrics, diffs = c.score_all(y, official[:, 0], ar, draws)
        c.write_npz(RUN / "scored.npz", official=official, y=y, cluster_draw_counts=draws, **diffs)
        c.dump(RUN / "metrics.json", metrics)
        c.dump(RUN / "score_seal.json", dict(lock_sha=lock_sha, blind_seal_sha=c.sha(RUN / "seal.json"),
                                             metrics_sha=c.sha(RUN / "metrics.json"),
                                             scored_sha=c.sha(RUN / "scored.npz")))
        log("score_complete", score_seal_sha=c.sha(RUN / "score_seal.json"))
        print(json.dumps(metrics["contrasts"]["C_BLEND_minus_MMDFN_SAME"], indent=2))
    except BaseException as exc:
        log("failed", stage="score", error=repr(exc), trace=traceback.format_exc())
        raise


def verify_scores(official, models, frozen, metrics):
    """Independent supports × predictions reduction and sklearn point check."""
    from sklearn.metrics import f1_score

    y = frozen["y"]
    n = len(np.unique(official[:, 0]))
    weights = frozen["cluster_draw_counts"]
    np.testing.assert_array_equal(weights, c.draw_counts(n))
    _, d = np.unique(official[:, 0], return_inverse=True)
    width = len(c.CLASSES)
    vectors = {}
    for (s, arm), p in models.items():
        pred = p.argmax(1)
        seed = metrics["per_seed"][f"{s}__{arm}"]
        wf1 = f1_score(y, pred, average="weighted", zero_division=0)*100.
        macro = f1_score(y, pred, average="macro", labels=range(width), zero_division=0)*100.
        np.testing.assert_allclose([wf1, macro], [seed["wf1_pct"], seed["macro_f1_pct"]],
                                   rtol=0., atol=1e-10)
        gold = np.zeros((n, width), dtype=np.int64)
        guessed, hit = np.zeros_like(gold), np.zeros_like(gold)
        np.add.at(gold, (d, y), 1)
        np.add.at(guessed, (d, pred), 1)
        keep = pred == y
        np.add.at(hit, (d[keep], y[keep]), 1)
        g, p_count, h = weights @ gold, weights @ guessed, weights @ hit
        denom = g + p_count
        f = np.divide(2*h, denom, out=np.zeros_like(h, dtype=float), where=denom > 0)
        vectors[s, arm] = 100*(g*f).sum(1)/g.sum(1)
    for a, b in c.PAIRS:
        k = f"{a}_minus_{b}"
        calc = np.mean([vectors[s, a] - vectors[s, b] for s in c.SEEDS], axis=0)
        np.testing.assert_allclose(calc, frozen[k], rtol=0., atol=1e-10)
        np.testing.assert_allclose(np.quantile(calc, [.025, .975]), metrics["contrasts"][k]["ci95_pp"],
                                   rtol=0., atol=1e-10)
    return dict(points_checked=len(models), contrasts_recomputed=len(c.PAIRS))


def audit_test(lock, lock_sha):
    official, ar, _ = verified_blind(lock, lock_sha)
    score_seal = js(RUN / "score_seal.json")
    c.require(score_seal["lock_sha"] == lock_sha and score_seal["blind_seal_sha"] == c.sha(RUN / "seal.json"),
              "score seal does not consume original blind seal")
    metrics = js(RUN / "metrics.json", score_seal["metrics_sha"])
    scored = c.npz(RUN / "scored.npz", score_seal["scored_sha"])
    np.testing.assert_array_equal(scored["official"], official)
    result = verify_scores(official, ar, scored, metrics)
    c.dump(RUN / "audit.json", dict(status="pass", **result, score_seal_sha=c.sha(RUN / "score_seal.json")))
    print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check", "predict", "score", "audit"))
    parser.add_argument("--lock-sha", required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(C1))
    lock = checked_lock(args.lock_sha)
    if args.command == "check":
        if PREFLIGHT.exists():
            p = js(PREFLIGHT)
            c.require(p["status"] == "pass" and p["lock_sha"] == args.lock_sha, "stale dev acceptance")
            print(f"reuse {PREFLIGHT}")
        else:
            run_dev_check(lock, args.lock_sha, PREFLIGHT)
    elif args.command == "predict":
        predict_test(lock, args.lock_sha)
    elif args.command == "score":
        score_test(lock, args.lock_sha)
    else:
        audit_test(lock, args.lock_sha)


if __name__ == "__main__":
    main()
