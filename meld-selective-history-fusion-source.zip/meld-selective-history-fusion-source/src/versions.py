"""版本常量：本项目代码版本之外的固定上游与特征版本。"""
from __future__ import annotations

# 2026-11-14 审计时固定的上游提交（详见 review/S0S1_*/03_上游审计.md）
UPSTREAM_COMMITS = {
    "M3NET": "4d0fa88cd4f92c72b053527e877763f54e29ccb2",       # 2023-12-05
    "HAUCL": "6a295b878f4faacac4b0cb5539debf2fdc056bb8",       # 2024-08-13
    "MELD_repo": "e8cedf27b5d2877e198332c957127e16eb214afe",    # 2026-05-17
    "conv-emotion_COSMIC": "6128ca20e9c736605cce7e99d5d95db0356c35f5",  # 2024-03-10，仅读取特征生产代码
    "MM-DFN": "da970366069247e05de3b9298f1e1bbc5c77a187",      # 2023-04-21，仅读取代码与数据来源说明
}

# 特征包版本：M3NET 官方 Dropbox 链接（2022-11-19 与 2023-10-23 打包）
FEATURE_SET_VERSION = "m3net-dropbox-2022-11-19+2023-10-23"

FEATURE_SHA256 = {
    "IEMOCAP_features.pkl": "ceb5cc9a45d1792998438e27f86a12642320aa6315546e4425316140ea503fb3",
    "MELD_features_raw1.pkl": "d043b3ec1813c8917e2067af01e933ff0892d33d19d93595098aaf88c4b200b0",
    "iemocap_features_roberta.pkl": "4bd60c581a5b7c70e217e18439f741b191605fbd6f2cf4dc1a6dcb7fcaa18f06",
    "meld_features_roberta.pkl": "58b2bdadc2eaec6abb40ac0cb3ffa3f31e929d636ece8197aecf1ca373a92951",
}

# 官方数据下载入口（审计记录用；S1 未重新下载原始 MELD 音视频）
DATA_SOURCES = {
    "MELD_raw": "https://huggingface.co/datasets/declare-lab/MELD",
    "MELD_official_splits": "https://github.com/declare-lab/MELD/tree/master/data/MELD",
    "IEMOCAP_raw": "本地 ~/Downloads/IEMOCAP_full_release（用户已有，未从网络下载）",
    "M3NET_features": "https://www.dropbox.com/sh/4b21lympehwdg4l/AADXMURD5uCECN_pvvJpCAy9a?dl=0",
}
