"""SOTA-B1 SDT adapter: interface-only wrapper around the fixed upstream model.

Upstream: third_party/classwise-multimodal-ERC @ 6f9c6b8d9211edd9a0dc41f54c49d0c88157cd6b
multimodal/model.py Transformer_Based_Model is imported UNMODIFIED (read-only source).
The adapter only converts batch layout and assembles the task-book loss:

    CE_fused + 0.5 * mean_m(CE_m) + 0.1 * tau^2 * mean_m(KL(p_teacher^tau || p_m^tau))

with tau=8, teacher = fused temperature-softened posterior DETACHED, no class
weights, upstream MaskedNLLLoss / MaskedKLDivLoss applied to the upstream
temperature-softened log p_m^tau and p_teacher^tau (no second softmax on log-probs).

Differences from the public train.py (declared local adaptations, task book §4):
- mean over modalities with weights 0.5 / 0.1*tau^2 (upstream uses sums, gamma=1);
- teacher detached (upstream softmax mode passes it undetached);
- labels=None always (upstream passes train labels for the contrastive branch,
  which is disabled here by con_temperature=0);
- hidden_dim=256 local dev width (paper shared width 1024);
- dev-only selection replaces the upstream per-epoch test selection.
"""
from __future__ import annotations

import importlib.util
import os

import torch
import torch.nn.functional as F

from ..training import sota_b1_spec as spec

_UPSTREAM_MODEL_PY = os.path.join(spec.UPSTREAM_DIR, "multimodal", "model.py")


def _load_upstream_module():
    import hashlib
    with open(_UPSTREAM_MODEL_PY, "rb") as f:
        file_sha = hashlib.sha256(f.read()).hexdigest()
    s = importlib.util.spec_from_file_location("sota_b1_upstream_model", _UPSTREAM_MODEL_PY)
    mod = importlib.util.module_from_spec(s)
    s.loader.exec_module(mod)
    mod._SOTA_B1_SOURCE_SHA = file_sha
    return mod


UP = _load_upstream_module()
UPSTREAM_MODEL_SHA = UP._SOTA_B1_SOURCE_SHA

# modules that exist in the upstream class but are unreachable under the frozen
# softmax / no-disentangle configuration (no gradient path, recorded not deleted)
UNREACHABLE_PREFIXES = (
    "disent_t.", "disent_a.", "disent_v.",
    "reliability_gate.", "scalar_reliability_gate.", "transformer_reliability_gate.",
)
FROZEN_IDENTITY_PREFIXES = tuple(
    f"{n}_gate.fc." for n in ("t_t", "a_t", "v_t", "a_a", "t_a", "v_a", "v_v", "t_v", "a_v")
)


def sdt_kwargs() -> dict:
    c = spec.SDT
    return dict(
        dataset="MELD", temp=c["temp"], D_text=c["d_text"], D_visual=c["d_visual"],
        D_audio=c["d_audio"], n_head=c["n_head"], n_classes=c["n_classes"],
        hidden_dim=c["hidden_dim"], n_speakers=c["n_speakers"], dropout=c["dropout"],
        modal_dropout=c["modal_dropout"], dropout_strategy=c["dropout_strategy"],
        fusion_mode=c["fusion_mode"], con_temperature=c["con_temperature"],
        use_disentangle=c["use_disentangle"], use_intra_visual_gate=c["use_intra_visual_gate"],
        use_speaker_embeddings=c["use_speaker_embeddings"],
        use_landmark_mlp=c["use_landmark_mlp"], gate_dim=c["gate_dim"],
        circumplex_alpha=c["circumplex_alpha"], va_map=None,
    )


def build_sdt() -> torch.nn.Module:
    return UP.Transformer_Based_Model(**sdt_kwargs())


def param_census(model) -> dict:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    unreachable, frozen = 0, 0
    for name, p in model.named_parameters():
        if name.startswith(UNREACHABLE_PREFIXES):
            unreachable += p.numel()
        elif name.startswith(FROZEN_IDENTITY_PREFIXES):
            frozen += p.numel()
    return {"total": int(total), "trainable": int(trainable),
            "unreachable_no_grad_path": int(unreachable),
            "frozen_identity_gates": int(frozen),
            "effective_trainable": int(trainable - unreachable)}


def to_upstream_batch(batch: dict) -> dict:
    """Project collate -> upstream layout. Upstream forward takes time-major
    feature tensors [T,B,D] (its Conv1d path permutes internally) but batch-major
    u_mask [B,T] and qmask [B,T,9] (the public dataloader permutes qmask only).
    No labels anywhere."""
    qmask = batch["qmask"].permute(1, 0, 2).contiguous()
    umask = batch["umask"].permute(1, 0).contiguous()
    return {"textf": batch["text"], "visuf": batch["visual"], "acouf": batch["audio"],
            "u_mask": umask, "qmask": qmask, "dia_len": list(batch["lengths"])}


def sdt_forward(model, batch: dict):
    ub = to_upstream_batch(batch)
    # labels=None always: the contrastive branch is disabled (con_temperature=0)
    # and no label tensor may reach the model.
    return model(ub["textf"], ub["visuf"], ub["acouf"], ub["u_mask"], ub["qmask"],
                 ub["dia_len"], labels=None)


def sdt_loss(outputs, flat_labels: torch.Tensor, umask_bt: torch.Tensor, tau: int = 8):
    """Task-book §4 loss on valid rows only; padding contributes zero value/grad.

    outputs: upstream 11-tuple. flat_labels: [B*T] long (padding entries 0, masked).
    umask_bt: [B,T] valid mask.
    """
    (t_lp, a_lp, v_lp, all_lp, all_p,
     kl_t_lp, kl_a_lp, kl_v_lp, kl_all_p, con_loss, orth_loss) = outputs
    assert con_loss is None and orth_loss is None
    mask = umask_bt.reshape(-1)
    nll = UP.MaskedNLLLoss()
    kl = UP.MaskedKLDivLoss()

    def ce(lp):
        return nll(lp.reshape(-1, lp.size(-1)), flat_labels, mask)

    def kld(lp):
        return kl(lp.reshape(-1, lp.size(-1)), kl_all_p.detach().reshape(-1, kl_all_p.size(-1)), mask)

    ce_fused = ce(all_lp)
    ce_modal = (ce(t_lp) + ce(a_lp) + ce(v_lp)) / 3.0
    kl_modal = (kld(kl_t_lp) + kld(kl_a_lp) + kld(kl_v_lp)) / 3.0
    loss = ce_fused + 0.5 * ce_modal + 0.1 * (tau ** 2) * kl_modal
    parts = {"ce_fused": float(ce_fused.item()), "ce_modal_mean": float(ce_modal.item()),
             "kl_modal_mean": float(kl_modal.item()), "total": float(loss.item())}
    return loss, parts


def sdt_dev_outputs(outputs, umask_bt: torch.Tensor) -> dict:
    """Un-tempered fused distribution + three modality heads for dev rows."""
    (t_lp, a_lp, v_lp, all_lp, all_p, *_rest) = outputs
    mask = umask_bt.bool()
    return {
        "fused_logp": all_lp[mask].detach().cpu(),
        "fused_probs": all_p[mask].detach().cpu(),
        "text_logp": t_lp[mask].detach().cpu(),
        "audio_logp": a_lp[mask].detach().cpu(),
        "visual_logp": v_lp[mask].detach().cpu(),
    }