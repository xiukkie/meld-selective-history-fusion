"""S2-D1 M3Net adaptation (fixed upstream commit 4d0fa88).

This is an independent dense-tensor implementation of the public method's
documented path: multimodal GRU encoders, speaker embedding, multivariate
hypergraph (modality + utterance hyperedges), high-frequency modality graph,
and the original concat_DHT classifier. It does not copy or execute the
unlicensed upstream source; HypergraphConv/highConv formulas are implemented
from the paper/code correspondence recorded in the delivery report.

Not the official upstream run. No CUDA/PyG dependency.
"""
from __future__ import annotations

import itertools
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class DenseHypergraphConv(nn.Module):
    """HypergraphConv(use_attention=False) from upstream, dense/index_add equivalent."""

    def __init__(self, in_channels: int, out_channels: int, bias: bool = True):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.weight = nn.Parameter(torch.empty(in_channels, out_channels))
        self.edgeweight = nn.Parameter(torch.empty(in_channels, out_channels))
        self.bias = nn.Parameter(torch.zeros(out_channels)) if bias else None
        nn.init.xavier_uniform_(self.weight)
        nn.init.xavier_uniform_(self.edgeweight)

    def forward(self, x, hyperedge_index, hyperedge_weight, EW_weight):
        node, edge = hyperedge_index[0], hyperedge_index[1]
        n, m = x.size(0), int(edge.max().item()) + 1
        D = torch.zeros(n, device=x.device, dtype=x.dtype).index_add_(
            0, node, hyperedge_weight[edge])
        D = torch.where(D > 0, 1.0 / D, torch.zeros_like(D))
        B = torch.zeros(m, device=x.device, dtype=x.dtype).index_add_(
            0, edge, EW_weight[node])
        B = torch.where(B > 0, 1.0 / B, torch.zeros_like(B))
        edge_sum = torch.zeros(m, x.size(1), device=x.device, dtype=x.dtype).index_add_(
            0, edge, x[node] * B[edge].unsqueeze(-1))
        node_sum = torch.zeros_like(x).index_add_(
            0, node, edge_sum[edge] * D[node].unsqueeze(-1))
        if self.bias is not None:
            node_sum = node_sum + self.bias
        return F.leaky_relu(node_sum)


class HighFrequencyConv(nn.Module):
    """highConv from upstream: degree-normalized gated difference propagation."""

    def __init__(self, in_channels: int):
        super().__init__()
        self.gate = nn.Linear(2 * in_channels, 1)

    def forward(self, x, edge_index):
        row, col = edge_index
        deg = torch.zeros(x.size(0), device=x.device, dtype=x.dtype).index_add_(
            0, row, torch.ones(row.numel(), device=x.device, dtype=x.dtype))
        deg_inv_sqrt = torch.where(deg > 0, deg.pow(-0.5), torch.zeros_like(deg))
        norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]
        alpha = torch.tanh(self.gate(torch.cat([x[row], x[col]], dim=1))).squeeze(-1)
        msg = norm.unsqueeze(-1) * x[col] * alpha.unsqueeze(-1)
        out = torch.zeros_like(x).index_add_(0, row, msg)
        return out


class M3NetHypergraph(nn.Module):
    def __init__(self, a_dim: int, v_dim: int, l_dim: int, n_dim: int, nhidden: int,
                 nclass: int, dropout: float, n_speakers: int, modals=('a', 'v', 'l'),
                 use_speaker=True, use_modal=False, num_L=3, num_K=3):
        super().__init__()
        self.modals = list(modals)
        self.n_speakers = int(n_speakers)
        self.use_speaker = bool(use_speaker)
        self.use_modal = bool(use_modal)
        self.n_dim = int(n_dim)
        self.nhidden = int(nhidden)
        self.num_L = int(num_L)
        self.num_K = int(num_K)
        self.dropout = float(dropout)
        self.speaker_embeddings = nn.Embedding(n_speakers, n_dim)
        self.modal_embeddings = nn.Embedding(3, n_dim)
        self.fc1 = nn.Linear(n_dim, nhidden)
        self.hyperconv = nn.ModuleList([
            DenseHypergraphConv(nhidden, nhidden) for _ in range(num_L)])
        self.highconv = nn.ModuleList([
            HighFrequencyConv(nhidden) for _ in range(num_K)])
        self.hyperedge_weight = nn.Parameter(torch.ones(1000))
        self.EW_weight = nn.Parameter(torch.ones(5200))
        self.hyperedge_attr1 = nn.Parameter(torch.rand(nhidden))
        self.hyperedge_attr2 = nn.Parameter(torch.rand(nhidden))
        self.use_residue = False

    def forward(self, a, v, l, dia_len, qmask):
        # qmask: [T,B,9] -> flattened [sumT,9] in batch-major order
        qflat = torch.cat([qmask[:int(x), b, :] for b, x in enumerate(dia_len)], dim=0)
        spk = torch.argmax(qflat, dim=-1)
        if self.use_speaker:
            l = l + self.speaker_embeddings(spk)
        if self.use_modal:
            emb = self.modal_embeddings.weight
            a = a + emb[0].unsqueeze(0)
            v = v + emb[1].unsqueeze(0)
            l = l + emb[2].unsqueeze(0)
        hyperedge_index, edge_index, features, hyperedge_type = self._build(
            a, v, l, dia_len)
        x = self.fc1(features)
        M = int(hyperedge_index[1].max().item()) + 1
        weight = self.hyperedge_weight[:M]
        EW = self.EW_weight[:hyperedge_index.size(1)]
        _ = self.hyperedge_attr1 * hyperedge_type + self.hyperedge_attr2 * (1 - hyperedge_type)
        out = x
        for layer in self.hyperconv:
            out = layer(out, hyperedge_index, weight, EW)
        gnn = x
        for layer in self.highconv:
            gnn = gnn + layer(gnn, edge_index)
        out2 = torch.cat([out, gnn], dim=1)
        return self._reverse(out2, dia_len)

    @staticmethod
    def _reverse(out2, dia_len):
        # out2: [3*sumT, 2*nhidden] -> [sumT, 3*2*nhidden]
        pieces = []
        start = 0
        for i in dia_len:
            i = int(i)
            l = out2[start:start + i]
            a = out2[start + i:start + 2 * i]
            v = out2[start + 2 * i:start + 3 * i]
            pieces.append(torch.cat([l, a, v], dim=-1))
            start += 3 * i
        return torch.cat(pieces, dim=0)

    @staticmethod
    def _build(a, v, l, dia_len):
        index1, index2, edge_list, etypes = [], [], [], []
        features = []
        node_count = 0
        edge_count = 0
        start = 0
        for i in dia_len:
            i = int(i)
            nodes = list(range(node_count, node_count + 3 * i))
            nodes_l = nodes[0:i]
            nodes_a = nodes[i:2 * i]
            nodes_v = nodes[2 * i:3 * i]
            index1 += nodes_l + nodes_a + nodes_v
            for j in range(i):
                index1 += [nodes_l[j], nodes_a[j], nodes_v[j]]
            for j in range(i + 3):
                if j < 3:
                    index2 += [edge_count] * i
                else:
                    index2 += [edge_count] * 3
                edge_count += 1
            features.append(torch.cat([l[start:start + i], a[start:start + i],
                                       v[start:start + i]], dim=0))
            # within-modality directed complete graph
            for group in (nodes_l, nodes_a, nodes_v):
                edge_list += list(itertools.permutations(group, 2))
            # cross-modal within-utterance complete graph
            for j in range(i):
                tri = [nodes_l[j], nodes_a[j], nodes_v[j]]
                edge_list += list(itertools.permutations(tri, 2))
            etypes += [1] * i + [0] * 3
            node_count += 3 * i
            start += i
        device = a.device
        hyperedge_index = torch.tensor([index1, index2], dtype=torch.long, device=device)
        edge_index = torch.tensor(edge_list, dtype=torch.long, device=device).T
        feat = torch.cat(features, dim=0)
        typ = torch.tensor(etypes, dtype=torch.float32, device=device).unsqueeze(-1)
        return hyperedge_index, edge_index, feat, typ


class M3Net(nn.Module):
    model_family = "s2d1_1_m3net_v11"

    def __init__(self, text_dim: int = 1024, audio_dim: int = 300, visual_dim: int = 342,
                 hidden: int = 1024, graph_hidden: int = 512, n_classes: int = 7,
                 n_speakers: int = 9, dropout: float = 0.4, num_L: int = 3,
                 num_K: int = 3, use_residue: bool = False):
        super().__init__()
        if text_dim != 1024:
            raise ValueError("M3Net official MELD RoBERTa path expects 1024 text dims")
        self.text_dim = text_dim
        self.norms = nn.ModuleList([nn.BatchNorm1d(text_dim) for _ in range(4)])
        self.gru_l = nn.GRU(text_dim, hidden // 2, num_layers=2, bidirectional=True,
                            dropout=dropout)
        self.linear_a = nn.Linear(audio_dim, hidden)
        self.linear_v = nn.Linear(visual_dim, hidden)
        self.graph = M3NetHypergraph(hidden, hidden, hidden, hidden, graph_hidden,
                                     n_classes, dropout, n_speakers, num_L=num_L,
                                     num_K=num_K)
        self.dropout = nn.Dropout(dropout)
        self.smax_fc = nn.Linear(3 * 2 * graph_hidden, n_classes)
        self.use_residue = bool(use_residue)

    def forward(self, text_layers, audio, visual, qmask, umask, lengths):
        # text_layers: list of 4 [T,B,1024]
        normed = []
        for i, x in enumerate(text_layers):
            seq, b, d = x.shape
            y = self.norms[i](x.transpose(0, 1).reshape(-1, d)).reshape(b, seq, d).transpose(0, 1)
            normed.append(y)
        text = sum(normed) / 4.0
        packed = pack_padded_sequence(text, [int(x) for x in lengths],
                                      enforce_sorted=False)
        emotions_l, _ = self.gru_l(packed)
        emotions_l, _ = pad_packed_sequence(emotions_l, total_length=text.size(0))
        emotions_a = self.linear_a(audio)
        emotions_v = self.linear_v(visual)
        fa = torch.cat([emotions_a[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        fv = torch.cat([emotions_v[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        fl = torch.cat([emotions_l[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        out = self.graph(fa, fv, fl, lengths, qmask)
        # fixed source hyper branch: dropout -> ReLU -> smax_fc
        out = F.relu(self.dropout(out))
        logits = self.smax_fc(out)
        log_probs = F.log_softmax(logits.float(), dim=-1)
        return logits, log_probs
