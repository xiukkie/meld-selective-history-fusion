"""S2-D1 MM-DFN GDF adaptation (fixed MIT upstream commit da97036).

Dense, device-agnostic implementation of the official GDF/MM-DFN core:
- modality-specific linear encoders; paper GRU text encoder;
- CRN same-speaker history (use_crn_speaker), speaker weights 0.5-0.5-1.5;
- GDF adjacency (cosine within modality, utterance-aligned cross-modal edges);
- 32 GCNII-style layers with reason_flag LSTM, residue and dynamic fusion head.

The official source is MIT licensed; attribution and modifications are recorded
in the S2-D1 delivery. The official source tree remains read-only.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class GraphConvolution(nn.Module):
    def __init__(self, in_features: int, out_features: int, variant: bool = True):
        super().__init__()
        self.variant = variant
        self.in_features = 2 * in_features if variant else in_features
        self.weight = nn.Parameter(torch.empty(self.in_features, out_features))
        stdv = 1.0 / math.sqrt(out_features)
        nn.init.uniform_(self.weight, -stdv, stdv)

    def forward(self, input, adj, h0, lamda, alpha, l):
        theta = math.log(lamda / l + 1)
        hi = torch.matmul(adj, input)
        if self.variant:
            support = torch.cat([hi, h0], dim=1)
            r = (1 - alpha) * hi + alpha * h0
        else:
            support = (1 - alpha) * hi + alpha * h0
            r = support
        return theta * torch.matmul(support, self.weight) + (1 - theta) * r


class GCNIIReason(nn.Module):
    def __init__(self, nfeat: int, nlayers: int, nhidden: int, dropout: float,
                 lamda: float, alpha: float, reason_flag: bool = True):
        super().__init__()
        self.convs = nn.ModuleList([GraphConvolution(nhidden, nhidden, variant=True)
                                    for _ in range(nlayers)])
        self.fc = nn.Linear(nfeat, nhidden)
        self.rnn = nn.LSTM(nhidden, nhidden, 1)
        self.reason_flag = bool(reason_flag)
        self.dropout = float(dropout)
        self.lamda = float(lamda)
        self.alpha = float(alpha)
        self.use_residue = True

    def forward(self, x, adj):
        x = F.dropout(x, self.dropout, training=self.training)
        anchor = F.relu(self.fc(x))
        # fixed source: save the undropped initial activation as the GCNII anchor;
        # only the iterative state is dropped out.
        inner = F.dropout(anchor, self.dropout, training=self.training)
        h = (torch.zeros_like(inner).unsqueeze(0), torch.zeros_like(inner).unsqueeze(0))
        for i, conv in enumerate(self.convs):
            if self.reason_flag:
                q = inner
                inner, h = self.rnn(q.unsqueeze(0), h)
                inner = inner.squeeze(0)
            inner = F.relu(conv(inner, adj, anchor, self.lamda, self.alpha, i + 1))
            inner = F.dropout(inner, self.dropout, training=self.training)
            if self.reason_flag:
                inner = inner + q
        return torch.cat([x, inner], dim=-1)  # use_residue=True


class MMDFNGraph(nn.Module):
    def __init__(self, dim: int = 200, nhidden: int = 100, nlayers: int = 32,
                 nclass: int = 7, dropout: float = 0.4, n_speakers: int = 9,
                 lamda: float = 0.5, alpha: float = 0.2, use_residue: bool = True,
                 reason_flag: bool = True):
        super().__init__()
        self.n_dim = dim
        self.nhidden = nhidden
        self.alpha = float(alpha)
        self.lamda = float(lamda)
        self.use_residue = bool(use_residue)
        self.graph_net = GCNIIReason(dim, nlayers, nhidden, dropout, lamda, alpha,
                                     reason_flag=reason_flag) if use_residue else None
        self.a_fc = nn.Linear(dim, dim)
        self.v_fc = nn.Linear(dim, dim)
        self.l_fc = nn.Linear(dim, dim)
        self.feature_fc = nn.Linear(dim * 3 + nhidden * 3, nhidden)
        self.final_fc = nn.Linear(nhidden, nclass)
        self.speaker_embeddings = nn.Embedding(n_speakers, dim)
        self.modal_embeddings = nn.Embedding(3, dim)

    def forward(self, a, v, l, dia_len, qmask, test_label=False):
        adj = self._build_adj(a, v, l, dia_len)
        feats = torch.cat([a, v, l], dim=0)
        out = self.graph_net(feats, adj)
        L = a.size(0)
        out = torch.cat([out[:L], out[L:2 * L], out[2 * L:3 * L]], dim=-1)
        return out

    @staticmethod
    def _build_adj(a, v, l, dia_len):
        num = len(dia_len)
        total = sum(int(x) for x in dia_len)
        adj = torch.zeros(3 * total, 3 * total, device=a.device, dtype=a.dtype)
        feats = [a, v, l]
        start = 0
        for i in dia_len:
            i = int(i)
            sub = []
            for x in feats:
                tmp = x[start:start + i]
                vec = torch.sqrt(torch.sum(tmp * tmp, dim=1)).clamp_min(1e-12)
                norm = (tmp.permute(1, 0) / vec)
                cos = torch.sum(norm.unsqueeze(2) * norm.unsqueeze(1), dim=0) * 0.99999
                sub.append(1 - torch.acos(cos) / math.pi)
            for m in range(3):
                for n in range(3):
                    ms, ns = start + total * m, start + total * n
                    if m == n:
                        adj[ms:ms + i, ns:ns + i] = sub[m]
                    else:
                        m1, m2 = feats[m], feats[n]
                        x1 = m1[start:start + i]
                        x2 = m2[start:start + i]
                        v1 = torch.sqrt(torch.sum(x1 * x1, dim=1)).clamp_min(1e-12)
                        v2 = torch.sqrt(torch.sum(x2 * x2, dim=1)).clamp_min(1e-12)
                        n1 = x1.permute(1, 0) / v1
                        n2 = x2.permute(1, 0) / v2
                        cos = torch.sum(n1 * n2, dim=0)
                        dsim = 1 - torch.acos(cos * 0.99999) / math.pi
                        idx = torch.arange(i, device=a.device)
                        adj[ms + idx, ns + idx] = dsim
            start += i
        d = adj.sum(1).clamp_min(1e-12)
        D = torch.diag(torch.pow(d, -0.5))
        return D.mm(adj).mm(D)


class MMDFN(nn.Module):
    model_family = "s2d1_1_mmdfn_gdf32_v11"

    def __init__(self, text_dim: int, audio_dim: int = 300, visual_dim: int = 342,
                 hidden: int = 200, d_e: int = 100, graph_hidden: int = 100,
                 nlayers: int = 32, n_classes: int = 7, n_speakers: int = 9,
                 dropout: float = 0.4, reason_flag: bool = True,
                 use_crn_speaker: bool = True,
                 speaker_weights=(0.5, 0.5, 1.5),
                 alpha: float = 0.2, lamda: float = 0.5):
        super().__init__()
        self.text_dim = int(text_dim)
        self.hidden = int(hidden)
        self.d_e = int(d_e)
        self.use_crn_speaker = bool(use_crn_speaker)
        self.speaker_weights = tuple(float(x) for x in speaker_weights)
        self.alpha = float(alpha)
        self.lamda = float(lamda)
        self.linear_a = nn.Linear(audio_dim, hidden)
        self.linear_v = nn.Linear(visual_dim, hidden)
        self.linear_l = nn.Linear(text_dim, hidden)
        self.gru_l = nn.GRU(hidden, d_e, num_layers=2, bidirectional=True,
                            dropout=dropout)
        self.rnn_parties = nn.GRU(hidden, d_e, num_layers=2, bidirectional=True,
                                  dropout=dropout)
        self.graph = MMDFNGraph(dim=2 * d_e, nhidden=graph_hidden, nlayers=nlayers,
                                nclass=n_classes, dropout=dropout,
                                n_speakers=n_speakers, reason_flag=reason_flag,
                                alpha=self.alpha, lamda=self.lamda)
        self.dropout = nn.Dropout(dropout)
        self.smax_fc = nn.Linear(3 * (2 * d_e + graph_hidden), n_classes)

    def _speaker_history(self, u, qmask, dia_len):
        # u: [T,B,200], qmask: [T,B,9]; CRN same-speaker history, packed to
        # keep the result independent of batch padding.
        ub = u.transpose(0, 1)  # [B,T,200]
        out = torch.zeros_like(ub)
        for p in range(qmask.size(2)):
            seqs, idxs = [], []
            for b in range(ub.size(0)):
                idx = torch.nonzero(qmask[:int(dia_len[b]), b, p], as_tuple=False).squeeze(-1)
                if idx.numel() > 0:
                    seqs.append(ub[b, idx])
                    idxs.append((b, idx))
            if not seqs:
                continue
            lens = [int(x.size(0)) for x in seqs]
            padded = torch.nn.utils.rnn.pad_sequence(seqs, batch_first=False)
            packed = pack_padded_sequence(padded, lens, enforce_sorted=False)
            h, _ = self.rnn_parties(packed)
            h, _ = pad_packed_sequence(h, total_length=padded.size(0))
            for bi, (b, idx) in enumerate(idxs):
                out[b, idx] = h[:idx.numel(), bi]
        return out.transpose(0, 1)

    def forward(self, text, audio, visual, qmask, umask, lengths):
        u_l = self.linear_l(text)
        u_a = self.linear_a(audio)
        u_v = self.linear_v(visual)
        hist_a = self._speaker_history(u_a, qmask, lengths) if self.use_crn_speaker else torch.zeros_like(u_a)
        hist_v = self._speaker_history(u_v, qmask, lengths) if self.use_crn_speaker else torch.zeros_like(u_v)
        hist_l = self._speaker_history(u_l, qmask, lengths) if self.use_crn_speaker else torch.zeros_like(u_l)
        if self.use_crn_speaker:
            u_a = u_a + self.speaker_weights[0] * hist_a
            u_v = u_v + self.speaker_weights[1] * hist_v
        packed = pack_padded_sequence(u_l, [int(x) for x in lengths],
                                      enforce_sorted=False)
        em_l, _ = self.gru_l(packed)
        em_l, _ = pad_packed_sequence(em_l, total_length=u_l.size(0))
        if self.use_crn_speaker:
            # fixed source: GRU(projected text) + speaker history computed from
            # the projected text, not GRU(text + history).
            em_l = em_l + self.speaker_weights[2] * hist_l
        fa = torch.cat([u_a[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        fv = torch.cat([u_v[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        fl = torch.cat([em_l[:int(l), b] for b, l in enumerate(lengths)], dim=0)
        out = self.graph(fa, fv, fl, lengths, qmask)
        logits = self.smax_fc(self.dropout(F.relu(out)))
        log_probs = F.log_softmax(logits.float(), dim=-1)
        return logits, log_probs
