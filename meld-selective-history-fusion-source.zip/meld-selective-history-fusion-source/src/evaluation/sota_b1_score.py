"""SOTA-B1 separated scorer: the ONLY module that reads dev emotion labels.

The training entry and collate never load labels. Unlabeled dev predictions are
written to disk first (keys + probabilities + SHA); this scorer then binds the
true labels by official key and computes metrics. Validation rejects duplicate /
missing / swapped keys, non-finite probabilities, wrong SHA, wrong seed/arm,
and any 'test' role before labels are touched.

weighted-F1 convention (task book §6): per-class support = confusion-matrix row
sum (true-class support summed along the prediction axis); the asymmetric example
y_true=[0,0,0,1], y_pred=[0,0,1,1] must give 0.7666666667.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os

import numpy as np

from ..training import sota_b1_spec as spec


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_dev_labels(binding: dict) -> dict[str, int]:
    """Read dev Emotion via the proven official binding. Scorer-only path."""
    rows = {}
    with open(os.path.join(spec.MELD_CSV_ROOT, "dev_sent_emo.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows[(r["Dialogue_ID"], r["Utterance_ID"])] = r["Emotion"]
    out = {}
    for did_s, entry in binding["dev"].items():
        for key, (d, u) in zip(entry["utterance_keys"], entry["official"]):
            emo = rows[(d, u)]
            if emo not in spec.CLASS_TO_ID:
                raise ValueError(f"unknown emotion {emo!r} for {key}")
            out[key] = spec.CLASS_TO_ID[emo]
    if len(out) != spec.DEV_UTTERANCES:
        raise ValueError(f"dev label coverage {len(out)} != {spec.DEV_UTTERANCES}")
    return out


def expected_dev_keys(binding: dict) -> list[str]:
    keys = []
    for did_s in sorted(binding["dev"], key=int):
        keys.extend(binding["dev"][did_s]["utterance_keys"])
    return keys


def confusion(y: np.ndarray, p: np.ndarray, n: int = 7) -> np.ndarray:
    cm = np.zeros((n, n), dtype=np.int64)
    np.add.at(cm, (y, p), 1)
    return cm


def metrics_from_cm(cm: np.ndarray) -> dict:
    support = cm.sum(axis=1)          # true-class support along prediction axis
    pred_count = cm.sum(axis=0)
    tp = np.diag(cm)
    with np.errstate(divide="ignore", invalid="ignore"):
        prec = np.where(pred_count > 0, tp / np.maximum(pred_count, 1), 0.0)
        rec = np.where(support > 0, tp / np.maximum(support, 1), 0.0)
        f1 = np.where((prec + rec) > 0, 2 * prec * rec / np.maximum(prec + rec, 1e-300), 0.0)
    n = int(cm.sum())
    wf1 = float((support * f1).sum() / n) if n else 0.0
    macro = float(f1[support > 0].mean()) if (support > 0).any() else 0.0
    acc = float(tp.sum() / n) if n else 0.0
    return {"weighted_f1": wf1, "macro_f1": macro, "accuracy": acc,
            "per_class": [{"class": spec.CLASS_ORDER[c], "precision": float(prec[c]),
                           "recall": float(rec[c]), "f1": float(f1[c]),
                           "support": int(support[c])} for c in range(cm.shape[0])],
            "confusion": cm.tolist(), "n": n}


def asymmetric_selftest() -> bool:
    y = np.array([0, 0, 0, 1]); p = np.array([0, 0, 1, 1])
    m = metrics_from_cm(confusion(y, p))
    return abs(m["weighted_f1"] - 0.7666666667) < 1e-9


def validate_unlabeled(path: str, manifest: dict, *, unit_id: str, seed: int, arm: str,
                       epoch: int, expected_keys: list[str]) -> dict:
    """Structural validation BEFORE any label is read. Raises on any violation."""
    if manifest.get("split") != "dev":
        raise PermissionError("scorer refuses non-dev role")
    if manifest.get("unit_id") != unit_id or int(manifest["seed"]) != int(seed) \
            or manifest.get("arm") != arm or int(manifest["epoch"]) != int(epoch):
        raise ValueError("manifest identity mismatch (unit/seed/arm/epoch)")
    actual_sha = sha256_file(path)
    if actual_sha != manifest.get("npz_sha256"):
        raise ValueError(f"SHA mismatch: {actual_sha} != {manifest.get('npz_sha256')}")
    z = np.load(path, allow_pickle=False)
    keys = [str(k) for k in z["keys"]]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate keys")
    if keys != list(expected_keys):
        raise ValueError("key coverage/order mismatch (missing, extra or swapped keys)")
    probs = z["fused_probs"]
    if probs.shape != (len(keys), 7):
        raise ValueError("prob shape mismatch")
    if not np.isfinite(probs).all() or (probs < 0).any():
        raise ValueError("non-finite or negative probabilities")
    if not np.allclose(probs.sum(axis=1), 1.0, atol=1e-5):
        raise ValueError("probabilities do not sum to 1")
    logp = z["fused_logp"]
    if not np.isfinite(logp).all():
        raise ValueError("non-finite log-probabilities")
    if not np.allclose(logp, np.log(np.clip(probs, 1e-300, None)), atol=2e-4):
        raise ValueError("logp/prob inconsistency")
    return {"keys": keys, "probs": probs, "logp": logp, "npz_sha256": actual_sha,
            "has_modal_heads": "text_logp" in z.files,
            "modal": {m: z[f"{m}_logp"] for m in ("text", "audio", "visual")
                      if f"{m}_logp" in z.files}}


def score_epoch(path: str, manifest: dict, *, unit_id: str, seed: int, arm: str,
                epoch: int, binding: dict, dev_labels: dict) -> dict:
    expected = expected_dev_keys(binding)
    v = validate_unlabeled(path, manifest, unit_id=unit_id, seed=seed, arm=arm,
                           epoch=epoch, expected_keys=expected)
    y = np.array([dev_labels[k] for k in v["keys"]], dtype=np.int64)
    pred = v["probs"].argmax(axis=1)
    m = metrics_from_cm(confusion(y, pred))
    nll = float(-v["logp"][np.arange(len(y)), y].mean())
    onehot = np.eye(7)[y]
    brier = float(((v["probs"] - onehot) ** 2).sum(axis=1).mean())
    m.update({"nll": nll, "brier": brier, "epoch": int(epoch),
              "npz_sha256": v["npz_sha256"], "unit_id": unit_id, "seed": int(seed),
              "arm": arm})
    return m


def is_better(cand: dict, best: dict | None, tol: float = spec.TIE_TOL) -> bool:
    """wF1 max; tie -> lower NLL; tie -> earlier epoch (handled by scan order)."""
    if best is None:
        return True
    if cand["weighted_f1"] > best["weighted_f1"] + tol:
        return True
    if abs(cand["weighted_f1"] - best["weighted_f1"]) <= tol:
        if cand["nll"] < best["nll"] - tol:
            return True
    return False