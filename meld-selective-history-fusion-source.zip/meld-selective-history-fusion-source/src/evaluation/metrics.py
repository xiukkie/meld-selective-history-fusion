"""评价指标：Accuracy、weighted-F1、macro-F1、各类别 F1，以及转变/非转变子集。

约定（对应 docs/实验规范.md 第 7 节）：
- 固定完整类别集合（MELD=7，IEMOCAP=6）；缺失类别按 zero-division=0 计入 macro 平均；
- 指标统一用 [0,1] 小数，另在记录里声明 metric_scale；
- 只统计有效性掩码内的话语；逐话语预测可重算汇总指标。
"""
from __future__ import annotations

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score


def _empty_metrics(num_classes: int) -> dict:
    return {
        "n": 0,
        "accuracy": None,
        "weighted_f1": None,
        "macro_f1": None,
        "per_class": [
            {"class_id": c, "support": 0, "precision": None, "recall": None, "f1": None}
            for c in range(num_classes)
        ],
        "confusion_matrix": [[0] * num_classes for _ in range(num_classes)],
    }


def compute_classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    num_classes: int,
) -> dict:
    """对一组话语计算主指标。y_true/y_pred 必须已经是同长度的一维整数数组。"""
    y_true = np.asarray(y_true, dtype=np.int64).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=np.int64).reshape(-1)
    if y_true.shape != y_pred.shape:
        raise ValueError(f"y_true/y_pred 长度不一致: {y_true.shape} vs {y_pred.shape}")
    if y_true.size == 0:
        return _empty_metrics(num_classes)
    labels = list(range(num_classes))
    if np.any(y_true < 0) or np.any(y_true >= num_classes):
        raise ValueError("y_true 存在越界类别")
    if np.any(y_pred < 0) or np.any(y_pred >= num_classes):
        raise ValueError("y_pred 存在越界类别")

    cm = confusion_matrix(y_true, y_pred, labels=labels)
    per_class = []
    for c in labels:
        tp = int(cm[c, c])
        support = int(cm[c, :].sum())
        pred_pos = int(cm[:, c].sum())
        precision = tp / pred_pos if pred_pos else 0.0
        recall = tp / support if support else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        per_class.append(
            {
                "class_id": c,
                "support": support,
                "precision": precision,
                "recall": recall,
                "f1": f1,
            }
        )
    return {
        "n": int(y_true.size),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "weighted_f1": float(
            f1_score(y_true, y_pred, labels=labels, average="weighted", zero_division=0)
        ),
        "macro_f1": float(
            f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)
        ),
        "per_class": per_class,
        "confusion_matrix": cm.tolist(),
    }


def compute_subset_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    subset_mask: np.ndarray,
    num_classes: int,
    subset_name: str,
) -> dict:
    """按子集掩码计算指标（例：发生转变 / 未发生转变的话语）。

    子集掩码只来自评价标签（转变标签），绝不作为模型输入。
    """
    y_true = np.asarray(y_true, dtype=np.int64).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=np.int64).reshape(-1)
    subset_mask = np.asarray(subset_mask, dtype=bool).reshape(-1)
    if not (y_true.shape == y_pred.shape == subset_mask.shape):
        raise ValueError("子集指标输入长度不一致")
    metrics = compute_classification_metrics(y_true[subset_mask], y_pred[subset_mask], num_classes)
    metrics["subset"] = subset_name
    return metrics


def compute_all_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    transition: np.ndarray,
    num_classes: int,
) -> dict:
    """完整评价输出：全体 + 发生转变子集 + 未发生转变子集（均含样本数）。"""
    y_true = np.asarray(y_true, dtype=np.int64).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=np.int64).reshape(-1)
    transition = np.asarray(transition, dtype=np.int64).reshape(-1)
    if not (y_true.shape == y_pred.shape == transition.shape):
        raise ValueError("评价输入长度不一致")
    has_p = transition >= 0
    result = {
        "metric_scale": "fraction",
        "num_classes": int(num_classes),
        "overall": compute_classification_metrics(y_true, y_pred, num_classes),
        "transition": compute_subset_metrics(
            y_true, y_pred, has_p & (transition == 1), num_classes, "transition"
        ),
        "non_transition": compute_subset_metrics(
            y_true, y_pred, has_p & (transition == 0), num_classes, "non_transition"
        ),
        "first_utterance_no_p": compute_subset_metrics(
            y_true, y_pred, transition == -1, num_classes, "first_utterance_no_p"
        ),
    }
    result["n_has_p"] = int(has_p.sum())
    result["n_no_p"] = int((transition == -1).sum())
    return result


def summarize_for_selection(metrics: dict) -> tuple[float, float]:
    """返回 (weighted_f1, -loss 的占位)；选择规则在 engine 中实现。"""
    return float(metrics["overall"]["weighted_f1"]), float(metrics["overall"]["accuracy"])
