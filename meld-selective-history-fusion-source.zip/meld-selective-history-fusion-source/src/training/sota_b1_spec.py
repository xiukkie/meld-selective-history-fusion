"""SOTA-B1 frozen specification: strong-baseline reproduction and label-free text upgrade.

Task book: review/SOTA_plan_2026-11-19/01_强基线复现与无标签文本升级执行Prompt.md
Two mandatory arms (MMDFN_COMMON, SDT_COMMON) x 3 seeds = 6 fits; optional third arm
SDT_TEXT_UPDATED x 3 seeds only after text-asset acceptance. MELD official train/dev only.
No test loader, no IEMOCAP fit, no paid compute, no external transfer.

Backend fixed BEFORE any formal fit by real forward/backward measurement:
CPU / float32 (see evidence/device_measurement.json).
"""
from __future__ import annotations
import hashlib
import json
import os

PROJECT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
STAGE = "SOTA-B1"
IMPL_VERSION = "sota_b1_v1"
OUT = os.path.join(PROJECT, "review/SOTA_B1_2026-11-19")
RUN = os.path.join(OUT, "run_20261119T175349")
EV = os.path.join(RUN, "evidence")
FITS = os.path.join(RUN, "fits")
CONFIG = os.path.join(RUN, "config")
MODEL_CACHE = os.path.join(RUN, "model_cache")
TEXT_DIR = os.path.join(RUN, "text")

TASK_PROMPT = os.path.join(PROJECT, "review/SOTA_plan_2026-11-19",
                           "01_强基线复现与无标签文本升级执行Prompt.md")

# ---- read-only frozen inputs -------------------------------------------------
FEATURES_ROOT = os.path.join(PROJECT, "data/features/m3net")
MELD_CSV_ROOT = os.path.join(PROJECT, "third_party/MELD/data/MELD")
UPSTREAM_DIR = os.path.join(PROJECT, "third_party/classwise-multimodal-ERC")
UPSTREAM_COMMIT = "6f9c6b8d9211edd9a0dc41f54c49d0c88157cd6b"
UPSTREAM_URL = "https://github.com/multimedia-eurecat/classwise-multimodal-ERC"
MMDFN_MODEL = os.path.join(PROJECT, "src/models/mmdfn_v11.py")

# Data SHA from the audited manifest (data/manifests/audit_report.json)
FEATURE_SHA = {
    "MELD_features_raw1.pkl": "d043b3ec1813c8917e2067af01e933ff0892d33d19d93595098aaf88c4b200b0",
    "meld_features_roberta.pkl": "58b2bdadc2eaec6abb40ac0cb3ffa3f31e929d636ece8197aecf1ca373a92951",
}

# ---- experiment definition ---------------------------------------------------
SEEDS = (73, 101, 2026)
ARMS_COMMON = ("MMDFN_COMMON", "SDT_COMMON")
ARMS_OPTIONAL = ("SDT_TEXT_UPDATED",)
ALL_ARMS = ARMS_COMMON + ARMS_OPTIONAL
MANDATORY_FITS = 6
MAX_FITS_THREE_ARM = 9
MAX_STARTS_TWO_ARM = 7
MAX_STARTS_THREE_ARM = 10

NUM_CLASSES = 7
CLASS_ORDER = ["neutral", "surprise", "fear", "sadness", "joy", "disgust", "anger"]
CLASS_TO_ID = {c: i for i, c in enumerate(CLASS_ORDER)}
FEATURE_DIMS = {"text": 1024, "audio": 300, "visual": 342, "speakers": 9}
CONTEXT = "offline"
DEV_DIALOGUES, DEV_UTTERANCES = 114, 1109
TRAIN_DIALOGUES, TRAIN_UTTERANCES = 1038, 9989
N_DEV_ROWS_2ARM = 6654   # 6 * 1109
N_DEV_ROWS_3ARM = 9981   # 9 * 1109

# ---- backend (fixed before any formal fit) -----------------------------------
DEVICE = "cpu"
DTYPE = "float32"
INTRA, INTER = 5, 15

# ---- MMDFN_COMMON recipe (R0, identical to audited S2-D1.1) -------------------
MMDFN = {
    "lr": 5e-4, "weight_decay": 1e-4, "betas": (0.9, 0.999), "eps": 1e-8,
    "batch_dialogues": 32, "clip": 1.0, "max_epochs": 60, "patience": 10,
    "hidden": 200, "d_e": 100, "graph_hidden": 100, "nlayers": 32,
    "dropout": 0.4, "focal_gamma": 0.5, "reason_flag": True,
    "use_crn_speaker": True, "speaker_weights": (0.5, 0.5, 1.5),
    "alpha": 0.2, "lamda": 0.5, "text_key": "roberta1", "text_dim": 1024,
}

# ---- SDT recipe (local dev-only fixed-width adaptation of upstream model.py) --
SDT = {
    "lr": 3e-4, "weight_decay": 1e-4, "betas": (0.9, 0.999), "eps": 1e-8,
    "batch_dialogues": 16, "clip": 1.0, "max_epochs": 30, "patience": 6,
    # architecture — local adaptation: paper shared width is 1024, we fix 256
    "hidden_dim": 256, "n_head": 4, "dropout": 0.3,
    "n_speakers": 9, "n_classes": 7, "temp": 8, "fusion_mode": "softmax",
    "modal_dropout": 0.0, "dropout_strategy": "input",
    "use_disentangle": False, "use_intra_visual_gate": False,
    "use_landmark_mlp": False, "use_speaker_embeddings": True,
    "circumplex_alpha": 0.0, "con_temperature": 0.0,  # no contrastive loss
    "gate_dim": 64,
    # distillation loss: CE_fused + 0.5*mean_m(CE_m) + 0.1*tau^2*mean_m(KL(teacher||m))
    "tau": 8, "w_fused": 1.0, "w_modal": 0.5, "w_kl": 0.1,
    "d_text": 1024, "d_visual": 342, "d_audio": 300,
    "text_key": "roberta1",
}

# ---- selection rule (identical for both model families) ----------------------
TIE_TOL = 1e-12
SELECTION = ["max dev weighted-F1", "then lower plain NLL within 1e-12",
             "then earlier epoch; epoch0 legal"]

# ---- budget ------------------------------------------------------------------
ROUND_MINUTES_MAX = 210
RESERVE_MINUTES = 20
PER_FIT_MINUTES_MAX = 30
TEXT_ENCODE_MINUTES_MAX = 60
NEW_FILES_GIB_MAX = 2.0
MODEL_DOWNLOAD_GB_MAX = 2.0

# ---- statistics --------------------------------------------------------------
BOOT_SEED = 2026111802
BOOT_N = 2000
BOOT_DIALOGUES = 114
ASYM_EXAMPLE = ([0, 0, 0, 1], [0, 0, 1, 1], 0.7666666667)

# ---- text upgrade asset (optional arm) ---------------------------------------
TEXT_MODEL_ID = "sentence-transformers/all-roberta-large-v1"
TEXT_MAX_LENGTH = 128
TEXT_CONTEXT_WINDOW = 2     # two most recent past utterances + current
TEXT_POOLING = "mean"       # last-layer attention-mask mean, no L2 norm
TEXT_OUTPUT_DIM = 1024


def unit_id(seed: int, arm: str) -> str:
    return f"SOTA_B1_seed{seed}_{arm}"


def sha_json(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False).encode("utf-8")).hexdigest()


def attempt_id() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
