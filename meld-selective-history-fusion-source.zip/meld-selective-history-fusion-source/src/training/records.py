"""实验记录与哈希工具（对应 docs/审查与交付.md 第 3 节字段要求）。"""
from __future__ import annotations

import hashlib
import json
import os
import resource
import subprocess

from .. import versions
from ..data.schema import Dialogue

_BLOCK = 1024 * 1024
_SHA_CACHE: dict[tuple[str, int, int], str] = {}


def utc_timestamp() -> str:
    from ..utils.logging import utc_now

    return utc_now()


def sha256_file(path: str) -> str:
    """文件 SHA-256。

    进程内按 (绝对路径, 大小, mtime_ns) 缓存，避免同一进程内多次小回归重复哈希 644MB 特征；
    文件被改写时 mtime/size 变化会重新计算。复核器与真实运行每次新进程仍会实际读取文件。
    """
    stat = os.stat(path)
    key = (os.path.abspath(path), int(stat.st_size), int(stat.st_mtime_ns))
    cached = _SHA_CACHE.get(key)
    if cached is not None:
        return cached
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(_BLOCK)
            if not chunk:
                break
            h.update(chunk)
    digest = h.hexdigest()
    _SHA_CACHE[key] = digest
    return digest


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _sha256_tree(directory: str) -> str:
    h = hashlib.sha256()
    if not os.path.isdir(directory):
        return h.hexdigest()
    for root, _dirs, files in os.walk(directory):
        for name in sorted(files):
            if not name.endswith(".py"):
                continue
            path = os.path.join(root, name)
            rel = os.path.relpath(path, directory)
            h.update(rel.encode("utf-8"))
            h.update(b"\0")
            with open(path, "rb") as f:
                h.update(f.read())
            h.update(b"\0")
    return h.hexdigest()


def project_version(project_root: str) -> dict:
    commit = None
    dirty = None
    try:
        out = subprocess.run(
            ["git", "-C", project_root, "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=10,
        )
        if out.returncode == 0:
            commit = out.stdout.strip()
            status = subprocess.run(
                ["git", "-C", project_root, "status", "--porcelain"],
                capture_output=True, text=True, timeout=10,
            )
            dirty = bool(status.stdout.strip())
    except (OSError, subprocess.SubprocessError):  # pragma: no cover
        pass
    return {
        "git_commit": commit,
        "git_dirty": dirty,
        "src_tree_sha256": _sha256_tree(os.path.join(project_root, "src")),
        "project_root_abs": os.path.abspath(project_root),
    }


def feature_file_hashes(features_root: str, verify: bool = True) -> dict:
    """计算（并可选核对）M3NET 特征文件哈希。"""
    m3net_dir = os.path.join(features_root, "m3net")
    result: dict[str, dict] = {}
    for name, expected in versions.FEATURE_SHA256.items():
        path = os.path.join(m3net_dir, name)
        if not os.path.isfile(path):
            result[name] = {"path": path, "status": "missing", "sha256": None, "size_bytes": None}
            continue
        digest = sha256_file(path)
        status = "ok"
        if verify:
            status = "ok" if digest == expected else "mismatch"
        result[name] = {
            "path": path,
            "status": status,
            "sha256": digest,
            "size_bytes": os.path.getsize(path),
            "expected_sha256": expected,
        }
    return result


def data_manifest_hash(feature_hashes: dict) -> str:
    payload = {
        name: {"sha256": info["sha256"], "size_bytes": info["size_bytes"]}
        for name, info in sorted(feature_hashes.items())
    }
    return sha256_text(json.dumps(payload, sort_keys=True))


def split_hash(dialogues: list[Dialogue]) -> str:
    """v1 划分哈希（旧运行使用的算法）：仅对话 ID -> split。"""
    payload = {d.dialogue_id: d.split for d in dialogues}
    return sha256_text(json.dumps(payload, sort_keys=True))


def split_manifest_v2(dialogues: list[Dialogue]) -> dict:
    """v2 划分清单：对话 ID + 逐话语 ID（用于更细粒度复核）。

    只返回哈希与计数，不把完整清单塞进 record；旧运行没有该字段时由复核器标注 legacy。
    """
    splits: dict[str, dict[str, list[str]]] = {}
    for d in dialogues:
        splits.setdefault(d.split, {})[d.dialogue_id] = list(d.utterance_ids)
    canonical = {
        "version": "v2-dialogue-utterance",
        "splits": {split: dict(sorted(items.items())) for split, items in sorted(splits.items())},
    }
    return {
        "version": "v2-dialogue-utterance",
        "hash": sha256_text(json.dumps(canonical, sort_keys=True, ensure_ascii=False)),
        "n_dialogues": {split: len(items) for split, items in sorted(splits.items())},
        "n_utterances": {split: sum(len(ids) for ids in items.values()) for split, items in sorted(splits.items())},
    }


def peak_memory_info() -> dict:
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    info = {
        "ru_maxrss_raw": int(rss),
        "ru_maxrss_note": "macOS 单位为字节；Linux 为 KB（见平台差异）",
        "peak_rss_bytes": int(rss) if os.uname().sysname == "Darwin" else int(rss) * 1024,
    }
    try:
        import torch

        if torch.backends.mps.is_available():
            info["mps_driver_allocated_bytes"] = int(torch.mps.driver_allocated_memory())
        if torch.cuda.is_available():  # pragma: no cover
            info["cuda_max_allocated_bytes"] = int(torch.cuda.max_memory_allocated())
    except (ImportError, RuntimeError, AttributeError):  # pragma: no cover
        pass
    return info


def make_record(
    *,
    experiment_id: str,
    stage: str,
    dataset: str,
    config: dict,
    config_path: str,
    config_hash: str,
    project_root: str,
    feature_hashes: dict,
    split_hash_value: str,
    device: str,
    seed: int,
    epochs_trained: int,
    best_epoch: int | None,
    validation_selection_rule: str,
    checkpoint_path: str | None,
    metrics_dev: dict | None,
    timing: dict,
    status: str,
    failure_reason: str | None = None,
    extra_notes: list[str] | None = None,
    checkpoint_format: str | None = None,
    checkpoint_summary: dict | None = None,
    resume: dict | None = None,
    stop_reason: str | None = None,
    trained_new_epochs: int | None = None,
    split_manifest_v2_value: dict | None = None,
) -> dict:
    return {
        "experiment_id": experiment_id,
        "stage": stage,
        "dataset": dataset,
        "timestamp_timezone": utc_timestamp(),
        "project_version": project_version(project_root),
        "upstream_commit": versions.UPSTREAM_COMMITS,
        "config_path": os.path.abspath(config_path),
        "config_hash": config_hash,
        "data_manifest_hash": data_manifest_hash(feature_hashes),
        "split_hash": split_hash_value,
        "feature_version": versions.FEATURE_SET_VERSION,
        "feature_files": feature_hashes,
        "context_mode": config["experiment"]["context_mode"],
        "device": device,
        "seed": int(seed),
        "selection_method": validation_selection_rule,
        "candidate_K": None,
        "max_evidence": None,
        "search_budget": None,
        "training_epochs": int(epochs_trained),
        "best_epoch": best_epoch,
        "validation_selection_rule": validation_selection_rule,
        "checkpoint": checkpoint_path,
        "checkpoint_format": checkpoint_format,
        "checkpoint_summary": checkpoint_summary,
        "metrics": {"dev": metrics_dev},
        "timing": timing,
        "peak_memory": peak_memory_info(),
        "status": status,
        "failure_reason": failure_reason,
        "test_set_read": False,
        "test_set_read_note": "该字段是运行记录声明；测试访问由 loader/配置门禁与复核器分别检查，不是独立审计证明",
        "resume": resume,
        "stop_reason": stop_reason,
        "trained_new_epochs": trained_new_epochs,
        "split_manifest_v2": split_manifest_v2_value,
        "notes": extra_notes or [],
    }
