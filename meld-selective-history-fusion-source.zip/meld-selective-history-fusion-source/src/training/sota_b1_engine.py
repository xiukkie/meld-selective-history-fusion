"""SOTA-B1 unified training engine: MMDFN_COMMON / SDT_COMMON / SDT_TEXT_UPDATED.

Protocol (task book §6):
- seeds 73/101/2026; the two SDT arms of one seed share initial weights, the
  full-dialogue batch plan, the dropout stream and the device;
- SDT: Adam(lr 3e-4, wd 1e-4), dialogue batch 16, clip 1, <=30 epochs, patience 6;
- MMDFN: R0 Adam(lr 5e-4, wd 1e-4), batch 32, clip 1, <=60 epochs, patience 10,
  detached-pt focal gamma 0.5 (identical formula to audited S2-D1.1);
- epoch0 and every trained epoch: UNLABELED dev forward written to disk with a
  SHA manifest, then the separated scorer binds labels; selection = max dev
  weighted-F1, then lower plain NLL, then earlier epoch (tol 1e-12); patience
  refreshes only on strict improvement in that priority order;
- initial / best / last snapshots, per-epoch records, batch plans, optimizer
  step counts, real timing; every formal launch intent is counted in a global
  append-only ledger (parameter errors count too).

Labels: train emotion enters ONLY the loss tensors built here from the separate
train-label map; dev labels are never loaded in this module.
"""
from __future__ import annotations

import copy
import json
import os
import time

import numpy as np
import torch

from ..data import sota_b1_data as D
from ..evaluation import sota_b1_score as SC
from ..models.mmdfn_v11 import MMDFN
from ..models import sota_b1_sdt as SDT
from ..training import sota_b1_spec as spec
from ..training.s2d1_v11 import focal_loss_mmdfn
from ..utils.seed import seed_everything


def _append_jsonl(path: str, obj: dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def ledger_path() -> str:
    return os.path.join(spec.EV, "global_attempts.jsonl")


def ledger_count() -> int:
    p = ledger_path()
    if not os.path.exists(p):
        return 0
    with open(p, encoding="utf-8") as f:
        return sum(1 for line in f if line.strip())


def register_launch(unit_id: str, seed: int, arm: str, max_starts: int) -> str:
    """Count EVERY formal launch intent before any work; reject over-budget."""
    n = ledger_count()
    aid = f"A{n + 1:03d}"
    rec = {"attempt_id": aid, "unit_id": unit_id, "seed": int(seed), "arm": arm,
           "registered_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "status": "registered", "optimizer_steps": 0}
    if n + 1 > max_starts:
        rec["status"] = "rejected_over_budget"
        _append_jsonl(ledger_path(), rec)
        raise RuntimeError(f"formal launch budget exhausted: {n + 1} > {max_starts}")
    _append_jsonl(ledger_path(), rec)
    return aid


def finish_launch(aid: str, status: str, steps: int, failure: str | None = None):
    p = ledger_path()
    lines = [json.loads(x) for x in open(p, encoding="utf-8") if x.strip()]
    for r in lines:
        if r["attempt_id"] == aid:
            r["status"] = status
            r["optimizer_steps"] = int(steps)
            r["failure_reason"] = failure
            r["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        for r in lines:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(tmp, p)


def build_mmdfn() -> MMDFN:
    c = spec.MMDFN
    return MMDFN(text_dim=c["text_dim"], hidden=c["hidden"], d_e=c["d_e"],
                 graph_hidden=c["graph_hidden"], nlayers=c["nlayers"],
                 dropout=c["dropout"], reason_flag=c["reason_flag"],
                 use_crn_speaker=c["use_crn_speaker"],
                 speaker_weights=c["speaker_weights"], alpha=c["alpha"], lamda=c["lamda"])


def dev_forward_write(model, family: str, dev_dialogues, unit_dir: str, *,
                      unit_id: str, seed: int, arm: str, epoch: int,
                      device, eval_batch: int = 32) -> tuple[str, dict]:
    """Unlabeled dev forward -> npz + manifest. NO labels read or written."""
    model.eval()
    keys, fused_p, fused_lp = [], [], []
    modal = {"text": [], "audio": [], "visual": []} if family == "sdt" else None
    with torch.no_grad():
        for s in range(0, len(dev_dialogues), eval_batch):
            chunk = dev_dialogues[s:s + eval_batch]
            batch = D.collate(chunk)
            batch = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
            if family == "sdt":
                out = SDT.sdt_forward(model, batch)
                d = SDT.sdt_dev_outputs(out, batch["umask"].permute(1, 0))
                keys.extend(batch["keys"])
                fused_p.append(d["fused_probs"]); fused_lp.append(d["fused_logp"])
                for m in modal:
                    modal[m].append(d[f"{m}_logp"])
            else:
                logits, logp = model(batch["text"], batch["audio"], batch["visual"],
                                     batch["qmask"], batch["umask"], batch["lengths"])
                # MMDFN v11 returns valid-row-flat [total,7] in b-major key order
                keys.extend(batch["keys"])
                fused_lp.append(logp.cpu())
                fused_p.append(logp.exp().cpu())
    payload = {"keys": np.asarray(keys), "fused_probs": torch.cat(fused_p).numpy(),
               "fused_logp": torch.cat(fused_lp).numpy()}
    if modal is not None:
        for m in modal:
            payload[f"{m}_logp"] = torch.cat(modal[m]).numpy()
    os.makedirs(unit_dir, exist_ok=True)
    npz_path = os.path.join(unit_dir, f"dev_epoch{epoch:03d}.npz")
    np.savez(npz_path, **payload)
    manifest = {"split": "dev", "unit_id": unit_id, "seed": int(seed), "arm": arm,
                "epoch": int(epoch), "n_rows": len(keys),
                "npz_sha256": SC.sha256_file(npz_path),
                "label_free": True, "eval_batch_dialogues": eval_batch,
                "heads": ["fused"] + (["text", "audio", "visual"] if modal else [])}
    mpath = os.path.join(unit_dir, f"dev_epoch{epoch:03d}.manifest.json")
    json.dump(manifest, open(mpath, "w"), ensure_ascii=False, indent=2)
    return npz_path, manifest


def run_unit(*, seed: int, arm: str, binding: dict, train_dialogues, dev_dialogues,
             train_labels: dict, dev_labels: dict, device: str,
             text_dir: str | None = None, max_starts: int,
             sdt_shared: dict | None = None) -> dict:
    """One formal fit. sdt_shared carries per-seed initial state + RNG state so
    both SDT arms start from identical weights and dropout stream."""
    if arm not in spec.ALL_ARMS:
        raise ValueError(arm)
    if seed not in spec.SEEDS:
        raise ValueError(f"seed {seed} not in frozen seeds {spec.SEEDS}")
    if arm == "SDT_TEXT_UPDATED" and text_dir is None:
        raise ValueError("SDT_TEXT_UPDATED requires the accepted modern text cache")
    unit_id = spec.unit_id(seed, arm)
    aid = register_launch(unit_id, seed, arm, max_starts)
    unit_dir = os.path.join(spec.FITS, unit_id)
    if os.path.exists(unit_dir) and os.listdir(unit_dir):
        finish_launch(aid, "failed", 0, "unit dir already populated")
        raise FileExistsError(unit_dir)
    os.makedirs(unit_dir, exist_ok=True)
    started = time.time()
    steps = 0
    family = "mmdfn" if arm == "MMDFN_COMMON" else "sdt"
    recipe = spec.MMDFN if family == "mmdfn" else spec.SDT
    try:
        torch.set_num_threads(spec.INTRA)
        try:
            torch.set_num_interop_threads(spec.INTER)
        except RuntimeError:
            pass
        dev = torch.device(device)

        # ---- text features for the updated arm (identity-checked) -----------
        train_d = train_dialogues
        text_npz = None
        if arm == "SDT_TEXT_UPDATED":
            man = json.load(open(os.path.join(text_dir, "text_manifest.json")))
            tmaps = {}
            for split in ("train", "dev"):
                npz_p = os.path.join(text_dir, f"{split}.npz")
                sm = man["splits"][split]
                if SC.sha256_file(npz_p) != sm["npz_sha256"]:
                    raise ValueError(f"text cache {split} SHA mismatch")
                z = np.load(npz_p, allow_pickle=False)
                if str(z["model_sha"][()]) != man["model_sha256"]:
                    raise ValueError("text cache model SHA mismatch")
                if len(z["keys"]) != sm["n_rows"]:
                    raise ValueError("text cache row count mismatch")
                tmaps[split] = {str(k): v for k, v in zip(z["keys"], z["embeddings"])}
            text_npz = os.path.join(text_dir, "train.npz") + ";" + os.path.join(text_dir, "dev.npz")

            def _replace(dialogues, split):
                tmap = tmaps[split]
                out = []
                for d_ in dialogues:
                    feats = dict(d_.features)
                    feats["text"] = np.stack([tmap[k] for k in d_.utterance_ids]).astype(np.float32)
                    out.append(D.SotaDialogue(
                        d_.dialogue_id, d_.official_dialogue_id, d_.split,
                        d_.utterance_ids, d_.official_utterance_ids,
                        d_.speaker_ids, d_.speaker_onehot, feats, d_.p_index))
                return out
            train_d = _replace(train_dialogues, "train")
            dev_dialogues = _replace(dev_dialogues, "dev")

        # ---- model & shared initialisation ----------------------------------
        if family == "mmdfn":
            seed_everything(seed)
            model = build_mmdfn().to(dev)
            rng_state = None
        else:
            if sdt_shared is None or sdt_shared.get("seed") != seed:
                raise ValueError("SDT arms require the per-seed shared initialisation")
            model = SDT.build_sdt().to(dev)
            model.load_state_dict(sdt_shared["initial_state"])
            torch.set_rng_state(sdt_shared["rng_state"])
            rng_state = sdt_shared["rng_state"]
        initial_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        torch.save({"format": "sota_b1-initial-v1", "unit_id": unit_id, "seed": seed,
                    "arm": arm, "state": initial_state},
                   os.path.join(unit_dir, "initial.pt"))
        census = (SDT.param_census(model) if family == "sdt" else
                  {"total": int(sum(p.numel() for p in model.parameters())),
                   "trainable": int(sum(p.numel() for p in model.parameters() if p.requires_grad))})

        opt = torch.optim.Adam(model.parameters(), lr=recipe["lr"],
                               weight_decay=recipe["weight_decay"],
                               betas=tuple(recipe["betas"]), eps=recipe["eps"])
        assert len(opt.param_groups) == 1
        assert opt.param_groups[0]["lr"] == recipe["lr"]
        assert opt.param_groups[0]["weight_decay"] == recipe["weight_decay"]

        bs = recipe["batch_dialogues"]
        ids = [d_.dialogue_id for d_ in train_d]
        ucounts = [d_.length for d_ in train_d]
        by_id = {d_.dialogue_id: d_ for d_ in train_d}
        expected_keys = SC.expected_dev_keys(binding)

        history, best, best_state, stale = [], None, None, 0
        plans = []
        timing = {"train_seconds": 0.0, "dev_seconds": 0.0, "per_epoch": []}
        limit_s = spec.PER_FIT_MINUTES_MAX * 60
        time_hit = False

        def eval_and_select(epoch: int) -> tuple[dict, float]:
            nonlocal best, best_state, stale
            d0 = time.time()
            npz_p, man = dev_forward_write(model, family, dev_dialogues, unit_dir,
                                           unit_id=unit_id, seed=seed, arm=arm,
                                           epoch=epoch, device=dev)
            cand = SC.score_epoch(npz_p, man, unit_id=unit_id, seed=seed, arm=arm,
                                  epoch=epoch, binding=binding, dev_labels=dev_labels)
            dev_sec = time.time() - d0
            timing["dev_seconds"] += dev_sec
            improved = SC.is_better(cand, best)
            if improved:
                best = {k: cand[k] for k in ("epoch", "weighted_f1", "nll", "accuracy",
                                             "macro_f1", "brier", "npz_sha256")}
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                stale = 0
                torch.save({"format": "sota_b1-best-v1", "unit_id": unit_id, "seed": seed,
                            "arm": arm, "epoch": epoch, "state": best_state,
                            "selection": best},
                           os.path.join(unit_dir, "best.pt"))
            else:
                stale += 1
            cand["improved"] = improved
            history.append(cand)
            return cand, dev_sec

        # ---- epoch 0 (legal best) -------------------------------------------
        cand0, dev_sec0 = eval_and_select(0)
        timing["per_epoch"].append({"epoch": 0, "train_seconds": 0.0,
                                    "dev_seconds": round(dev_sec0, 3)})

        for epoch in range(1, recipe["max_epochs"] + 1):
            if time.time() - started > limit_s:
                time_hit = True
                break
            model.train()
            plan = D.batch_plan(ids, ucounts, seed=seed, epoch=epoch, batch_size=bs)
            plans.append({"epoch": epoch, "plan_sha256": plan["plan_sha256"],
                          "n_batches": len(plan["batches"])})
            t0 = time.time()
            tr_loss, n_utt = 0.0, 0
            for bspec in plan["batches"]:
                chunk = [by_id[x] for x in bspec["dialogue_ids"]]
                batch = D.collate(chunk)
                batch = {k: (v.to(dev) if torch.is_tensor(v) else v)
                         for k, v in batch.items()}
                if family == "mmdfn":
                    logits, logp = model(batch["text"], batch["audio"], batch["visual"],
                                         batch["qmask"], batch["umask"], batch["lengths"])
                    flat = logp  # already valid-row-flat [total,7], b-major
                    y = torch.tensor([train_labels[k] for k in batch["keys"]],
                                     dtype=torch.long, device=dev)
                    loss = focal_loss_mmdfn(flat, y, torch.ones_like(y),
                                            float(recipe["focal_gamma"]))
                    n = int(y.numel())
                else:
                    out = SDT.sdt_forward(model, batch)
                    y = torch.tensor([train_labels[k] for k in batch["keys"]],
                                     dtype=torch.long, device=dev)
                    # upstream layout is [B,T]; padding label 0 is masked out
                    ybt = torch.zeros(batch["umask"].permute(1, 0).shape,
                                      dtype=torch.long, device=dev)
                    off = 0
                    for b, d_ in enumerate(chunk):
                        ybt[b, :d_.length] = y[off:off + d_.length]
                        off += d_.length
                    loss, _parts = SDT.sdt_loss(out, ybt.reshape(-1),
                                                batch["umask"].permute(1, 0),
                                                tau=int(recipe["tau"]))
                    n = int(batch["umask"].sum().item())
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), recipe["clip"])
                opt.step()
                steps += 1
                tr_loss += float(loss.item()) * n
                n_utt += n
            train_sec = time.time() - t0
            timing["train_seconds"] += train_sec
            cand, dev_sec = eval_and_select(epoch)
            cand["train_loss"] = tr_loss / max(n_utt, 1)
            timing["per_epoch"].append({"epoch": epoch, "train_seconds": round(train_sec, 3),
                                        "dev_seconds": round(dev_sec, 3)})
            if stale >= recipe["patience"]:
                break

        # ---- last snapshot & record -----------------------------------------
        last_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        torch.save({"format": "sota_b1-last-v1", "unit_id": unit_id, "seed": seed,
                    "arm": arm, "epoch": history[-1]["epoch"], "state": last_state},
                   os.path.join(unit_dir, "last.pt"))
        json.dump(history, open(os.path.join(unit_dir, "history.json"), "w"),
                  ensure_ascii=False, indent=2)
        json.dump(plans, open(os.path.join(unit_dir, "batch_plans.json"), "w"),
                  ensure_ascii=False, indent=2)
        record = {
            "experiment_id": unit_id, "stage": spec.STAGE, "impl_version": spec.IMPL_VERSION,
            "status": "success", "failure_reason": None, "attempt_id": aid,
            "seed": int(seed), "arm": arm, "model_family": family,
            "dataset": "meld", "split": "official_train_dev", "context_mode": spec.CONTEXT,
            "device": str(dev), "dtype": spec.DTYPE,
            "recipe": {k: (list(v) if isinstance(v, tuple) else v) for k, v in recipe.items()},
            "optimizer": "Adam", "optimizer_steps": steps,
            "optimizer_param_groups": [{"lr": float(g["lr"]), "weight_decay": float(g["weight_decay"]),
                                        "n_params": int(sum(p.numel() for p in g["params"]))}
                                       for g in opt.param_groups],
            "param_census": census,
            "selection": {"rule": spec.SELECTION, "tie_tol": spec.TIE_TOL,
                          "best_epoch": int(best["epoch"]),
                          "best_weighted_f1": float(best["weighted_f1"]),
                          "best_nll": float(best["nll"]),
                          "best_npz_sha256": best["npz_sha256"]},
            "n_train_dialogues": len(train_d), "n_train_utterances": sum(ucounts),
            "n_dev_dialogues": len(dev_dialogues),
            "n_dev_utterances": sum(d_.length for d_ in dev_dialogues),
            "text_source": ("modern_roberta_large" if arm == "SDT_TEXT_UPDATED"
                            else "published_roberta1"),
            "text_npz": text_npz, "time_limit_hit": bool(time_hit),
            "wall_seconds": round(time.time() - started, 3), "timing": timing,
            "history_epochs": len(history),
            "test_set_read": False, "dev_labels_in_entry": False,
            "upstream_model_sha": (SDT.UPSTREAM_MODEL_SHA if family == "sdt" else None),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        json.dump(record, open(os.path.join(unit_dir, "record.json"), "w"),
                  ensure_ascii=False, indent=2)
        finish_launch(aid, "success", steps)
        return record
    except Exception as exc:
        finish_launch(aid, "failed", steps, f"{type(exc).__name__}: {exc}")
        json.dump({"status": "failed", "failure_reason": f"{type(exc).__name__}: {exc}",
                   "optimizer_steps": steps},
                  open(os.path.join(unit_dir, "failure.json"), "w"))
        raise


def make_sdt_shared(seed: int, device: str) -> dict:
    """Per-seed SDT initial weights + post-init RNG state (shared by both arms)."""
    seed_everything(seed)
    m = SDT.build_sdt().to(torch.device(device))
    state = {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}
    return {"seed": int(seed), "initial_state": state,
            "rng_state": torch.get_rng_state().clone(),
            "param_census": SDT.param_census(m)}