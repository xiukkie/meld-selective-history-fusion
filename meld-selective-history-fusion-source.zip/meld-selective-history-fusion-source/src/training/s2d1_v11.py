"""S2-D1 public-baseline training protocol for MELD (M3Net / MM-DFN)."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from ..data.public_meld_v11 import PublicDialogue, load_public_meld
from ..evaluation.metrics import compute_all_metrics
from ..models.m3net_v11 import M3Net
from ..models.mmdfn_v11 import MMDFN
from ..training.records import peak_memory_info, sha256_file
from ..utils.logging import utc_now
from ..utils.config import config_hash, save_config, validate_config
from ..utils.logging import RunLogger
from ..utils.seed import seed_everything

STAGE = "S2-D1.1"
IMPL_VERSION = "s2d1_1_v11"
MODEL_KINDS = ("mmdfn", "m3net")
TRACKS = ("native", "common")
RECIPES = {
    "mmdfn": {"R0": {"lr": 5e-4, "weight_decay": 1e-4},
              "R1": {"lr": 1e-3, "weight_decay": 1e-4}},
    "m3net": {"R0": {"lr": 1e-4, "weight_decay": 3e-5},
              "R1": {"lr": 3e-4, "weight_decay": 3e-5}},
}


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def default_s2d1_config(model_kind: str, track: str, seed: int, recipe: str,
                        *, features_root: str, project_root: str) -> dict:
    if model_kind not in MODEL_KINDS:
        raise ValueError(model_kind)
    if track not in TRACKS:
        raise ValueError(track)
    if recipe not in RECIPES[model_kind]:
        raise ValueError(recipe)
    if model_kind == "m3net" and track != "common":
        raise ValueError("M3Net S2-D1.1 path is F-common only")
    lr = RECIPES[model_kind][recipe]["lr"]
    wd = RECIPES[model_kind][recipe]["weight_decay"]
    if model_kind == "mmdfn":
        base = {"batch_size": 32, "hidden": 200, "d_e": 100, "graph_hidden": 100,
                "nlayers": 32, "dropout": 0.4, "focal_gamma": 0.5,
                "speaker_weights": [0.5, 0.5, 1.5], "reason_flag": True,
                "use_crn_speaker": True, "alpha": 0.2, "lamda": 0.5}
        if track == "native":
            text_dim = 600
        else:
            text_dim = 1024
    else:
        base = {"batch_size": 16, "hidden": 1024, "graph_hidden": 512,
                "num_L": 3, "num_K": 3, "dropout": 0.4,
                "focal_gamma": None, "use_residue": False}
        text_dim = 1024
    return {
        "experiment": {
            "stage": STAGE, "name": f"s2d1_{model_kind}_{track}_seed{seed}_{recipe}",
            "dataset": "meld", "model_kind": model_kind, "feature_track": track,
            "seed": int(seed), "recipe": recipe, "device": "cpu",
            "context_mode": "offline",
        },
        "data": {
            "features_root": os.path.abspath(os.path.join(project_root, features_root)),
            "feature_family": "mmdfn_native" if track == "native" else "m3net_roberta",
            "text_key": "roberta1", "four_text_layers": model_kind == "m3net",
            "repeat_roberta1": model_kind == "m3net",
            "text_dim": text_dim, "audio_dim": 300, "visual_dim": 342,
            "num_classes": 7, "num_speakers": 9,
        },
        "model": dict(base, model_kind=model_kind, text_dim=text_dim),
        "training": {
            "lr": lr, "weight_decay": wd, "batch_size": base["batch_size"],
            "grad_clip_norm": 1.0, "max_epochs": 60, "patience": 10,
            "time_limit_minutes": 45, "cpu_intra_threads": 5,
            "cpu_interop_threads": 15, "optimizer": "Adam",
            "betas": [0.9, 0.999], "eps": 1e-8,
        },
        "evaluation": {
            "selection_metric": "weighted_f1", "selection_mode": "dev_only",
            "dev_eval_batch_size": 1 if model_kind == "m3net" else 32,
            "metric_scale": "fraction",
        },
    }


def load_data(cfg: dict):
    track = cfg["experiment"]["feature_track"]
    root = cfg["data"]["features_root"]
    train = load_public_meld(root, "train", track=track,
                             four_text_layers=bool(cfg["data"]["four_text_layers"]),
                             repeat_roberta1=bool(cfg["data"].get("repeat_roberta1", False)))
    dev = load_public_meld(root, "dev", track=track,
                           four_text_layers=bool(cfg["data"]["four_text_layers"]),
                           repeat_roberta1=bool(cfg["data"].get("repeat_roberta1", False)))
    return train, dev


def collate(dialogues: list[PublicDialogue], model_kind: str, device) -> dict:
    B = len(dialogues)
    lengths = [d.length for d in dialogues]
    T = max(lengths)
    text_dim = dialogues[0].features["text"].shape[1]
    audio_dim = dialogues[0].features["audio"].shape[1]
    visual_dim = dialogues[0].features["visual"].shape[1]
    text = torch.zeros(T, B, text_dim)
    audio = torch.zeros(T, B, audio_dim)
    visual = torch.zeros(T, B, visual_dim)
    qmask = torch.zeros(T, B, 9)
    umask = torch.zeros(T, B)
    labels = torch.full((T, B), -1, dtype=torch.long)
    text_layers = ([torch.zeros(T, B, 1024) for _ in range(4)]
                   if model_kind == "m3net" else None)
    keys = []
    for b, d in enumerate(dialogues):
        n = d.length
        text[:n, b] = torch.from_numpy(d.features["text"])
        audio[:n, b] = torch.from_numpy(d.features["audio"])
        visual[:n, b] = torch.from_numpy(d.features["visual"])
        if text_layers is not None:
            for i in range(4):
                text_layers[i][:n, b] = torch.from_numpy(d.text_layers[i])
        qmask[:n, b] = torch.from_numpy(d.speaker_onehot)
        umask[:n, b] = 1
        labels[:n, b] = torch.from_numpy(d.labels)
        for j in range(n):
            keys.append({
                "dialogue_id": d.dialogue_id, "utterance_id": d.utterance_ids[j],
                "target_index": j, "speaker_id": int(d.speaker_ids[j]),
                "p_index": int(d.p_index[j]),
                "p_utterance_id": (d.utterance_ids[int(d.p_index[j])]
                                   if d.p_index[j] >= 0 else None),
                "true_label": int(d.labels[j]),
                "true_transition_label": (int(d.transition[j])
                                          if d.transition[j] >= 0 else None),
            })
    flat_labels = torch.tensor([k["true_label"] for k in keys], dtype=torch.long)
    flat_trans = torch.tensor([k["true_transition_label"] if k["true_transition_label"]
                               is not None else -1 for k in keys], dtype=torch.long)
    out = {"text": text.to(device), "audio": audio.to(device),
           "visual": visual.to(device), "qmask": qmask.to(device),
           "umask": umask.to(device), "labels": labels.to(device),
           "flat_labels": flat_labels.to(device), "flat_transition": flat_trans,
           "lengths": lengths, "keys": keys, "batch_size": B}
    if text_layers is not None:
        out["text_layers"] = [x.to(device) for x in text_layers]
    return out


def forward_batch(model, model_kind: str, batch: dict):
    if model_kind == "m3net":
        return model(batch["text_layers"], batch["audio"], batch["visual"],
                     batch["qmask"], batch["umask"], batch["lengths"])
    return model(batch["text"], batch["audio"], batch["visual"],
                 batch["qmask"], batch["umask"], batch["lengths"])


def focal_loss(log_probs, labels, mask, gamma: float, alpha: float | None = None):
    valid = mask.bool()
    lp = log_probs[valid]
    y = labels[valid]
    lp_true = lp.gather(1, y.unsqueeze(1)).squeeze(1)
    pt = lp_true.exp()
    loss = -((1 - pt) ** gamma) * lp_true
    if alpha is not None:
        loss = alpha * loss
    return loss.mean()


def focal_loss_mmdfn(log_probs, labels, mask, gamma: float = 0.5):
    """Fixed MIT focal: pt = detached(logpt).data.exp(); gamma=0.5."""
    valid = mask.bool()
    lp = log_probs[valid]
    y = labels[valid]
    lp_true = lp.gather(1, y.unsqueeze(1)).squeeze(1)
    pt = lp_true.detach().exp()
    return (-((1 - pt) ** gamma) * lp_true).mean()


def nll_loss(log_probs, labels, mask):
    valid = mask.bool()
    lp = log_probs[valid]
    y = labels[valid]
    return -lp.gather(1, y.unsqueeze(1)).squeeze(1).mean()


@torch.no_grad()
def evaluate_dev(model, model_kind, dialogues, batch_size, device):
    model.eval()
    order = list(range(len(dialogues)))
    y_true, y_pred, trans = [], [], []
    nll_sum, n = 0.0, 0
    for start in range(0, len(order), batch_size):
        chunk = [dialogues[i] for i in order[start:start + batch_size]]
        batch = collate(chunk, model_kind, device)
        logits, log_probs = forward_batch(model, model_kind, batch)
        labels = batch["labels"]
        mask = batch["umask"]
        fl = batch["flat_labels"]
        nll_sum += float(nll_loss(log_probs, fl, torch.ones_like(fl)).item()) * fl.numel()
        n += fl.numel()
        pred = logits.argmax(-1)
        y_true.append(fl.cpu().numpy())
        y_pred.append(pred.cpu().numpy())
        trans.append(batch["flat_transition"].numpy())
    y = np.concatenate(y_true)
    p = np.concatenate(y_pred)
    tr = np.concatenate(trans)
    metrics = compute_all_metrics(y, p, tr, num_classes=7)
    metrics["mean_ce"] = nll_sum / max(n, 1)
    return metrics


def is_better(cand: dict, best: dict | None) -> bool:
    if best is None:
        return True
    if cand["weighted_f1"] > best["weighted_f1"] + 1e-12:
        return True
    if abs(cand["weighted_f1"] - best["weighted_f1"]) <= 1e-12:
        if cand["nll"] < best["nll"] - 1e-12:
            return True
    return False


def _snapshot(path, model, cfg, epoch, history, selection_metrics):
    payload = {
        "format": "s2d1_1-eval-snapshot-v1", "stage": STAGE,
        "impl_version": IMPL_VERSION,
        "model_kind": cfg["experiment"]["model_kind"],
        "feature_track": cfg["experiment"]["feature_track"],
        "model_config": cfg["model"], "data_config": cfg["data"],
        "experiment": cfg["experiment"], "model_state": model.state_dict(),
        "epoch": int(epoch), "history": copy.deepcopy(history),
        "selection_metrics": copy.deepcopy(selection_metrics),
        "created_at": utc_now(),
    }
    torch.save(payload, path)


def run_training(*, cfg: dict, run_dir: str, project_root: str, logger: RunLogger | None = None):
    validate_config(cfg)
    model_kind = cfg["experiment"]["model_kind"]
    track = cfg["experiment"]["feature_track"]
    seed = int(cfg["experiment"]["seed"])
    if os.path.exists(run_dir) and os.listdir(run_dir):
        raise FileExistsError(run_dir)
    os.makedirs(run_dir, exist_ok=True)
    if logger is None:
        logger = RunLogger(run_dir, name="train")
    started = time.time()
    save_config(cfg, os.path.join(run_dir, "config.yaml"))
    cfg_hash = config_hash(cfg)
    seed_everything(seed)
    train, dev = load_data(cfg)
    device = torch.device("cpu")
    if model_kind == "mmdfn":
        text_dim = int(cfg["data"]["text_dim"])
        model = MMDFN(text_dim=text_dim,
                      hidden=int(cfg["model"]["hidden"]),
                      d_e=int(cfg["model"]["d_e"]),
                      graph_hidden=int(cfg["model"]["graph_hidden"]),
                      nlayers=int(cfg["model"]["nlayers"]),
                      dropout=float(cfg["model"]["dropout"]),
                      reason_flag=bool(cfg["model"]["reason_flag"]),
                      use_crn_speaker=bool(cfg["model"]["use_crn_speaker"]),
                      speaker_weights=cfg["model"]["speaker_weights"],
                      alpha=float(cfg["model"]["alpha"]),
                      lamda=float(cfg["model"]["lamda"])).to(device)
    else:
        model = M3Net(text_dim=int(cfg["data"]["text_dim"]),
                      hidden=int(cfg["model"]["hidden"]),
                      graph_hidden=int(cfg["model"]["graph_hidden"]),
                      dropout=float(cfg["model"]["dropout"]),
                      num_L=int(cfg["model"]["num_L"]),
                      num_K=int(cfg["model"]["num_K"]),
                      use_residue=bool(cfg["model"]["use_residue"])).to(device)
    if model_kind == "mmdfn":
        assert float(model.alpha) == float(cfg["model"]["alpha"]) == 0.2
        assert float(model.lamda) == float(cfg["model"]["lamda"]) == 0.5
        assert int(model.graph.alpha * 10) == 2 and float(model.graph.lamda) == 0.5
        assert len(model.graph.graph_net.convs) == int(cfg["model"]["nlayers"]) == 32
    else:
        assert len(model.graph.hyperconv) == int(cfg["model"]["num_L"]) == 3
        assert len(model.graph.highconv) == int(cfg["model"]["num_K"]) == 3
        assert model.graph.use_speaker is True and model.graph.use_modal is False
        assert model.use_residue is False
    opt = torch.optim.Adam(model.parameters(), lr=float(cfg["training"]["lr"]),
                           weight_decay=float(cfg["training"]["weight_decay"]),
                           betas=tuple(cfg["training"]["betas"]),
                           eps=float(cfg["training"]["eps"]))
    assert len(opt.param_groups) == 1
    assert abs(float(opt.param_groups[0]["lr"]) - float(cfg["training"]["lr"])) == 0.0
    assert abs(float(opt.param_groups[0]["weight_decay"])
               - float(cfg["training"]["weight_decay"])) == 0.0
    batch_size = int(cfg["training"]["batch_size"])
    patience = int(cfg["training"]["patience"])
    max_epochs = int(cfg["training"]["max_epochs"])
    limit_s = float(cfg["training"]["time_limit_minutes"]) * 60
    history, best, best_state, stale = [], None, None, 0
    timing = {"train_seconds": 0.0, "dev_seconds": 0.0, "per_epoch": []}
    rng = np.random.default_rng(seed * 100003 + 1)
    status, failure, time_hit = "success", None, False
    try:
        for epoch in range(1, max_epochs + 1):
            if time.time() - started > limit_s:
                time_hit = True
                logger.message("45min limit hit")
                break
            model.train()
            order = rng.permutation(len(train)).tolist()
            t0 = time.time()
            tr_loss, n = 0.0, 0
            for start in range(0, len(order), batch_size):
                chunk = [train[i] for i in order[start:start + batch_size]]
                batch = collate(chunk, model_kind, device)
                logits, log_probs = forward_batch(model, model_kind, batch)
                fl = batch["flat_labels"]
                if model_kind == "m3net":
                    loss = nll_loss(log_probs, fl, torch.ones_like(fl))
                else:
                    loss = focal_loss_mmdfn(log_probs, fl, torch.ones_like(fl),
                                            float(cfg["model"]["focal_gamma"]))
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),
                                               float(cfg["training"]["grad_clip_norm"]))
                opt.step()
                tr_loss += float(loss.item()) * int(fl.numel())
                n += int(fl.numel())
            train_sec = time.time() - t0
            d0 = time.time()
            metrics = evaluate_dev(model, model_kind, dev,
                                   int(cfg["evaluation"]["dev_eval_batch_size"]), device)
            dev_sec = time.time() - d0
            overall = metrics["overall"]
            cand = {"epoch": epoch, "weighted_f1": float(overall["weighted_f1"]),
                    "accuracy": float(overall["accuracy"]),
                    "macro_f1": float(overall["macro_f1"]),
                    "nll": float(metrics["mean_ce"]),
                    "train_loss": tr_loss / max(n, 1)}
            improved = is_better(cand, best)
            if improved:
                best = dict(cand)
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                stale = 0
                _snapshot(os.path.join(run_dir, "best.pt"), model, cfg, epoch,
                          history + [cand], {k: best[k] for k in
                                             ("weighted_f1", "accuracy", "macro_f1", "nll")})
            else:
                stale += 1
            history.append(cand)
            timing["train_seconds"] += train_sec
            timing["dev_seconds"] += dev_sec
            timing["per_epoch"].append({"epoch": epoch, "train_seconds": round(train_sec, 3),
                                        "dev_seconds": round(dev_sec, 3)})
            logger.event("epoch", **cand, improved=improved,
                         train_seconds=round(train_sec, 3), dev_seconds=round(dev_sec, 3))
            logger.message(f"epoch {epoch}: loss={cand['train_loss']:.4f} "
                           f"dev wF1={cand['weighted_f1']:.4f} NLL={cand['nll']:.4f} "
                           f"{'[best]' if improved else ''}")
            if stale >= patience:
                break
        if best_state is None:
            raise RuntimeError("no best checkpoint")
        model.load_state_dict(best_state)
        metrics = evaluate_dev(model, model_kind, dev,
                               int(cfg["evaluation"]["dev_eval_batch_size"]), device)
        # full dev predictions from best
        model.eval()
        rows = []
        for start in range(0, len(dev), int(cfg["evaluation"]["dev_eval_batch_size"])):
            chunk = dev[start:start + int(cfg["evaluation"]["dev_eval_batch_size"])]
            batch = collate(chunk, model_kind, device)
            logits, log_probs = forward_batch(model, model_kind, batch)
            probs = log_probs.exp()
            pred = logits.argmax(-1)
            flat = 0
            for b, d in enumerate(chunk):
                for j in range(d.length):
                    k = batch["keys"][flat]
                    rows.append({**k,
                                 "pred_label": int(pred[flat, b].item()) if False else
                                 int(pred[flat].item()),
                                 "probs": [float(x) for x in probs[flat].tolist()],
                                 "log_probs": [float(x) for x in log_probs[flat].tolist()]})
                    flat += 1
        history_path = os.path.join(run_dir, "history.json")
        json.dump(history, open(history_path, "w"), ensure_ascii=False, indent=2)
        pred_path = os.path.join(run_dir, "predictions_dev.jsonl")
        with open(pred_path, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        metrics_path = os.path.join(run_dir, "metrics_dev.json")
        json.dump(metrics, open(metrics_path, "w"), ensure_ascii=False, indent=2)
        record = {
            "experiment_id": os.path.basename(run_dir), "stage": STAGE,
            "impl_version": IMPL_VERSION,
            "model_family": ("s2d1_1_m3net_v11" if model_kind == "m3net"
                             else "s2d1_1_mmdfn_gdf32_v11"),
            "status": status, "failure_reason": failure,
            "model_kind": model_kind, "feature_track": track, "seed": seed,
            "recipe": cfg["experiment"]["recipe"],
            "lr": float(cfg["training"]["lr"]),
            "weight_decay": float(cfg["training"]["weight_decay"]),
            "dataset": "meld", "split": "official_train_dev",
            "device": str(device), "config_hash": cfg_hash, "config": cfg,
            "model_config": cfg["model"],
            "num_parameters": int(sum(p.numel() for p in model.parameters())),
            "optimizer_param_groups": [{"lr": float(g["lr"]),
                                         "weight_decay": float(g["weight_decay"]),
                                         "n_params": int(sum(p.numel() for p in g["params"]))}
                                        for g in opt.param_groups],
            "dev_eval_batch_size": int(cfg["evaluation"]["dev_eval_batch_size"]),
            "loss": "standard NLL/CE" if model_kind == "m3net" else "fixed-source focal gamma0.5 (detached pt)",
            "alpha": float(cfg["model"].get("alpha", 0.0)) if model_kind == "mmdfn" else None,
            "lamda": float(cfg["model"].get("lamda", 0.0)) if model_kind == "mmdfn" else None,
            "selection": {"best_epoch": int(best["epoch"]),
                          "weighted_f1": float(best["weighted_f1"]),
                          "nll": float(best["nll"]),
                          "rule": "wF1 max; tie NLL lower; then earlier epoch"},
            "metrics": metrics, "history": history, "timing": timing,
            "wall_seconds": round(time.time() - started, 3),
            "time_limit_hit": bool(time_hit), "peak_memory": peak_memory_info(),
            "data_manifest": {
                "features_root": cfg["data"]["features_root"],
                "n_train_dialogues": len(train), "n_dev_dialogues": len(dev),
                "n_train_utterances": sum(d.length for d in train),
                "n_dev_utterances": sum(d.length for d in dev),
                "feature_track": track,
            },
            "checkpoint": os.path.join(run_dir, "best.pt"),
            "predictions": pred_path, "metrics_file": metrics_path,
            "implementation": ("M3Net adapted dense (fixed upstream 4d0fa88)" if model_kind == "m3net"
                               else "MM-DFN GDF32 adapted (fixed MIT upstream da97036)"),
            "test_set_read": False,
            "notes": ["official MELD train/dev only", "no test loader",
                      "public model adapted; not official upstream run"],
        }
        json.dump(record, open(os.path.join(run_dir, "record.json"), "w"),
                  ensure_ascii=False, indent=2)
        logger.event("success", wall_seconds=record["wall_seconds"],
                     best_epoch=int(best["epoch"]))
        return record
    except Exception as exc:
        failure = f"{type(exc).__name__}: {exc}"
        json.dump({"status": "failed", "failure_reason": failure},
                  open(os.path.join(run_dir, "failure.json"), "w"),
                  ensure_ascii=False, indent=2)
        logger.event("failure", reason=failure)
        raise
    finally:
        logger.close()
