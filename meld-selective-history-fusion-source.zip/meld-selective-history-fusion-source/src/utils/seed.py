"""随机种子与运行设备。"""
from __future__ import annotations

import os
import random

import numpy as np


def seed_everything(seed: int) -> None:
    """固定 Python/NumPy/PyTorch 随机源。

    MPS 上并非所有算子都保证逐位可复现；本项目只要求在相同设备与相同输入下
    预测一致（标签置乱不变性测试），不宣称跨硬件逐位一致。
    """
    os.environ["PYTHONHASHSEED"] = str(int(seed))
    random.seed(int(seed))
    np.random.seed(int(seed))
    import torch  # 延迟导入，便于仅做数据审计时不依赖 torch

    torch.manual_seed(int(seed))
    if torch.cuda.is_available():  # pragma: no cover - 本机无 CUDA
        torch.cuda.manual_seed_all(int(seed))
    torch.backends.cudnn.deterministic = True  # pragma: no cover - 本机无 CUDA
    torch.backends.cudnn.benchmark = False  # pragma: no cover - 本机无 CUDA


def resolve_device(requested: str = "auto"):
    """设备选择：auto 优先 mps，其次 cuda，最后 cpu；显式请求失败时明确报错。"""
    import torch

    requested = (requested or "auto").lower()
    if requested == "auto":
        if torch.backends.mps.is_available():
            return torch.device("mps")
        if torch.cuda.is_available():  # pragma: no cover
            return torch.device("cuda")
        return torch.device("cpu")
    if requested == "mps":
        if not torch.backends.mps.is_available():
            raise RuntimeError("请求 mps 但当前环境 MPS 不可用")
        return torch.device("mps")
    if requested == "cuda":  # pragma: no cover
        if not torch.cuda.is_available():
            raise RuntimeError("请求 cuda 但当前环境 CUDA 不可用")
        return torch.device("cuda")
    if requested == "cpu":
        return torch.device("cpu")
    raise ValueError(f"未知设备 {requested!r}")
