"""配置加载、校验与哈希。

配置是实验约束的唯一来源：数据划分、上下文范围、选模指标、种子等都必须在
运行前写入 YAML，运行时不得隐式改协议。
"""
from __future__ import annotations

import hashlib
import json
import os
from copy import deepcopy

import yaml

from .protocol import UnsupportedProtocolError, validate_supported_protocol

_REQUIRED_TOP_KEYS = ("experiment", "data", "model", "training", "evaluation")


def load_config(path: str) -> dict:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"配置文件不存在: {path}")
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError(f"配置文件必须解析为字典: {path}")
    for key in _REQUIRED_TOP_KEYS:
        if key not in cfg:
            raise KeyError(f"配置缺少顶层字段 {key!r}: {path}")
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict) -> None:
    exp = cfg["experiment"]
    for key in ("name", "stage", "dataset", "seed", "context_mode"):
        if key not in exp:
            raise KeyError(f"experiment 缺少字段 {key!r}")
    if exp["dataset"] not in ("meld", "iemocap"):
        raise ValueError(f"未知 dataset={exp['dataset']!r}")
    if exp["context_mode"] not in ("offline", "prefix"):
        raise ValueError(f"未知 context_mode={exp['context_mode']!r}（必须显式声明）")
    # 本轮明确只支持 offline + 双向；不支持的配置在任何训练/评价开始前拒绝。
    validate_supported_protocol(cfg, entry="config")
    if not isinstance(exp["seed"], int):
        raise TypeError("experiment.seed 必须是整数")
    if exp.get("allow_test_reading", False):
        raise ValueError(
            "S0/S1/S2/S3 开发配置禁止设置 allow_test_reading=True；"
            "最终测试需在配置冻结后单独声明并记录暴露情况。"
        )

    data = cfg["data"]
    if "features_root" not in data:
        raise KeyError("data.features_root 缺失")
    modalities = data.get("modalities", ["text", "audio", "visual"])
    if not modalities or not set(modalities).issubset({"text", "audio", "visual"}):
        raise ValueError(f"data.modalities 非法: {modalities}")
    if "text_key" in data and data["text_key"] not in ("roberta1", "roberta2", "roberta3", "roberta4"):
        raise ValueError(f"data.text_key 非法: {data['text_key']}")
    for key in ("train_limit", "dev_limit"):
        value = data.get(key)
        if value is not None and (not isinstance(value, int) or value <= 0):
            raise ValueError(f"data.{key} 必须是正整数或 null")

    model = cfg["model"]
    if model.get("encoder", "gru") not in ("gru",):
        raise ValueError(f"未知 model.encoder={model.get('encoder')!r}")
    if model.get("bidirectional", True) is not True:
        raise UnsupportedProtocolError(
            "当前实现只支持双向序列编码器（bidirectional=True）；拒绝 bidirectional=False。"
        )
    if int(model.get("hidden", 0)) <= 0:
        raise ValueError("model.hidden 必须为正整数")

    training = cfg["training"]
    for key in ("max_epochs", "batch_size", "lr", "patience"):
        if key not in training:
            raise KeyError(f"training.{key} 缺失")
    if int(training["max_epochs"]) <= 0 or int(training["batch_size"]) <= 0:
        raise ValueError("max_epochs/batch_size 必须为正整数")
    if float(training["lr"]) <= 0:
        raise ValueError("training.lr 必须为正")
    if int(training["patience"]) < 0:
        raise ValueError("training.patience 不能为负")

    evaluation = cfg["evaluation"]
    if evaluation.get("selection_metric") != "weighted_f1":
        raise ValueError("本项目选模指标固定为 dev weighted_f1（见 docs/实验规范.md）")
    if evaluation.get("selection_mode") != "dev_only":
        raise ValueError("选模只允许 dev_only")


def config_hash(cfg: dict) -> str:
    canonical = json.dumps(cfg, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def freeze_config(cfg: dict) -> dict:
    """深拷贝，防止运行期意外修改配置对象。"""
    return deepcopy(cfg)


def save_config(cfg: dict, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=True)
