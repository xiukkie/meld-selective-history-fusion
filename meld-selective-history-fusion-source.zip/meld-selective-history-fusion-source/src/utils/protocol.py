"""S1.1 支持的训练协议声明与强制校验。

当前实现只支持 offline（完整对话可见）+ 双向序列编码器。
prefix（前缀/在线）尚未实现；用户把配置值改成 prefix 不会改变模型的可见范围，
因此必须在配置解析、训练/评价入口和模型构造三处显式拒绝，避免“配置声称 prefix、
实际使用未来信息”的静默错误。
"""
from __future__ import annotations

SUPPORTED_CONTEXT_MODES: tuple[str, ...] = ("offline",)
SUPPORTED_BIDIRECTIONAL = True


class UnsupportedProtocolError(ValueError):
    """请求了当前实现尚未支持、且不能静默降级的训练协议。"""


def validate_supported_protocol(cfg: dict, entry: str = "config") -> None:
    """校验配置所声明的上下文范围/编码器方向是否被当前实现支持。

    Args:
        cfg: 至少包含 experiment/model 两节的配置字典。
        entry: 调用入口名，用于报错定位（config/run_experiment/evaluate/model/...）。

    Raises:
        UnsupportedProtocolError: 请求了 prefix 或双向以外的编码器。
    """
    if not isinstance(cfg, dict):
        raise UnsupportedProtocolError(f"[{entry}] 配置必须是字典，实际为 {type(cfg).__name__}")
    exp = cfg.get("experiment")
    if not isinstance(exp, dict):
        raise UnsupportedProtocolError(f"[{entry}] 配置缺少 experiment 节")
    context_mode = exp.get("context_mode")
    if context_mode not in SUPPORTED_CONTEXT_MODES:
        raise UnsupportedProtocolError(
            f"[{entry}] 当前实现只支持 offline 双向基线，不能提供 prefix 前缀信息隔离；"
            f"拒绝 context_mode={context_mode!r}。"
            f"（双向序列编码器会读取未来话语；单向/在线实现尚未完成，不得用配置值冒充。）"
        )

    model = cfg.get("model")
    if not isinstance(model, dict):
        raise UnsupportedProtocolError(f"[{entry}] 配置缺少 model 节")
    bidirectional = model.get("bidirectional", True)
    if bidirectional is not True:
        raise UnsupportedProtocolError(
            f"[{entry}] 当前实现只支持双向序列编码器（bidirectional=True）；"
            f"拒绝 bidirectional={bidirectional!r}。单向编码器尚未实现，"
            f"修改该字段不会得到单向模型，只会得到不一致的模型结构。"
        )
