"""运行日志：同时写 JSONL（机器可读）与纯文本（人工检查）。"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone


def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


class RunLogger:
    def __init__(self, run_dir: str, name: str = "train"):
        self.run_dir = run_dir
        os.makedirs(run_dir, exist_ok=True)
        self.jsonl_path = os.path.join(run_dir, f"{name}.jsonl")
        self.txt_path = os.path.join(run_dir, f"{name}.log")
        self._jsonl = open(self.jsonl_path, "a", encoding="utf-8")
        self._txt = open(self.txt_path, "a", encoding="utf-8")

    def event(self, event: str, **fields) -> dict:
        payload = {"timestamp": utc_now(), "event": event}
        payload.update(fields)
        self._jsonl.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self._jsonl.flush()
        return payload

    def message(self, text: str) -> None:
        line = f"[{utc_now()}] {text}"
        print(line, flush=True)
        self._txt.write(line + "\n")
        self._txt.flush()

    def close(self) -> None:
        self._jsonl.close()
        self._txt.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def tee_stdout(path: str):  # pragma: no cover - 仅供脚本使用
    """把 stdout/stderr 同时写入文件（脚本级原始日志）。"""
    class _Tee:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for s in self.streams:
                s.write(data)
                s.flush()

        def flush(self):
            for s in self.streams:
                s.flush()

    fh = open(path, "a", encoding="utf-8")
    original_out, original_err = sys.stdout, sys.stderr
    sys.stdout = _Tee(original_out, fh)
    sys.stderr = _Tee(original_err, fh)

    class _TeeHandle:
        def close(self):
            # 恢复原始流后再关闭文件，避免解释器退出时向已关闭文件 flush（exit code 120）
            sys.stdout = original_out
            sys.stderr = original_err
            if not fh.closed:
                fh.flush()
                fh.close()

    return _TeeHandle()
