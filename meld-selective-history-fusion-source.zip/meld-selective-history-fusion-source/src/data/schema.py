"""统一对话数据结构与不变量校验。

本模块定义 S1 基线所需的最小数据结构：一段对话 = 若干按原始时间顺序排列的话语，
每句话带说话人、标签、三模态特征与有效性掩码。

设计边界（对应 docs/实验规范.md）：
- 对话内顺序不可打乱；
- padding 不进入图/节点（数据层只保留真实话语，padding 仅发生在批处理张量层）；
- p(i) 只在同一对话内查找同一说话人的最近更早话语；
- 转变标签 z_i = 1[y_i != y_p(i)] 只用于训练/评价，不作为模型输入。
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

MODALITIES: tuple[str, ...] = ("text", "audio", "visual")
SPLITS: tuple[str, ...] = ("train", "dev", "test")
CONTEXT_MODES: tuple[str, ...] = ("offline", "prefix")


def same_speaker_predecessor(speaker_ids: np.ndarray) -> np.ndarray:
    """返回每句话在同一对话内同说话人的最近更早话语下标；不存在则为 -1。

    不使用全局上一句，也不跨对话检索。
    """
    speaker_ids = np.asarray(speaker_ids, dtype=np.int64)
    last_seen: dict[int, int] = {}
    p = np.full(speaker_ids.shape, -1, dtype=np.int64)
    for i, spk in enumerate(speaker_ids.tolist()):
        if spk in last_seen:
            p[i] = last_seen[spk]
        last_seen[spk] = i
    return p


def derive_transition(labels: np.ndarray, p_index: np.ndarray) -> np.ndarray:
    """z_i = 1[y_i != y_p(i)]；无 p(i) 的样本为 -1（训练时掩码跳过）。"""
    labels = np.asarray(labels, dtype=np.int64)
    p_index = np.asarray(p_index, dtype=np.int64)
    trans = np.full(labels.shape, -1, dtype=np.int64)
    has_p = p_index >= 0
    trans[has_p] = (labels[has_p] != labels[p_index[has_p]]).astype(np.int64)
    return trans


@dataclass
class Dialogue:
    """一段对话的规范化表示。

    所有数组都只覆盖真实话语（长度 T），不包含 padding。
    """

    dialogue_id: str
    split: str
    utterance_ids: list[str]
    speaker_ids: np.ndarray          # (T,) int64，对话内角色编号（数据集内语义见对应 loader）
    labels: np.ndarray               # (T,) int64，类别编号；本项目中每句都有标签
    features: dict[str, np.ndarray]  # modality -> (T, D_m) float32
    modality_mask: dict[str, np.ndarray]  # modality -> (T,) bool，False 表示该句该模态缺失
    p_index: np.ndarray              # (T,) int64，同说话人最近更早话语下标，-1 表示无
    transition: np.ndarray           # (T,) int64，{-1,0,1}，仅评价/辅助训练使用
    context_mode: str = "offline"
    texts: list[str] | None = None   # (T,) 已核验句子文本（TF-IDF 特征族与候选检索用；不进入情感标签）

    def __post_init__(self) -> None:
        t = len(self.utterance_ids)
        if t == 0:
            raise ValueError(f"{self.dialogue_id}: 对话必须至少包含一句话")
        if self.split not in SPLITS:
            raise ValueError(f"{self.dialogue_id}: 未知 split={self.split!r}")
        if self.context_mode not in CONTEXT_MODES:
            raise ValueError(
                f"{self.dialogue_id}: context_mode 必须是 {CONTEXT_MODES} 之一，"
                f"实际为 {self.context_mode!r}"
            )
        if len(set(self.utterance_ids)) != t:
            raise ValueError(f"{self.dialogue_id}: utterance_id 存在重复")
        if self.texts is not None:
            if not isinstance(self.texts, list) or len(self.texts) != t:
                raise ValueError(f"{self.dialogue_id}: texts 必须是长度 {t} 的字符串列表")
            if any(not isinstance(x, str) for x in self.texts):
                raise ValueError(f"{self.dialogue_id}: texts 含非字符串")

        for name in ("speaker_ids", "labels", "p_index", "transition"):
            arr = getattr(self, name)
            if not isinstance(arr, np.ndarray) or arr.ndim != 1 or arr.shape[0] != t:
                raise ValueError(f"{self.dialogue_id}: {name} 必须是长度 {t} 的一维 ndarray")
        if not np.issubdtype(self.speaker_ids.dtype, np.integer):
            raise ValueError(f"{self.dialogue_id}: speaker_ids 必须是整数")
        if np.any(self.speaker_ids < 0):
            raise ValueError(f"{self.dialogue_id}: speaker_ids 不能为负")
        if not np.issubdtype(self.labels.dtype, np.integer) or np.any(self.labels < 0):
            raise ValueError(f"{self.dialogue_id}: labels 必须是非负整数")
        if np.any(self.p_index < -1) or np.any(self.p_index >= t):
            raise ValueError(f"{self.dialogue_id}: p_index 越界")
        for i, p in enumerate(self.p_index.tolist()):
            if p >= 0:
                if p >= i:
                    raise ValueError(f"{self.dialogue_id}: p({i})={p} 必须早于当前话语")
                if self.speaker_ids[p] != self.speaker_ids[i]:
                    raise ValueError(f"{self.dialogue_id}: p({i})={p} 与当前话语说话人不同")
        if np.any(~np.isin(self.transition, (-1, 0, 1))):
            raise ValueError(f"{self.dialogue_id}: transition 只能取 -1/0/1")
        if not np.array_equal(self.transition == -1, self.p_index == -1):
            raise ValueError(f"{self.dialogue_id}: transition 掩码必须与 p_index 一致")
        has_p = self.p_index >= 0
        expected = (self.labels[has_p] != self.labels[self.p_index[has_p]]).astype(np.int64)
        if not np.array_equal(self.transition[has_p], expected):
            raise ValueError(f"{self.dialogue_id}: transition 与标签/前驱不一致")

        if set(self.features) != set(MODALITIES):
            raise ValueError(f"{self.dialogue_id}: features 必须恰好包含 {MODALITIES}")
        if set(self.modality_mask) != set(MODALITIES):
            raise ValueError(f"{self.dialogue_id}: modality_mask 必须恰好包含 {MODALITIES}")
        for m in MODALITIES:
            f = self.features[m]
            mask = self.modality_mask[m]
            if not isinstance(f, np.ndarray) or f.ndim != 2 or f.shape[0] != t:
                raise ValueError(f"{self.dialogue_id}: features[{m}] 必须是 (T, D) float32，实际 {getattr(f, 'shape', None)}")
            if f.shape[1] == 0:
                raise ValueError(f"{self.dialogue_id}: features[{m}] 特征维度为 0")
            if f.dtype != np.float32:
                raise ValueError(f"{self.dialogue_id}: features[{m}] dtype 必须是 float32")
            if not np.all(np.isfinite(f)):
                raise ValueError(f"{self.dialogue_id}: features[{m}] 存在非有限值")
            if not isinstance(mask, np.ndarray) or mask.shape != (t,) or mask.dtype != bool:
                raise ValueError(f"{self.dialogue_id}: modality_mask[{m}] 必须是长度 {t} 的 bool 数组")
            missing_rows = ~mask
            if np.any(f[missing_rows] != 0):
                raise ValueError(f"{self.dialogue_id}: features[{m}] 缺失话语的特征必须置 0")

    @property
    def length(self) -> int:
        return len(self.utterance_ids)

    @property
    def num_classes_used(self) -> int:
        return int(self.labels.max()) + 1

    def transition_prevalence(self) -> dict[str, float | int]:
        """返回转变标签的描述性统计（仅评价/数据分析用，不是模型输入）。"""
        valid = self.transition >= 0
        n_valid = int(valid.sum())
        n_pos = int((self.transition[valid] == 1).sum())
        return {
            "n_utterances": self.length,
            "n_with_p": n_valid,
            "n_transition": n_pos,
            "transition_rate": (n_pos / n_valid) if n_valid else 0.0,
        }


def build_dialogue(
    dialogue_id: str,
    split: str,
    utterance_ids: list[str],
    speaker_ids: np.ndarray,
    labels: np.ndarray,
    features: dict[str, np.ndarray],
    context_mode: str = "offline",
    modality_mask: dict[str, np.ndarray] | None = None,
    texts: list[str] | None = None,
) -> Dialogue:
    """由原始数组构造 Dialogue，并自动计算 p(i)、转变标签与默认有效性掩码。"""
    speaker_ids = np.asarray(speaker_ids, dtype=np.int64)
    labels = np.asarray(labels, dtype=np.int64)
    t = len(utterance_ids)
    if modality_mask is None:
        modality_mask = {m: np.ones(t, dtype=bool) for m in MODALITIES}
    feats = {m: np.ascontiguousarray(np.asarray(features[m], dtype=np.float32)) for m in MODALITIES}
    mask = {m: np.asarray(modality_mask[m], dtype=bool) for m in MODALITIES}
    for m in MODALITIES:
        missing = ~mask[m]
        if np.any(missing):
            feats[m] = feats[m].copy()
            feats[m][missing] = 0.0
    p_index = same_speaker_predecessor(speaker_ids)
    transition = derive_transition(labels, p_index)
    return Dialogue(
        dialogue_id=dialogue_id,
        split=split,
        utterance_ids=list(utterance_ids),
        speaker_ids=speaker_ids,
        labels=labels,
        features=feats,
        modality_mask=mask,
        p_index=p_index,
        transition=transition,
        context_mode=context_mode,
        texts=list(texts) if texts is not None else None,
    )
