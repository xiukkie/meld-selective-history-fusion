"""MELD 预提取特征加载器（M3NET 发布特征 + COSMIC RoBERTa 文本特征）。

真实来源与核验记录见 review/S0S1_*/02_数据来源清单.md：
- MELD_features_raw1.pkl:  M3NET 官方 Dropbox 特征包（MM-DFN 生成的 utterance 级特征）
- meld_features_roberta.pkl: COSMIC/fairseq RoBERTa 特征（逐句独立编码，train 划分微调）
两文件 SHA-256 已与官方发布包逐字节核对。

划分恢复：
- 基础 pkl 的 trainVid 合并了官方 train+dev（并按官方顺序偏移），不能直接当训练集；
- roberta pkl 保留 trainIds=1038 / validIds=114 / testIds=280，恢复官方 MELD 划分。
- 官方划分另经 data/MELD/train|dev|test_sent_emo.csv 逐句核对（见 scripts/audit_data.py）。

本模块只做数据装载与字段规范化，不做任何标签相关的模型输入。
"""
from __future__ import annotations

import os
import pickle
from functools import lru_cache

import numpy as np

from .schema import Dialogue, build_dialogue
from .text import decode_pkl_text

MELD_NUM_CLASSES = 7
MELD_NUM_ROLE_SLOTS = 9  # 基础 pkl 的说话人 one-hot 维度；对话内角色槽位，非全局身份

# 官方 MELD 七类标签在特征文件中的整数编号（已用官方 CSV 逐句核对，0 处不一致）
MELD_LABEL_NAMES = {
    0: "neutral",
    1: "surprise",
    2: "fear",
    3: "sadness",
    4: "joy",
    5: "disgust",
    6: "anger",
}

_FEATURE_FILES = {
    "base": "MELD_features_raw1.pkl",
    "roberta": "meld_features_roberta.pkl",
}

# roberta pkl 结构（11 个元素）: [0]=speaker one-hot, [1]=speaker 标量,
# [2]=另一标量字段, [3..6]=roberta1..4, [7]=sentences, [8]=trainIds,
# [9]=testIds, [10]=validIds
_ROBERTA_TEXT_INDEX = {
    "roberta1": 3,
    "roberta2": 4,
    "roberta3": 5,
    "roberta4": 6,
}
_SPLIT_IDS_INDEX = {"train": 8, "test": 9, "dev": 10}

# 基础 pkl 结构（10 个元素）: [0]=videoIDs, [1]=speakers one-hot,
# [2]=labels, [3]=videoText(600), [4]=videoAudio(300), [5]=videoVisual(342),
# [6]=videoSentence, [7]=trainVid(set), [8]=testVid(set), [9]=None
_BASE_SPEAKERS = 1
_BASE_LABELS = 2
_BASE_AUDIO = 4
_BASE_VISUAL = 5
_BASE_TEXTS = 6


@lru_cache(maxsize=8)
def _load_pickles(features_dir: str) -> tuple[tuple, tuple]:
    base_path = os.path.join(features_dir, _FEATURE_FILES["base"])
    rob_path = os.path.join(features_dir, _FEATURE_FILES["roberta"])
    for p in (base_path, rob_path):
        if not os.path.isfile(p):
            raise FileNotFoundError(
                f"缺少 MELD 特征文件: {p}。请将 M3NET 官方特征放入 {features_dir}，"
                "并运行 scripts/audit_data.py 核对 SHA-256。"
            )
    with open(base_path, "rb") as f:
        base = pickle.load(f, encoding="latin1")
    with open(rob_path, "rb") as f:
        rob = pickle.load(f, encoding="latin1")
    if len(rob) != 11 or len(base) != 10:
        raise ValueError(
            f"MELD 特征 pkl 结构不符合预期: base={len(base)} 个元素, roberta={len(rob)} 个元素"
        )
    return tuple(base), tuple(rob)


def split_dialogue_ids(features_dir: str, split: str) -> list[int]:
    """返回官方划分下的对话键列表（已排序，保证可复现）。"""
    if split not in _SPLIT_IDS_INDEX:
        raise ValueError(f"未知 split={split!r}")
    _, rob = _load_pickles(features_dir)
    return sorted(int(x) for x in rob[_SPLIT_IDS_INDEX[split]])


def load_dialogues(
    features_dir: str,
    split: str,
    text_key: str = "roberta1",
    context_mode: str = "offline",
    allow_test: bool = False,
    limit: int | None = None,
) -> list[Dialogue]:
    """装载 MELD 指定划分的对话列表。

    Args:
        features_dir: 特征目录（含 MELD_features_raw1.pkl / meld_features_roberta.pkl）。
        split: "train" | "dev" | "test"。
        text_key: 使用哪个 RoBERTa 层特征作为文本模态（roberta1 为最后一层 [CLS]）。
        context_mode: "offline" 或 "prefix"，仅作为元数据写入，模型使用方式由训练配置声明。
        allow_test: 是否允许读取测试集。S1/S2 开发阶段必须为 False。
        limit: 只取前 N 个对话（仅用于冒烟测试/有界试验），按排序后的对话键截取。

    Returns:
        Dialogue 列表，按 data 文件中的对话键排序，保证跨进程可复现。
    """
    if split == "test" and not allow_test:
        raise PermissionError(
            "拒绝读取测试集：开发阶段仅允许 train/dev。"
            "若确需在配置冻结后运行最终测试，请显式设置 allow_test=True 并记录暴露情况。"
        )
    if text_key not in _ROBERTA_TEXT_INDEX:
        raise ValueError(f"text_key 必须是 {sorted(_ROBERTA_TEXT_INDEX)} 之一")
    base, rob = _load_pickles(features_dir)
    text_idx = _ROBERTA_TEXT_INDEX[text_key]

    ids = split_dialogue_ids(features_dir, split)
    if limit is not None:
        ids = ids[: int(limit)]
    if not ids:
        raise ValueError(f"MELD split={split} 为空")

    out: list[Dialogue] = []
    for k in ids:
        n_utt = len(base[_BASE_LABELS][k])
        speakers = np.argmax(np.asarray(base[_BASE_SPEAKERS][k], dtype=np.float32), axis=1)
        labels = np.asarray(base[_BASE_LABELS][k], dtype=np.int64)
        text = np.asarray(rob[text_idx][k], dtype=np.float32)
        audio = np.asarray(base[_BASE_AUDIO][k], dtype=np.float32)
        visual = np.asarray(base[_BASE_VISUAL][k], dtype=np.float32)
        texts = [decode_pkl_text(x) for x in base[_BASE_TEXTS][k]]
        if not (len(speakers) == len(labels) == text.shape[0] == audio.shape[0] == visual.shape[0] == n_utt):
            raise ValueError(f"MELD 对话 {k} 各字段长度不一致")
        out.append(
            build_dialogue(
                dialogue_id=f"meld_d{k:04d}",
                split=split,
                utterance_ids=[f"meld_d{k:04d}_u{j:03d}" for j in range(n_utt)],
                speaker_ids=speakers,
                labels=labels,
                features={"text": text, "audio": audio, "visual": visual},
                context_mode=context_mode,
                texts=texts,
            )
        )
    return out
