"""SOTA-B1 MELD data access with strict label isolation.

Rules enforced here (task book §3):
- Only official train/dev are loadable; any 'test' request fails BEFORE opening a pkl.
- Official key = (split, Dialogue_ID, Utterance_ID); published key = meld_dNNNN::j.
  Binding is proven by full per-utterance text + speaker-slot + position match,
  never by row counts, default concatenation order, or text-dedup alone.
- Dev labels are NOT loaded by the entry or collate. They exist only in the
  separate scorer path (sota_b1_score.load_dev_labels).
- True Sentiment / emotion / transition labels are never model inputs.
- p_index is derived from the speaker sequence only (structural, label-free).
"""
from __future__ import annotations
import csv
import hashlib
import json
import os
from dataclasses import dataclass

import numpy as np

from ..training import sota_b1_spec as spec
from .text import decode_pkl_text


@dataclass
class SotaDialogue:
    dialogue_id: str          # meld_dNNNN
    official_dialogue_id: str  # CSV Dialogue_ID string
    split: str
    utterance_ids: list[str]   # meld_dNNNN::j
    official_utterance_ids: list[str]
    speaker_ids: np.ndarray    # [T] within-dialogue slot 0..8
    speaker_onehot: np.ndarray  # [T,9]
    features: dict[str, np.ndarray]  # text/audio/visual [T,D]
    p_index: np.ndarray        # [T] same-speaker previous, -1 if none

    @property
    def length(self) -> int:
        return len(self.utterance_ids)


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _norm(s: str) -> str:
    """cp1252-normalised text for cross-source matching (audit convention)."""
    try:
        s = s.encode("latin1").decode("cp1252")
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    return " ".join(str(s).split()).strip()


def _read_csv(split: str) -> list[dict]:
    if split not in ("train", "dev"):
        raise PermissionError("only official train/dev CSV may be read")
    p = os.path.join(spec.MELD_CSV_ROOT, f"{split}_sent_emo.csv")
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _speaker_slots(names: list[str]) -> np.ndarray:
    """Within-dialogue speaker role slots by first occurrence (bijective per dialogue)."""
    mapping, out = {}, []
    for n in names:
        if n not in mapping:
            mapping[n] = len(mapping)
        out.append(mapping[n])
    return np.asarray(out, dtype=np.int64)


def _p_index(speaker_ids: np.ndarray) -> np.ndarray:
    n = len(speaker_ids)
    out = np.full(n, -1, dtype=np.int64)
    last = {}
    for j, spk in enumerate(speaker_ids.tolist()):
        if spk in last:
            out[j] = last[spk]
        last[spk] = j
    return out


def verify_binding(features_root: str | None = None) -> dict:
    """Prove (split, Dialogue_ID, Utterance_ID) <-> meld_dNNNN::j by full
    per-utterance match of normalised text, speaker slot and position.

    Returns a manifest with the binding and a digest. No labels are used.
    """
    import pickle
    root = features_root or spec.FEATURES_ROOT
    base_p = os.path.join(root, "MELD_features_raw1.pkl")
    rob_p = os.path.join(root, "meld_features_roberta.pkl")
    for p in (base_p, rob_p):
        if not os.path.isfile(p):
            raise FileNotFoundError(p)
    with open(base_p, "rb") as f:
        base = pickle.load(f, encoding="latin1")   # [0] ids [1] spk [2] labels [3] text600 [4] a [5] v [6] sent
    with open(rob_p, "rb") as f:
        rob = pickle.load(f, encoding="latin1")    # [8] trainIds [9] testIds [10] validIds
    # Mapping convention (audited scripts/audit_data.py):
    #   train pkl key = official train Dialogue_ID (id 60 absent), in CSV order;
    #   dev  pkl key = 1039 + i  ->  i-th official dev dialogue in CSV order;
    #   test pkl key = 1153 + i  ->  i-th official test dialogue (never loaded).
    # We reconstruct candidate key->CSV mapping positionally, then PROVE it by
    # full per-utterance text + speaker-slot + position match.
    def _group(rows):
        out, cur = [], None
        for r in rows:
            did = r["Dialogue_ID"]
            if cur is None or cur["did"] != did:
                cur = {"did": did, "rows": []}
                out.append(cur)
            cur["rows"].append(r)
        return out

    csv_dev = _group(_read_csv("dev"))
    csv_train = _group(_read_csv("train"))
    train_ids = sorted(int(x) for x in rob[8])
    dev_ids = sorted(int(x) for x in rob[10])
    if train_ids != sorted(int(d["did"]) for d in csv_train):
        raise ValueError("train pkl keys != official train Dialogue_ID set")
    if dev_ids != [1039 + i for i in range(len(csv_dev))]:
        raise ValueError("dev pkl keys != 1039+i convention")
    cand = {"train": list(zip(train_ids, csv_train)),
            "dev": list(zip(dev_ids, csv_dev))}

    binding: dict[str, dict] = {}
    detail = {}
    for split in ("train", "dev"):
        b = {}
        checked_utt = 0
        for k, dia in cand[split]:
            rows_d = sorted(dia["rows"], key=lambda r: int(r["Utterance_ID"]))
            n = len(rows_d)
            sent = base[6][k]
            if len(sent) != n:
                raise ValueError(f"{split}/{k}: sentence count {len(sent)} != CSV {n}")
            slots = _speaker_slots([r["Speaker"] for r in rows_d])
            pkl_slots = np.argmax(np.asarray(base[1][k], dtype=np.float32), axis=1)
            if len(pkl_slots) != n or not np.array_equal(slots, pkl_slots):
                raise ValueError(f"{split}/{k}: speaker-slot sequence mismatch")
            int_keys, off_keys, spk_chk = [], [], []
            for j, r in enumerate(rows_d):
                csv_txt = _norm(r["Utterance"])
                pkl_txt = _norm(decode_pkl_text(sent[j]))
                if csv_txt != pkl_txt:
                    raise ValueError(f"{split}/{k}/{j}: text mismatch "
                                     f"csv={csv_txt[:60]!r} pkl={pkl_txt[:60]!r}")
                int_keys.append(f"meld_d{k:04d}::{j}")
                off_keys.append((str(int(r["Dialogue_ID"])), str(int(r["Utterance_ID"]))))
                spk_chk.append(int(slots[j]))
                checked_utt += 1
            b[str(k)] = {"internal_dialogue": f"meld_d{k:04d}",
                         "utterance_keys": int_keys,
                         "official": off_keys, "speaker_slots": spk_chk}
        binding[split] = b
        detail[split] = {"dialogues": len(b), "utterances": checked_utt}
    manifest = {
        "method": "full per-utterance normalised text + speaker-slot + position match",
        "key_convention": "train key=official Dialogue_ID; dev key=1039+idx; test=1153+idx (never loaded)",
        "text_normalisation": "cp1252 decode, whitespace collapse",
        "counts": detail,
        "class_order": spec.CLASS_ORDER,
        "binding_sha256": _sha(json.dumps(binding, sort_keys=True, ensure_ascii=False)),
    }
    return {"manifest": manifest, "binding": binding}


# label-free loaders -----------------------------------------------------------

def load_dialogues(split: str, features_root: str | None = None,
                   binding: dict | None = None) -> list[SotaDialogue]:
    """Load STRUCTURE ONLY. Dev labels are never touched here."""
    if split == "test":
        # Sentinel: fail before any feature file is opened.
        raise PermissionError("SOTA-B1 refuses MELD test: no test loader/param/branch exists")
    if split not in ("train", "dev"):
        raise ValueError(f"unknown split {split!r}")
    import pickle
    root = features_root or spec.FEATURES_ROOT
    if binding is None:
        binding = verify_binding(root)["binding"]
    bmap = binding[split]
    base_p = os.path.join(root, "MELD_features_raw1.pkl")
    rob_p = os.path.join(root, "meld_features_roberta.pkl")
    with open(base_p, "rb") as f:
        base = pickle.load(f, encoding="latin1")
    with open(rob_p, "rb") as f:
        rob = pickle.load(f, encoding="latin1")
    out = []
    for did_s, entry in bmap.items():
        k = int(did_s)
        n = len(entry["utterance_keys"])
        onehot = np.asarray(base[1][k], dtype=np.float32)
        speaker_ids = np.argmax(onehot, axis=1).astype(np.int64)
        feats = {
            "text": np.asarray(rob[3][k], dtype=np.float32),  # roberta1
            "audio": np.asarray(base[4][k], dtype=np.float32),
            "visual": np.asarray(base[5][k], dtype=np.float32),
        }
        for name, arr in feats.items():
            if arr.shape[0] != n:
                raise ValueError(f"{split}/{k}: {name} length {arr.shape[0]} != {n}")
        off = entry["official"]
        out.append(SotaDialogue(
            dialogue_id=entry["internal_dialogue"], official_dialogue_id=did_s,
            split=split, utterance_ids=entry["utterance_keys"],
            official_utterance_ids=[f"{d}::{u}" for d, u in off],
            speaker_ids=speaker_ids, speaker_onehot=onehot,
            features=feats, p_index=_p_index(speaker_ids)))
    return out


def load_train_labels(features_root: str | None = None, binding: dict | None = None) -> dict[str, int]:
    """Train emotion labels, used ONLY by the training loss path."""
    import pickle
    root = features_root or spec.FEATURES_ROOT
    if binding is None:
        binding = verify_binding(root)["binding"]
    with open(os.path.join(root, "MELD_features_raw1.pkl"), "rb") as f:
        base = pickle.load(f, encoding="latin1")
    out = {}
    for did_s, entry in binding["train"].items():
        k = int(did_s)
        labs = [int(x) for x in base[2][k]]
        for key, y in zip(entry["utterance_keys"], labs):
            out[key] = y
    return out


def collate(dialogues: list[SotaDialogue]) -> dict:
    """Model input only: text/audio/visual/speaker/position/mask + keys.
    No labels of any kind are placed in the batch dict.
    """
    B = len(dialogues)
    lengths = [d.length for d in dialogues]
    T = max(lengths)
    td, ad, vd = spec.FEATURE_DIMS["text"], spec.FEATURE_DIMS["audio"], spec.FEATURE_DIMS["visual"]
    text = torch.zeros(T, B, td)
    audio = torch.zeros(T, B, ad)
    visual = torch.zeros(T, B, vd)
    qmask = torch.zeros(T, B, spec.FEATURE_DIMS["speakers"])
    umask = torch.zeros(T, B)
    keys = []
    for b, d in enumerate(dialogues):
        n = d.length
        text[:n, b] = torch.from_numpy(d.features["text"])
        audio[:n, b] = torch.from_numpy(d.features["audio"])
        visual[:n, b] = torch.from_numpy(d.features["visual"])
        qmask[:n, b] = torch.from_numpy(d.speaker_onehot)
        umask[:n, b] = 1.0
        for j, key in enumerate(d.utterance_ids):
            keys.append(key)
    return {"text": text, "audio": audio, "visual": visual,
            "qmask": qmask, "umask": umask, "lengths": lengths,
            "keys": keys, "batch_size": B}


def batch_plan(dialogue_ids: list[str], ucounts: list[int], *, seed: int, epoch: int,
               batch_size: int) -> dict:
    """Deterministic per-epoch dialogue batch plan (shared across the two SDT arms)."""
    rng = np.random.Generator(np.random.PCG64(
        int.from_bytes(hashlib.sha256(f"{seed}:{epoch}".encode()).digest()[:8], "big")))
    order = rng.permutation(len(dialogue_ids)).tolist()
    batches = []
    for s in range(0, len(order), batch_size):
        idx = order[s:s + batch_size]
        batches.append({"dialogue_ids": [dialogue_ids[i] for i in idx],
                        "targets": int(sum(ucounts[i] for i in idx))})
    payload = {"seed": seed, "epoch": epoch, "batch_size": batch_size,
               "n_dialogues": len(dialogue_ids), "n_targets": int(sum(ucounts)),
               "batches": batches}
    payload["plan_sha256"] = spec.sha_json(payload)
    return payload


import torch  # noqa: E402  (collate needs torch; kept late so audit-only import is light)
