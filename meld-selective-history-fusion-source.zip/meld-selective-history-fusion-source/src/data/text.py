"""已核验句子文本的编码处理（M3NET pkl 中为 Python2 latin1 字节串）。"""
from __future__ import annotations


def decode_pkl_text(value) -> str:
    """把 pkl 中的 Python2 字节串按 cp1252 还原为可读文本；无法编码时原样返回。"""
    try:
        return str(value).encode("latin1").decode("cp1252")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return str(value)
