"""S2-D1: MELD official-split loader for the public baseline tracks.

Two feature tracks are kept distinct:
- native: MM-DFN/M3Net released TextCNN/GloVe text 600, audio 300, visual 342;
- common: C3 RoBERTa `roberta1` 1024, audio 300, visual 342 (plus roberta1..4
  only for M3Net's official four-stream RoBERTa path).

Only the audited MELD official split is loaded (train/dev; test is refused).
No raw audio/video is downloaded or decoded.
"""
from __future__ import annotations

import os
import pickle
from dataclasses import dataclass

import numpy as np

from .meld import split_dialogue_ids, MELD_NUM_CLASSES, MELD_NUM_ROLE_SLOTS

_ROB_SLOT = {"roberta1": 3, "roberta2": 4, "roberta3": 5, "roberta4": 6}


@dataclass
class PublicDialogue:
    dialogue_id: str
    split: str
    utterance_ids: list[str]
    speaker_ids: np.ndarray       # [T]
    speaker_onehot: np.ndarray    # [T,9]
    labels: np.ndarray            # [T]
    p_index: np.ndarray           # [T], -1 if none
    transition: np.ndarray        # [T], -1 no p, else 0/1
    features: dict[str, np.ndarray]
    text_layers: list[np.ndarray] | None
    feature_track: str

    @property
    def length(self) -> int:
        return len(self.labels)


def _load_pickles(features_dir: str):
    base_path = os.path.join(features_dir, "MELD_features_raw1.pkl")
    rob_path = os.path.join(features_dir, "meld_features_roberta.pkl")
    for p in (base_path, rob_path):
        if not os.path.isfile(p):
            raise FileNotFoundError(p)
    base = pickle.load(open(base_path, "rb"), encoding="latin1")
    rob = pickle.load(open(rob_path, "rb"), encoding="latin1")
    if len(base) != 10 or len(rob) != 11:
        raise ValueError("unexpected MELD pkl structure")
    return base, rob


def load_public_meld(features_dir: str, split: str, *, track: str,
                     four_text_layers: bool = False,
                     repeat_roberta1: bool = False) -> list[PublicDialogue]:
    if split not in ("train", "dev"):
        raise PermissionError("S2-D1 only allows MELD train/dev; test is not authorized")
    if track not in ("native", "common"):
        raise ValueError(track)
    base, rob = _load_pickles(features_dir)
    ids = split_dialogue_ids(features_dir, split)
    out = []
    for k in ids:
        n = len(base[2][k])
        labels = np.asarray(base[2][k], dtype=np.int64)
        onehot = np.asarray(base[1][k], dtype=np.float32)
        if onehot.ndim != 2 or onehot.shape[1] != MELD_NUM_ROLE_SLOTS or len(onehot) != n:
            raise ValueError(f"MELD {k}: bad speaker one-hot shape {onehot.shape}")
        speaker_ids = np.argmax(onehot, axis=1).astype(np.int64)
        audio = np.asarray(base[4][k], dtype=np.float32)
        visual = np.asarray(base[5][k], dtype=np.float32)
        if track == "native":
            text = np.asarray(base[3][k], dtype=np.float32)
            layers = None
        else:
            text = np.asarray(rob[_ROB_SLOT["roberta1"]][k], dtype=np.float32)
            if four_text_layers:
                if repeat_roberta1:
                    layers = [text.copy() for _ in range(4)]
                else:
                    layers = [np.asarray(rob[_ROB_SLOT[f"roberta{i}"]][k], dtype=np.float32)
                              for i in range(1, 5)]
            else:
                layers = None
        for name, arr in (("text", text), ("audio", audio), ("visual", visual)):
            if arr.shape[0] != n:
                raise ValueError(f"MELD {k}: {name} length {arr.shape[0]} != {n}")
        p_index = np.full(n, -1, dtype=np.int64)
        last = {}
        for j, spk in enumerate(speaker_ids.tolist()):
            if spk in last:
                p_index[j] = last[spk]
            last[spk] = j
        transition = np.full(n, -1, dtype=np.int64)
        has = p_index >= 0
        transition[has] = (labels[has] != labels[p_index[has]]).astype(np.int64)
        out.append(PublicDialogue(
            dialogue_id=f"meld_d{k:04d}", split=split,
            utterance_ids=[f"meld_d{k:04d}_u{j:03d}" for j in range(n)],
            speaker_ids=speaker_ids, speaker_onehot=onehot, labels=labels,
            p_index=p_index, transition=transition,
            features={"text": text, "audio": audio, "visual": visual},
            text_layers=layers, feature_track=track))
    return out
